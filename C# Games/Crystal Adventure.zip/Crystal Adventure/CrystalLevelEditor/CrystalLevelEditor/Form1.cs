﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CrystalLevelEditor
{
    public partial class Form1 : Form
    {
        /*BUGS TO BE WORKED OUT
         * 1. Any time you want to change the file, you must first edit the document manually to have 48 characters, each one having their own line.
         * 2. You must make the level every time you want to play the game (error with results in game1 being null, and only having values if the current program runs through this class).
         * 3. Enemies and the player don't get assigned to proper positions (this is due to them being drawn differently than walls, I can't currently give them position values).
         * 4. Walls are weird and buggy, doesn't seem to put down all the walls correctly and I cannot figure out why.
         */
        public int color = 0; //int value to choose what color to assign

        //text file that will be edited
        public string filePath = "../../../../lvltxt.rtf";
        public string[] text;
        public string tEdit;
        public string resetText;

        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        #region Up 2 Code
        private void button1_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button1.BackColor = Color.Green;
                text[0] = "W";
            }
            else if (color == 2)
            {
                button1.BackColor = Color.Red;
                text[0] = "E";
            }
            else if (color == 3)
            {
                button1.BackColor = Color.AliceBlue;
                text[0] = "H";
            }
            else if (color == 4)
            {
                button1.BackColor = Color.Yellow;
                text[0] = "F";
            }
            else if (color == 5)
            {
                button1.BackColor = Color.MidnightBlue;
                text[0] = "O";
            }
            else if (color == 6)
            {
                button1.BackColor = Color.Magenta;
                text[0] = "C";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button2.BackColor = Color.Green;
                text[1] = "W";
            }
            else if (color == 2)
            {
                button2.BackColor = Color.Red;
                text[1] = "E";
            }
            else if (color == 3)
            {
                button2.BackColor = Color.Blue;
                text[1] = "H";
            }
            else if (color == 4)
            {
                button2.BackColor = Color.Yellow;
                text[1] = "F";
            }
            else if (color == 5)
            {
                button2.BackColor = Color.MidnightBlue;
                text[1] = "O";
            }
            else if (color == 6)
            {
                button2.BackColor = Color.Magenta;
                text[1] = "C";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button3.BackColor = Color.Green;
                text[2] = "W";
            }
            else if (color == 2)
            {
                button3.BackColor = Color.Red;
                text[2] = "E";
            }
            else if (color == 3)
            {
                button3.BackColor = Color.Blue;
                text[2] = "H";
            }
            else if (color == 4)
            {
                button3.BackColor = Color.Yellow;
                text[2] = "F";
            }
            else if (color == 5)
            {
                button3.BackColor = Color.MidnightBlue;
                text[2] = "O";
            }
            else if (color == 6)
            {
                button3.BackColor = Color.Magenta;
                text[2] = "C";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button4.BackColor = Color.Green;
                text[3] = "W";
            }
            else if (color == 2)
            {
                button4.BackColor = Color.Red;
                text[3] = "E";
            }
            else if (color == 3)
            {
                button4.BackColor = Color.Blue;
                text[3] = "H";
            }
            else if (color == 4)
            {
                button4.BackColor = Color.Yellow;
                text[3] = "F";
            }
            else if (color == 5)
            {
                button4.BackColor = Color.MidnightBlue;
                text[3] = "O";
            }
            else if (color == 6)
            {
                button4.BackColor = Color.Magenta;
                text[3] = "C";
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button5.BackColor = Color.Green;
                text[4] = "W";
            }
            else if (color == 2)
            {
                button5.BackColor = Color.Red;
                text[4] = "E";
            }
            else if (color == 3)
            {
                button5.BackColor = Color.Blue;
                text[4] = "H";
            }
            else if (color == 4)
            {
                button5.BackColor = Color.Yellow;
                text[4] = "F";
            }
            else if (color == 5)
            {
                button5.BackColor = Color.MidnightBlue;
                text[4] = "O";
            }
            else if (color == 6)
            {
                button5.BackColor = Color.Magenta;
                text[4] = "C";
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button6.BackColor = Color.Green;
                text[5] = "W";
            }
            else if (color == 2)
            {
                button6.BackColor = Color.Red;
                text[5] = "E";
            }
            else if (color == 3)
            {
                button6.BackColor = Color.Blue;
                text[5] = "H";
            }
            else if (color == 4)
            {
                button6.BackColor = Color.Yellow;
                text[5] = "F";
            }
            else if (color == 5)
            {
                button6.BackColor = Color.MidnightBlue;
                text[5] = "O";
            }
            else if (color == 6)
            {
                button6.BackColor = Color.Magenta;
                text[5] = "C";
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button7.BackColor = Color.Green;
                text[6] = "W";
            }
            else if (color == 2)
            {
                button7.BackColor = Color.Red;
                text[6] = "E";
            }
            else if (color == 3)
            {
                button7.BackColor = Color.Blue;
                text[6] = "H";
            }
            else if (color == 4)
            {
                button7.BackColor = Color.Yellow;
                text[6] = "F";
            }
            else if (color == 5)
            {
                button7.BackColor = Color.MidnightBlue;
                text[6] = "O";
            }
            else if (color == 6)
            {
                button7.BackColor = Color.Magenta;
                text[6] = "C";
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button8.BackColor = Color.Green;
                text[7] = "W";
            }
            else if (color == 2)
            {
                button8.BackColor = Color.Red;
                text[7] = "E";
            }
            else if (color == 3)
            {
                button8.BackColor = Color.Blue;
                text[7] = "H";
            }
            else if (color == 4)
            {
                button8.BackColor = Color.Yellow;
                text[7] = "F";
            }
            else if (color == 5)
            {
                button8.BackColor = Color.MidnightBlue;
                text[7] = "O";
            }
            else if (color == 6)
            {
                button8.BackColor = Color.Magenta;
                text[7] = "C";
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button9.BackColor = Color.Green;
                text[8] = "W";
            }
            else if (color == 2)
            {
                button9.BackColor = Color.Red;
                text[8] = "E";
            }
            else if (color == 3)
            {
                button9.BackColor = Color.Blue;
                text[8] = "H";
            }
            else if (color == 4)
            {
                button9.BackColor = Color.Yellow;
                text[8] = "F";
            }
            else if (color == 5)
            {
                button9.BackColor = Color.MidnightBlue;
                text[8] = "O";
            }
            else if (color == 6)
            {
                button9.BackColor = Color.Magenta;
                text[8] = "C";
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button10.BackColor = Color.Green;
                text[9] = "W";
            }
            else if (color == 2)
            {
                button10.BackColor = Color.Red;
                text[9] = "E";
            }
            else if (color == 3)
            {
                button10.BackColor = Color.Blue;
                text[9] = "H";
            }
            else if (color == 4)
            {
                button10.BackColor = Color.Yellow;
                text[9] = "F";
            }
            else if (color == 5)
            {
                button10.BackColor = Color.MidnightBlue;
                text[9] = "O";
            }
            else if (color == 6)
            {
                button10.BackColor = Color.Magenta;
                text[9] = "C";
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button11.BackColor = Color.Green;
                text[10] = "W";
            }
            else if (color == 2)
            {
                button11.BackColor = Color.Red;
                text[10] = "E";
            }
            else if (color == 3)
            {
                button11.BackColor = Color.Blue;
                text[10] = "H";
            }
            else if (color == 4)
            {
                button11.BackColor = Color.Yellow;
                text[10] = "F";
            }
            else if (color == 5)
            {
                button11.BackColor = Color.MidnightBlue;
                text[10] = "O";
            }
            else if (color == 6)
            {
                button11.BackColor = Color.Magenta;
                text[10] = "C";
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button12.BackColor = Color.Green;
                text[11] = "W";
            }
            else if (color == 2)
            {
                button12.BackColor = Color.Red;
                text[11] = "E";
            }
            else if (color == 3)
            {
                button12.BackColor = Color.Blue;
                text[11] = "H";
            }
            else if (color == 4)
            {
                button12.BackColor = Color.Yellow;
                text[11] = "F";
            }
            else if (color == 5)
            {
                button12.BackColor = Color.MidnightBlue;
                text[11] = "O";
            }
            else if (color == 6)
            {
                button12.BackColor = Color.Magenta;
                text[11] = "C";
            }

        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button13.BackColor = Color.Green;
                text[12] = "W";
            }
            else if (color == 2)
            {
                button13.BackColor = Color.Red;
                text[12] = "E";
            }
            else if (color == 3)
            {
                button13.BackColor = Color.Blue;
                text[12] = "H";
            }
            else if (color == 4)
            {
                button13.BackColor = Color.Yellow;
                text[11] = "F";
            }
            else if (color == 5)
            {
                button13.BackColor = Color.MidnightBlue;
                text[12] = "O";
            }
            else if (color == 6)
            {
                button13.BackColor = Color.Magenta;
                text[12] = "C";
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button14.BackColor = Color.Green;
                text[13] = "W";
            }
            else if (color == 2)
            {
                button14.BackColor = Color.Red;
                text[13] = "E";
            }
            else if (color == 3)
            {
                button14.BackColor = Color.Blue;
                text[13] = "H";
            }
            else if (color == 4)
            {
                button14.BackColor = Color.Yellow;
                text[13] = "F";
            }
            else if (color == 5)
            {
                button14.BackColor = Color.MidnightBlue;
                text[13] = "O";
            }
            else if (color == 6)
            {
                button14.BackColor = Color.Magenta;
                text[13] = "C";
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button15.BackColor = Color.Green;
                text[14] = "W";
            }
            else if (color == 2)
            {
                button15.BackColor = Color.Red;
                text[14] = "E";
            }
            else if (color == 3)
            {
                button15.BackColor = Color.Blue;
                text[14] = "H";
            }
            else if (color == 4)
            {
                button15.BackColor = Color.Yellow;
                text[14] = "F";
            }
            else if (color == 5)
            {
                button15.BackColor = Color.MidnightBlue;
                text[14] = "O";
            }
            else if (color == 6)
            {
                button15.BackColor = Color.Magenta;
                text[14] = "C";
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button16.BackColor = Color.Green;
                text[15] = "W";
            }
            else if (color == 2)
            {
                button16.BackColor = Color.Red;
                text[15] = "E";
            }
            else if (color == 3)
            {
                button16.BackColor = Color.Blue;
                text[15] = "H";
            }
            else if (color == 4)
            {
                button16.BackColor = Color.Yellow;
                text[15] = "F";
            }
            else if (color == 5)
            {
                button16.BackColor = Color.MidnightBlue;
                text[15] = "O";
            }
            else if (color == 6)
            {
                button16.BackColor = Color.Magenta;
                text[15] = "C";
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button17.BackColor = Color.Green;
                text[16] = "W";
            }
            else if (color == 2)
            {
                button17.BackColor = Color.Red;
                text[16] = "E";
            }
            else if (color == 3)
            {
                button17.BackColor = Color.Blue;
                text[16] = "H";
            }
            else if (color == 4)
            {
                button17.BackColor = Color.Yellow;
                text[16] = "F";
            }
            else if (color == 5)
            {
                button17.BackColor = Color.MidnightBlue;
                text[16] = "O";
            }
            else if (color == 6)
            {
                button17.BackColor = Color.Magenta;
                text[16] = "C";
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button18.BackColor = Color.Green;
                text[17] = "W";
            }
            else if (color == 2)
            {
                button18.BackColor = Color.Red;
                text[17] = "E";
            }
            else if (color == 3)
            {
                button18.BackColor = Color.Blue;
                text[17] = "H";
            }
            else if (color == 4)
            {
                button18.BackColor = Color.Yellow;
                text[17] = "F";
            }
            else if (color == 5)
            {
                button18.BackColor = Color.MidnightBlue;
                text[17] = "O";
            }
            else if (color == 6)
            {
                button18.BackColor = Color.Magenta;
                text[17] = "C";
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button19.BackColor = Color.Green;
                text[18] = "W";
            }
            else if (color == 2)
            {
                button19.BackColor = Color.Red;
                text[18] = "E";
            }
            else if (color == 3)
            {
                button19.BackColor = Color.Blue;
                text[18] = "H";
            }
            else if (color == 4)
            {
                button19.BackColor = Color.Yellow;
                text[18] = "F";
            }
            else if (color == 5)
            {
                button19.BackColor = Color.MidnightBlue;
                text[18] = "O";
            }
            else if (color == 6)
            {
                button19.BackColor = Color.Magenta;
                text[18] = "C";
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button20.BackColor = Color.Green;
                text[19] = "W";
            }
            else if (color == 2)
            {
                button20.BackColor = Color.Red;
                text[19] = "E";
            }
            else if (color == 3)
            {
                button20.BackColor = Color.Blue;
                text[19] = "H";
            }
            else if (color == 4)
            {
                button20.BackColor = Color.Yellow;
                text[19] = "F";
            }
            else if (color == 5)
            {
                button20.BackColor = Color.MidnightBlue;
                text[19] = "O";
            }
            else if (color == 6)
            {
                button20.BackColor = Color.Magenta;
                text[19] = "C";
            }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button21.BackColor = Color.Green;
                text[20] = "W";
            }
            else if (color == 2)
            {
                button21.BackColor = Color.Red;
                text[20] = "E";
            }
            else if (color == 3)
            {
                button21.BackColor = Color.Blue;
                text[20] = "H";
            }
            else if (color == 4)
            {
                button21.BackColor = Color.Yellow;
                text[20] = "F";
            }
            else if (color == 5)
            {
                button21.BackColor = Color.MidnightBlue;
                text[20] = "O";
            }
            else if (color == 6)
            {
                button21.BackColor = Color.Magenta;
                text[20] = "C";
            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button22.BackColor = Color.Green;
                text[21] = "W";
            }
            else if (color == 2)
            {
                button22.BackColor = Color.Red;
                text[21] = "E";
            }
            else if (color == 3)
            {
                button22.BackColor = Color.Blue;
                text[21] = "H";
            }
            else if (color == 4)
            {
                button22.BackColor = Color.Yellow;
                text[21] = "F";
            }
            else if (color == 5)
            {
                button22.BackColor = Color.MidnightBlue;
                text[21] = "O";
            }
            else if (color == 6)
            {
                button22.BackColor = Color.Magenta;
                text[21] = "C";
            }
        }

        private void button23_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button23.BackColor = Color.Green;
                text[22] = "W";
            }
            else if (color == 2)
            {
                button23.BackColor = Color.Red;
                text[22] = "E";
            }
            else if (color == 3)
            {
                button23.BackColor = Color.Blue;
                text[22] = "H";
            }
            else if (color == 4)
            {
                button23.BackColor = Color.Yellow;
                text[22] = "F";
            }
            else if (color == 5)
            {
                button23.BackColor = Color.MidnightBlue;
                text[22] = "O";
            }
            else if (color == 6)
            {
                button23.BackColor = Color.Magenta;
                text[22] = "C";
            }
        }

        private void button24_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button24.BackColor = Color.Green;
                text[23] = "W";
            }
            else if (color == 2)
            {
                button24.BackColor = Color.Red;
                text[23] = "E";
            }
            else if (color == 3)
            {
                button24.BackColor = Color.Blue;
                text[23] = "H";
            }
            else if (color == 4)
            {
                button24.BackColor = Color.Yellow;
                text[23] = "F";
            }
            else if (color == 5)
            {
                button24.BackColor = Color.MidnightBlue;
                text[23] = "O";
            }
            else if (color == 6)
            {
                button24.BackColor = Color.Magenta;
                text[23] = "C";
            }
        }

        private void button25_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button25.BackColor = Color.Green;
                text[24] = "W";
            }
            else if (color == 2)
            {
                button25.BackColor = Color.Red;
                text[24] = "E";
            }
            else if (color == 3)
            {
                button25.BackColor = Color.Blue;
                text[24] = "H";
            }
            else if (color == 4)
            {
                button25.BackColor = Color.Yellow;
                text[24] = "F";
            }
            else if (color == 5)
            {
                button25.BackColor = Color.MidnightBlue;
                text[24] = "O";
            }
            else if (color == 6)
            {
                button25.BackColor = Color.Magenta;
                text[24] = "C";
            }
        }

        private void button26_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button26.BackColor = Color.Green;
                text[25] = "W";
            }
            else if (color == 2)
            {
                button26.BackColor = Color.Red;
                text[25] = "E";
            }
            else if (color == 3)
            {
                button26.BackColor = Color.Blue;
                text[25] = "H";
            }
            else if (color == 4)
            {
                button26.BackColor = Color.Yellow;
                text[25] = "F";
            }
            else if (color == 5)
            {
                button26.BackColor = Color.MidnightBlue;
                text[25] = "O";
            }
            else if (color == 6)
            {
                button26.BackColor = Color.Magenta;
                text[25] = "C";
            }
        }

        private void button27_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button27.BackColor = Color.Green;
                text[26] = "W";
            }
            else if (color == 2)
            {
                button27.BackColor = Color.Red;
                text[26] = "E";
            }
            else if (color == 3)
            {
                button27.BackColor = Color.Blue;
                text[26] = "H";
            }
            else if (color == 4)
            {
                button27.BackColor = Color.Yellow;
                text[26] = "F";
            }
            else if (color == 5)
            {
                button27.BackColor = Color.MidnightBlue;
                text[26] = "O";
            }
            else if (color == 6)
            {
                button27.BackColor = Color.Magenta;
                text[26] = "C";
            }
        }

        private void button28_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button28.BackColor = Color.Green;
                text[27] = "W";
            }
            else if (color == 2)
            {
                button28.BackColor = Color.Red;
                text[27] = "E";
            }
            else if (color == 3)
            {
                button28.BackColor = Color.Blue;
                text[27] = "H";
            }
            else if (color == 4)
            {
                button28.BackColor = Color.Yellow;
                text[27] = "F";
            }
            else if (color == 5)
            {
                button28.BackColor = Color.MidnightBlue;
                text[27] = "O";
            }
            else if (color == 6)
            {
                button28.BackColor = Color.Magenta;
                text[27] = "C";
            }
        }

        private void button29_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button29.BackColor = Color.Green;
                text[28] = "W";
            }
            else if (color == 2)
            {
                button29.BackColor = Color.Red;
                text[28] = "E";
            }
            else if (color == 3)
            {
                button29.BackColor = Color.Blue;
                text[28] = "H";
            }
            else if (color == 4)
            {
                button29.BackColor = Color.Yellow;
                text[28] = "F";
            }
            else if (color == 5)
            {
                button29.BackColor = Color.MidnightBlue;
                text[28] = "O";
            }
            else if (color == 6)
            {
                button29.BackColor = Color.Magenta;
                text[28] = "C";
            }
        }

        private void button30_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button30.BackColor = Color.Green;
                text[29] = "W";
            }
            else if (color == 2)
            {
                button30.BackColor = Color.Red;
                text[29] = "E";
            }
            else if (color == 3)
            {
                button30.BackColor = Color.Blue;
                text[29] = "H";
            }
            else if (color == 4)
            {
                button30.BackColor = Color.Yellow;
                text[29] = "F";
            }
            else if (color == 5)
            {
                button30.BackColor = Color.MidnightBlue;
                text[29] = "O";
            }
            else if (color == 6)
            {
                button30.BackColor = Color.Magenta;
                text[29] = "C";
            }
        }

        private void button31_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button31.BackColor = Color.Green;
                text[30] = "W";
            }
            else if (color == 2)
            {
                button31.BackColor = Color.Red;
                text[30] = "E";
            }
            else if (color == 3)
            {
                button31.BackColor = Color.Blue;
                text[30] = "H";
            }
            else if (color == 4)
            {
                button31.BackColor = Color.Yellow;
                text[30] = "F";
            }
            else if (color == 5)
            {
                button31.BackColor = Color.MidnightBlue;
                text[30] = "O";
            }
            else if (color == 6)
            {
                button31.BackColor = Color.Magenta;
                text[30] = "C";
            }
        }

        private void button32_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button32.BackColor = Color.Green;
                text[31] = "W";
            }
            else if (color == 2)
            {
                button32.BackColor = Color.Red;
                text[31] = "E";
            }
            else if (color == 3)
            {
                button32.BackColor = Color.Blue;
                text[31] = "H";
            }
            else if (color == 4)
            {
                button32.BackColor = Color.Yellow;
                text[31] = "F";
            }
            else if (color == 5)
            {
                button32.BackColor = Color.MidnightBlue;
                text[31] = "O";
            }
            else if (color == 6)
            {
                button32.BackColor = Color.Magenta;
                text[31] = "C";
            }
        }

        private void button33_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button33.BackColor = Color.Green;
                text[32] = "W";
            }
            else if (color == 2)
            {
                button33.BackColor = Color.Red;
                text[32] = "E";
            }
            else if (color == 3)
            {
                button33.BackColor = Color.Blue;
                text[32] = "H";
            }
            else if (color == 4)
            {
                button33.BackColor = Color.Yellow;
                text[33] = "F";
            }
            else if (color == 5)
            {
                button33.BackColor = Color.MidnightBlue;
                text[32] = "O";
            }
            else if (color == 6)
            {
                button33.BackColor = Color.Magenta;
                text[32] = "C";
            }
        }

        private void button34_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button34.BackColor = Color.Green;
                text[33] = "W";
            }
            else if (color == 2)
            {
                button34.BackColor = Color.Red;
                text[33] = "E";
            }
            else if (color == 3)
            {
                button34.BackColor = Color.Blue;
                text[33] = "H";
            }
            else if (color == 4)
            {
                button34.BackColor = Color.Yellow;
                text[33] = "F";
            }
            else if (color == 5)
            {
                button34.BackColor = Color.MidnightBlue;
                text[33] = "O";
            }
            else if (color == 6)
            {
                button34.BackColor = Color.Magenta;
                text[33] = "C";
            }
        }

        private void button35_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button35.BackColor = Color.Green;
                text[34] = "W";
            }
            else if (color == 2)
            {
                button35.BackColor = Color.Red;
                text[34] = "E";
            }
            else if (color == 3)
            {
                button35.BackColor = Color.Blue;
                text[34] = "H";
            }
            else if (color == 4)
            {
                button35.BackColor = Color.Yellow;
                text[34] = "F";
            }
            else if (color == 5)
            {
                button35.BackColor = Color.MidnightBlue;
                text[34] = "O";
            }
            else if (color == 6)
            {
                button35.BackColor = Color.Magenta;
                text[34] = "C";
            }
        }

        private void button36_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button36.BackColor = Color.Green;
                text[35] = "W";
            }
            else if (color == 2)
            {
                button36.BackColor = Color.Red;
                text[35] = "E";
            }
            else if (color == 3)
            {
                button36.BackColor = Color.Blue;
                text[35] = "H";
            }
            else if (color == 4)
            {
                button36.BackColor = Color.Yellow;
                text[35] = "F";
            }
            else if (color == 5)
            {
                button36.BackColor = Color.MidnightBlue;
                text[35] = "O";
            }
            else if (color == 6)
            {
                button36.BackColor = Color.Magenta;
                text[35] = "C";
            }
        }

        private void button37_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button37.BackColor = Color.Green;
                text[36] = "W";
            }
            else if (color == 2)
            {
                button37.BackColor = Color.Red;
                text[36] = "E";
            }
            else if (color == 3)
            {
                button37.BackColor = Color.Blue;
                text[36] = "H";
            }
            else if (color == 4)
            {
                button37.BackColor = Color.Yellow;
                text[36] = "F";
            }
            else if (color == 5)
            {
                button37.BackColor = Color.MidnightBlue;
                text[36] = "O";
            }
            else if (color == 6)
            {
                button37.BackColor = Color.Magenta;
                text[36] = "C";
            }
        }

        private void button38_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button38.BackColor = Color.Green;
                text[37] = "W";
            }
            else if (color == 2)
            {
                button38.BackColor = Color.Red;
                text[37] = "E";
            }
            else if (color == 3)
            {
                button38.BackColor = Color.Blue;
                text[37] = "H";
            }
            else if (color == 4)
            {
                button38.BackColor = Color.Yellow;
                text[37] = "F";
            }
            else if (color == 5)
            {
                button38.BackColor = Color.MidnightBlue;
                text[37] = "O";
            }
            else if (color == 6)
            {
                button38.BackColor = Color.Magenta;
                text[37] = "C";
            }
        }

        private void button39_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button39.BackColor = Color.Green;
                text[38] = "W";
            }
            else if (color == 2)
            {
                button39.BackColor = Color.Red;
                text[38] = "E";
            }
            else if (color == 3)
            {
                button39.BackColor = Color.Blue;
                text[38] = "H";
            }
            else if (color == 4)
            {
                button39.BackColor = Color.Yellow;
                text[38] = "F";
            }
            else if (color == 5)
            {
                button39.BackColor = Color.MidnightBlue;
                text[38] = "O";
            }
            else if (color == 6)
            {
                button39.BackColor = Color.Magenta;
                text[38] = "C";
            }
        }

        private void button40_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button40.BackColor = Color.Green;
                text[39] = "W";
            }
            else if (color == 2)
            {
                button40.BackColor = Color.Red;
                text[39] = "E";
            }
            else if (color == 3)
            {
                button40.BackColor = Color.Blue;
                text[39] = "H";
            }
            else if (color == 4)
            {
                button40.BackColor = Color.Yellow;
                text[39] = "F";
            }
            else if (color == 5)
            {
                button40.BackColor = Color.MidnightBlue;
                text[39] = "O";
            }
            else if (color == 6)
            {
                button40.BackColor = Color.Magenta;
                text[39] = "C";
            }
        }

        private void button41_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button41.BackColor = Color.Green;
                text[40] = "W";
            }
            else if (color == 2)
            {
                button41.BackColor = Color.Red;
                text[40] = "E";
            }
            else if (color == 3)
            {
                button41.BackColor = Color.Blue;
                text[40] = "H";
            }
            else if (color == 4)
            {
                button41.BackColor = Color.Yellow;
                text[40] = "F";
            }
            else if (color == 5)
            {
                button41.BackColor = Color.MidnightBlue;
                text[40] = "O";
            }
            else if (color == 6)
            {
                button41.BackColor = Color.Magenta;
                text[40] = "C";
            }
        }

        private void button42_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button42.BackColor = Color.Green;
                text[41] = "W";
            }
            else if (color == 2)
            {
                button42.BackColor = Color.Red;
                text[41] = "E";
            }
            else if (color == 3)
            {
                button42.BackColor = Color.Blue;
                text[41] = "H";
            }
            else if (color == 4)
            {
                button42.BackColor = Color.Yellow;
                text[41] = "F";
            }
            else if (color == 5)
            {
                button42.BackColor = Color.MidnightBlue;
                text[41] = "O";
            }
            else if (color == 6)
            {
                button42.BackColor = Color.Magenta;
                text[41] = "C";
            }
        }

        private void button43_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button43.BackColor = Color.Green;
                text[42] = "W";
            }
            else if (color == 2)
            {
                button43.BackColor = Color.Red;
                text[42] = "E";
            }
            else if (color == 3)
            {
                button43.BackColor = Color.Blue;
                text[42] = "H";
            }
            else if (color == 4)
            {
                button43.BackColor = Color.Yellow;
                text[42] = "F";
            }
            else if (color == 5)
            {
                button43.BackColor = Color.MidnightBlue;
                text[42] = "O";
            }
            else if (color == 6)
            {
                button43.BackColor = Color.Magenta;
                text[42] = "C";
            }
        }

        private void button44_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button44.BackColor = Color.Green;
                text[43] = "W";
            }
            else if (color == 2)
            {
                button44.BackColor = Color.Red;
                text[43] = "E";
            }
            else if (color == 3)
            {
                button44.BackColor = Color.Blue;
                text[43] = "H";
            }
            else if (color == 4)
            {
                button44.BackColor = Color.Yellow;
                text[43] = "F";
            }
            else if (color == 5)
            {
                button44.BackColor = Color.MidnightBlue;
                text[43] = "O";
            }
            else if (color == 6)
            {
                button44.BackColor = Color.Magenta;
                text[43] = "C";
            }
        }

        private void button45_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button45.BackColor = Color.Green;
                text[44] = "W";
            }
            else if (color == 2)
            {
                button45.BackColor = Color.Red;
                text[44] = "E";
            }
            else if (color == 3)
            {
                button45.BackColor = Color.Blue;
                text[44] = "H";
            }
            else if (color == 4)
            {
                button45.BackColor = Color.Yellow;
                text[44] = "F";
            }
            else if (color == 5)
            {
                button45.BackColor = Color.MidnightBlue;
                text[44] = "O";
            }
            else if (color == 6)
            {
                button45.BackColor = Color.Magenta;
                text[44] = "C";
            }
        }

        private void button46_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button46.BackColor = Color.Green;
                text[45] = "W";
            }
            else if (color == 2)
            {
                button46.BackColor = Color.Red;
                text[45] = "E";
            }
            else if (color == 3)
            {
                button46.BackColor = Color.Blue;
                text[45] = "H";
            }
            else if (color == 4)
            {
                button46.BackColor = Color.Yellow;
                text[45] = "F";
            }
            else if (color == 5)
            {
                button46.BackColor = Color.MidnightBlue;
                text[45] = "O";
            }
            else if (color == 6)
            {
                button46.BackColor = Color.Magenta;
                text[45] = "C";
            }
        }

        private void button47_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button47.BackColor = Color.Green;
                text[46] = "W";
            }
            else if (color == 2)
            {
                button47.BackColor = Color.Red;
                text[46] = "E";
            }
            else if (color == 3)
            {
                button47.BackColor = Color.Blue;
                text[46] = "H";
            }
            else if (color == 4)
            {
                button47.BackColor = Color.Yellow;
                text[46] = "F";
            }
            else if (color == 5)
            {
                button47.BackColor = Color.MidnightBlue;
                text[46] = "O";
            }
            else if (color == 6)
            {
                button47.BackColor = Color.Magenta;
                text[46] = "C";
            }
        }

        private void button48_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button48.BackColor = Color.Green;
                text[47] = "W";
            }
            else if (color == 2)
            {
                button48.BackColor = Color.Red;
                text[47] = "E";
            }
            else if (color == 3)
            {
                button48.BackColor = Color.Blue;
                text[47] = "H";
            }
            else if (color == 4)
            {
                button48.BackColor = Color.Yellow;
                text[47] = "F";
            }
            else if (color == 5)
            {
                button48.BackColor = Color.MidnightBlue;
                text[47] = "O";
            }
            else if (color == 6)
            {
                button48.BackColor = Color.Magenta;
                text[47] = "C";
            }
        }
        #endregion

        #region Up 1 Code
        private void button49_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button49.BackColor = Color.Green;
                text[48] = "W";
            }
            else if (color == 2)
            {
                button49.BackColor = Color.Red;
                text[48] = "E";
            }
            else if (color == 3)
            {
                button49.BackColor = Color.Blue;
                text[48] = "H";
            }
            else if (color == 4)
            {
                button49.BackColor = Color.Yellow;
                text[48] = "F";
            }
            else if (color == 5)
            {
                button49.BackColor = Color.MidnightBlue;
                text[48] = "O";
            }
            else if (color == 6)
            {
                button49.BackColor = Color.Magenta;
                text[48] = "C";
            }
        }

        private void button50_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button50.BackColor = Color.Green;
                text[49] = "W";
            }
            else if (color == 2)
            {
                button50.BackColor = Color.Red;
                text[49] = "E";
            }
            else if (color == 3)
            {
                button50.BackColor = Color.Blue;
                text[49] = "H";
            }
            else if (color == 4)
            {
                button50.BackColor = Color.Yellow;
                text[49] = "F";
            }
            else if (color == 5)
            {
                button50.BackColor = Color.MidnightBlue;
                text[49] = "O";
            }
            else if (color == 6)
            {
                button50.BackColor = Color.Magenta;
                text[49] = "C";
            }
        }

        private void button51_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button51.BackColor = Color.Green;
                text[50] = "W";
            }
            else if (color == 2)
            {
                button51.BackColor = Color.Red;
                text[50] = "E";
            }
            else if (color == 3)
            {
                button51.BackColor = Color.Blue;
                text[50] = "H";
            }
            else if (color == 4)
            {
                button51.BackColor = Color.Yellow;
                text[50] = "F";
            }
            else if (color == 5)
            {
                button51.BackColor = Color.MidnightBlue;
                text[50] = "O";
            }
            else if (color == 6)
            {
                button51.BackColor = Color.Magenta;
                text[50] = "C";
            }
        }

        private void button52_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button52.BackColor = Color.Green;
                text[51] = "W";
            }
            else if (color == 2)
            {
                button52.BackColor = Color.Red;
                text[51] = "E";
            }
            else if (color == 3)
            {
                button52.BackColor = Color.Blue;
                text[51] = "H";
            }
            else if (color == 4)
            {
                button52.BackColor = Color.Yellow;
                text[51] = "F";
            }
            else if (color == 5)
            {
                button52.BackColor = Color.MidnightBlue;
                text[51] = "O";
            }
            else if (color == 6)
            {
                button52.BackColor = Color.Magenta;
                text[51] = "C";
            }
        }

        private void button53_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button53.BackColor = Color.Green;
                text[52] = "W";
            }
            else if (color == 2)
            {
                button53.BackColor = Color.Red;
                text[52] = "E";
            }
            else if (color == 3)
            {
                button53.BackColor = Color.Blue;
                text[52] = "H";
            }
            else if (color == 4)
            {
                button53.BackColor = Color.Yellow;
                text[52] = "F";
            }
            else if (color == 5)
            {
                button53.BackColor = Color.MidnightBlue;
                text[52] = "O";
            }
            else if (color == 6)
            {
                button53.BackColor = Color.Magenta;
                text[52] = "C";
            }
        }

        private void button54_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button54.BackColor = Color.Green;
                text[53] = "W";
            }
            else if (color == 2)
            {
                button54.BackColor = Color.Red;
                text[53] = "E";
            }
            else if (color == 3)
            {
                button54.BackColor = Color.Blue;
                text[53] = "H";
            }
            else if (color == 4)
            {
                button54.BackColor = Color.Yellow;
                text[53] = "F";
            }
            else if (color == 5)
            {
                button54.BackColor = Color.MidnightBlue;
                text[53] = "O";
            }
            else if (color == 6)
            {
                button54.BackColor = Color.Magenta;
                text[53] = "C";
            }
        }

        private void button55_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button55.BackColor = Color.Green;
                text[54] = "W";
            }
            else if (color == 2)
            {
                button55.BackColor = Color.Red;
                text[54] = "E";
            }
            else if (color == 3)
            {
                button55.BackColor = Color.Blue;
                text[54] = "H";
            }
            else if (color == 4)
            {
                button55.BackColor = Color.Yellow;
                text[54] = "F";
            }
            else if (color == 5)
            {
                button55.BackColor = Color.MidnightBlue;
                text[54] = "O";
            }
            else if (color == 6)
            {
                button55.BackColor = Color.Magenta;
                text[54] = "C";
            }
        }

        private void button56_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button56.BackColor = Color.Green;
                text[55] = "W";
            }
            else if (color == 2)
            {
                button56.BackColor = Color.Red;
                text[55] = "E";
            }
            else if (color == 3)
            {
                button56.BackColor = Color.Blue;
                text[55] = "H";
            }
            else if (color == 4)
            {
                button56.BackColor = Color.Yellow;
                text[55] = "F";
            }
            else if (color == 5)
            {
                button56.BackColor = Color.MidnightBlue;
                text[55] = "O";
            }
            else if (color == 6)
            {
                button56.BackColor = Color.Magenta;
                text[55] = "C";
            }
        }

        private void button57_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button57.BackColor = Color.Green;
                text[56] = "W";
            }
            else if (color == 2)
            {
                button57.BackColor = Color.Red;
                text[56] = "E";
            }
            else if (color == 3)
            {
                button57.BackColor = Color.Blue;
                text[56] = "H";
            }
            else if (color == 4)
            {
                button57.BackColor = Color.Yellow;
                text[56] = "F";
            }
            else if (color == 5)
            {
                button57.BackColor = Color.MidnightBlue;
                text[56] = "O";
            }
            else if (color == 6)
            {
                button57.BackColor = Color.Magenta;
                text[56] = "C";
            }
        }

        private void button58_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button58.BackColor = Color.Green;
                text[57] = "W";
            }
            else if (color == 2)
            {
                button58.BackColor = Color.Red;
                text[57] = "E";
            }
            else if (color == 3)
            {
                button58.BackColor = Color.Blue;
                text[57] = "H";
            }
            else if (color == 4)
            {
                button58.BackColor = Color.Yellow;
                text[57] = "F";
            }
            else if (color == 5)
            {
                button58.BackColor = Color.MidnightBlue;
                text[57] = "O";
            }
            else if (color == 6)
            {
                button58.BackColor = Color.Magenta;
                text[57] = "C";
            }
        }

        private void button59_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button59.BackColor = Color.Green;
                text[58] = "W";
            }
            else if (color == 2)
            {
                button59.BackColor = Color.Red;
                text[58] = "E";
            }
            else if (color == 3)
            {
                button59.BackColor = Color.Blue;
                text[58] = "H";
            }
            else if (color == 4)
            {
                button59.BackColor = Color.Yellow;
                text[58] = "F";
            }
            else if (color == 5)
            {
                button59.BackColor = Color.MidnightBlue;
                text[58] = "O";
            }
            else if (color == 6)
            {
                button59.BackColor = Color.Magenta;
                text[58] = "C";
            }
        }

        private void button60_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button60.BackColor = Color.Green;
                text[59] = "W";
            }
            else if (color == 2)
            {
                button60.BackColor = Color.Red;
                text[59] = "E";
            }
            else if (color == 3)
            {
                button60.BackColor = Color.Blue;
                text[59] = "H";
            }
            else if (color == 4)
            {
                button60.BackColor = Color.Yellow;
                text[59] = "F";
            }
            else if (color == 5)
            {
                button60.BackColor = Color.MidnightBlue;
                text[59] = "O";
            }
            else if (color == 6)
            {
                button60.BackColor = Color.Magenta;
                text[59] = "C";
            }
        }

        private void button61_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button61.BackColor = Color.Green;
                text[60] = "W";
            }
            else if (color == 2)
            {
                button61.BackColor = Color.Red;
                text[60] = "E";
            }
            else if (color == 3)
            {
                button61.BackColor = Color.Blue;
                text[60] = "H";
            }
            else if (color == 4)
            {
                button61.BackColor = Color.Yellow;
                text[60] = "F";
            }
            else if (color == 5)
            {
                button61.BackColor = Color.MidnightBlue;
                text[60] = "O";
            }
            else if (color == 6)
            {
                button61.BackColor = Color.Magenta;
                text[60] = "C";
            }
        }

        private void button62_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button62.BackColor = Color.Green;
                text[61] = "W";
            }
            else if (color == 2)
            {
                button62.BackColor = Color.Red;
                text[61] = "E";
            }
            else if (color == 3)
            {
                button62.BackColor = Color.Blue;
                text[61] = "H";
            }
            else if (color == 4)
            {
                button62.BackColor = Color.Yellow;
                text[61] = "F";
            }
            else if (color == 5)
            {
                button62.BackColor = Color.MidnightBlue;
                text[61] = "O";
            }
            else if (color == 6)
            {
                button62.BackColor = Color.Magenta;
                text[61] = "C";
            }
        }

        private void button63_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button63.BackColor = Color.Green;
                text[62] = "W";
            }
            else if (color == 2)
            {
                button63.BackColor = Color.Red;
                text[62] = "E";
            }
            else if (color == 3)
            {
                button63.BackColor = Color.Blue;
                text[62] = "H";
            }
            else if (color == 4)
            {
                button63.BackColor = Color.Yellow;
                text[62] = "F";
            }
            else if (color == 5)
            {
                button63.BackColor = Color.MidnightBlue;
                text[62] = "O";
            }
            else if (color == 6)
            {
                button63.BackColor = Color.Magenta;
                text[62] = "C";
            }
        }

        private void button64_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button64.BackColor = Color.Green;
                text[63] = "W";
            }
            else if (color == 2)
            {
                button64.BackColor = Color.Red;
                text[63] = "E";
            }
            else if (color == 3)
            {
                button64.BackColor = Color.Blue;
                text[63] = "H";
            }
            else if (color == 4)
            {
                button64.BackColor = Color.Yellow;
                text[63] = "F";
            }
            else if (color == 5)
            {
                button64.BackColor = Color.MidnightBlue;
                text[63] = "O";
            }
            else if (color == 6)
            {
                button64.BackColor = Color.Magenta;
                text[63] = "C";
            }
        }

        private void button65_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button65.BackColor = Color.Green;
                text[64] = "W";
            }
            else if (color == 2)
            {
                button65.BackColor = Color.Red;
                text[64] = "E";
            }
            else if (color == 3)
            {
                button65.BackColor = Color.Blue;
                text[64] = "H";
            }
            else if (color == 4)
            {
                button65.BackColor = Color.Yellow;
                text[64] = "F";
            }
            else if (color == 5)
            {
                button65.BackColor = Color.MidnightBlue;
                text[64] = "O";
            }
            else if (color == 6)
            {
                button65.BackColor = Color.Magenta;
                text[64] = "C";
            }
        }

        private void button66_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button66.BackColor = Color.Green;
                text[65] = "W";
            }
            else if (color == 2)
            {
                button66.BackColor = Color.Red;
                text[65] = "E";
            }
            else if (color == 3)
            {
                button66.BackColor = Color.Blue;
                text[65] = "H";
            }
            else if (color == 4)
            {
                button66.BackColor = Color.Yellow;
                text[65] = "F";
            }
            else if (color == 5)
            {
                button66.BackColor = Color.MidnightBlue;
                text[65] = "O";
            }
            else if (color == 6)
            {
                button66.BackColor = Color.Magenta;
                text[65] = "C";
            }
        }

        private void button67_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button67.BackColor = Color.Green;
                text[66] = "W";
            }
            else if (color == 2)
            {
                button67.BackColor = Color.Red;
                text[66] = "E";
            }
            else if (color == 3)
            {
                button67.BackColor = Color.Blue;
                text[66] = "H";
            }
            else if (color == 4)
            {
                button67.BackColor = Color.Yellow;
                text[66] = "F";
            }
            else if (color == 5)
            {
                button67.BackColor = Color.MidnightBlue;
                text[66] = "O";
            }
            else if (color == 6)
            {
                button67.BackColor = Color.Magenta;
                text[66] = "C";
            }
        }

        private void button68_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button68.BackColor = Color.Green;
                text[67] = "W";
            }
            else if (color == 2)
            {
                button68.BackColor = Color.Red;
                text[67] = "E";
            }
            else if (color == 3)
            {
                button68.BackColor = Color.Blue;
                text[67] = "H";
            }
            else if (color == 4)
            {
                button68.BackColor = Color.Yellow;
                text[67] = "F";
            }
            else if (color == 5)
            {
                button68.BackColor = Color.MidnightBlue;
                text[67] = "O";
            }
            else if (color == 6)
            {
                button68.BackColor = Color.Magenta;
                text[67] = "C";
            }
        }

        private void button69_Click(object sender, EventArgs e) //nice
        {
            if (color == 1)
            {
                button69.BackColor = Color.Green;
                text[68] = "W";
            }
            else if (color == 2)
            {
                button69.BackColor = Color.Red;
                text[68] = "E";
            }
            else if (color == 3)
            {
                button69.BackColor = Color.Blue;
                text[68] = "H";
            }
            else if (color == 4)
            {
                button69.BackColor = Color.Yellow;
                text[68] = "F";
            }
            else if (color == 5)
            {
                button69.BackColor = Color.MidnightBlue;
                text[68] = "O";
            }
            else if (color == 6)
            {
                button69.BackColor = Color.Magenta;
                text[68] = "C";
            }
        }

        private void button70_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button70.BackColor = Color.Green;
                text[69] = "W";
            }
            else if (color == 2)
            {
                button70.BackColor = Color.Red;
                text[69] = "E";
            }
            else if (color == 3)
            {
                button70.BackColor = Color.Blue;
                text[69] = "H";
            }
            else if (color == 4)
            {
                button70.BackColor = Color.Yellow;
                text[69] = "F";
            }
            else if (color == 5)
            {
                button70.BackColor = Color.MidnightBlue;
                text[69] = "O";
            }
            else if (color == 6)
            {
                button70.BackColor = Color.Magenta;
                text[69] = "C";
            }
        }

        private void button71_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button71.BackColor = Color.Green;
                text[70] = "W";
            }
            else if (color == 2)
            {
                button71.BackColor = Color.Red;
                text[70] = "E";
            }
            else if (color == 3)
            {
                button71.BackColor = Color.Blue;
                text[70] = "H";
            }
            else if (color == 4)
            {
                button71.BackColor = Color.Yellow;
                text[70] = "F";
            }
            else if (color == 5)
            {
                button71.BackColor = Color.MidnightBlue;
                text[70] = "O";
            }
            else if (color == 6)
            {
                button71.BackColor = Color.Magenta;
                text[70] = "C";
            }
        }

        private void button72_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button72.BackColor = Color.Green;
                text[71] = "W";
            }
            else if (color == 2)
            {
                button72.BackColor = Color.Red;
                text[71] = "E";
            }
            else if (color == 3)
            {
                button72.BackColor = Color.Blue;
                text[71] = "H";
            }
            else if (color == 4)
            {
                button72.BackColor = Color.Yellow;
                text[71] = "F";
            }
            else if (color == 5)
            {
                button72.BackColor = Color.MidnightBlue;
                text[71] = "O";
            }
            else if (color == 6)
            {
                button72.BackColor = Color.Magenta;
                text[71] = "C";
            }
        }

        private void button73_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button73.BackColor = Color.Green;
                text[72] = "W";
            }
            else if (color == 2)
            {
                button73.BackColor = Color.Red;
                text[72] = "E";
            }
            else if (color == 3)
            {
                button73.BackColor = Color.Blue;
                text[72] = "H";
            }
            else if (color == 4)
            {
                button73.BackColor = Color.Yellow;
                text[72] = "F";
            }
            else if (color == 5)
            {
                button73.BackColor = Color.MidnightBlue;
                text[72] = "O";
            }
            else if (color == 6)
            {
                button73.BackColor = Color.Magenta;
                text[72] = "C";
            }
        }

        private void button74_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button74.BackColor = Color.Green;
                text[73] = "W";
            }
            else if (color == 2)
            {
                button74.BackColor = Color.Red;
                text[73] = "E";
            }
            else if (color == 3)
            {
                button74.BackColor = Color.Blue;
                text[73] = "H";
            }
            else if (color == 4)
            {
                button74.BackColor = Color.Yellow;
                text[73] = "F";
            }
            else if (color == 5)
            {
                button74.BackColor = Color.MidnightBlue;
                text[73] = "O";
            }
            else if (color == 6)
            {
                button74.BackColor = Color.Magenta;
                text[73] = "C";
            }
        }

        private void button75_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button75.BackColor = Color.Green;
                text[74] = "W";
            }
            else if (color == 2)
            {
                button75.BackColor = Color.Red;
                text[74] = "E";
            }
            else if (color == 3)
            {
                button75.BackColor = Color.Blue;
                text[74] = "H";
            }
            else if (color == 4)
            {
                button75.BackColor = Color.Yellow;
                text[74] = "F";
            }
            else if (color == 5)
            {
                button75.BackColor = Color.MidnightBlue;
                text[74] = "O";
            }
            else if (color == 6)
            {
                button75.BackColor = Color.Magenta;
                text[74] = "C";
            }
        }

        private void button76_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button76.BackColor = Color.Green;
                text[75] = "W";
            }
            else if (color == 2)
            {
                button76.BackColor = Color.Red;
                text[75] = "E";
            }
            else if (color == 3)
            {
                button76.BackColor = Color.Blue;
                text[75] = "H";
            }
            else if (color == 4)
            {
                button76.BackColor = Color.Yellow;
                text[75] = "F";
            }
            else if (color == 5)
            {
                button76.BackColor = Color.MidnightBlue;
                text[75] = "O";
            }
            else if (color == 6)
            {
                button76.BackColor = Color.Magenta;
                text[75] = "C";
            }
        }

        private void button77_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button77.BackColor = Color.Green;
                text[76] = "W";
            }
            else if (color == 2)
            {
                button77.BackColor = Color.Red;
                text[76] = "E";
            }
            else if (color == 3)
            {
                button77.BackColor = Color.Blue;
                text[76] = "H";
            }
            else if (color == 4)
            {
                button77.BackColor = Color.Yellow;
                text[76] = "F";
            }
            else if (color == 5)
            {
                button77.BackColor = Color.MidnightBlue;
                text[76] = "O";
            }
            else if (color == 6)
            {
                button77.BackColor = Color.Magenta;
                text[76] = "C";
            }
        }

        private void button78_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button78.BackColor = Color.Green;
                text[77] = "W";
            }
            else if (color == 2)
            {
                button78.BackColor = Color.Red;
                text[77] = "E";
            }
            else if (color == 3)
            {
                button78.BackColor = Color.Blue;
                text[77] = "H";
            }
            else if (color == 4)
            {
                button78.BackColor = Color.Yellow;
                text[77] = "F";
            }
            else if (color == 5)
            {
                button78.BackColor = Color.MidnightBlue;
                text[77] = "O";
            }
            else if (color == 6)
            {
                button78.BackColor = Color.Magenta;
                text[77] = "C";
            }
        }

        private void button79_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button79.BackColor = Color.Green;
                text[78] = "W";
            }
            else if (color == 2)
            {
                button79.BackColor = Color.Red;
                text[78] = "E";
            }
            else if (color == 3)
            {
                button79.BackColor = Color.Blue;
                text[78] = "H";
            }
            else if (color == 4)
            {
                button79.BackColor = Color.Yellow;
                text[78] = "F";
            }
            else if (color == 5)
            {
                button79.BackColor = Color.MidnightBlue;
                text[78] = "O";
            }
            else if (color == 6)
            {
                button79.BackColor = Color.Magenta;
                text[78] = "C";
            }
        }

        private void button80_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button80.BackColor = Color.Green;
                text[79] = "W";
            }
            else if (color == 2)
            {
                button80.BackColor = Color.Red;
                text[79] = "E";
            }
            else if (color == 3)
            {
                button80.BackColor = Color.Blue;
                text[79] = "H";
            }
            else if (color == 4)
            {
                button80.BackColor = Color.Yellow;
                text[79] = "F";
            }
            else if (color == 5)
            {
                button80.BackColor = Color.MidnightBlue;
                text[79] = "O";
            }
            else if (color == 6)
            {
                button80.BackColor = Color.Magenta;
                text[79] = "C";
            }
        }

        private void button81_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button81.BackColor = Color.Green;
                text[80] = "W";
            }
            else if (color == 2)
            {
                button81.BackColor = Color.Red;
                text[80] = "E";
            }
            else if (color == 3)
            {
                button81.BackColor = Color.Blue;
                text[80] = "H";
            }
            else if (color == 4)
            {
                button81.BackColor = Color.Yellow;
                text[80] = "F";
            }
            else if (color == 5)
            {
                button81.BackColor = Color.MidnightBlue;
                text[80] = "O";
            }
            else if (color == 6)
            {
                button81.BackColor = Color.Magenta;
                text[80] = "C";
            }
        }

        private void button82_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button82.BackColor = Color.Green;
                text[81] = "W";
            }
            else if (color == 2)
            {
                button82.BackColor = Color.Red;
                text[81] = "E";
            }
            else if (color == 3)
            {
                button82.BackColor = Color.Blue;
                text[81] = "H";
            }
            else if (color == 4)
            {
                button82.BackColor = Color.Yellow;
                text[81] = "F";
            }
            else if (color == 5)
            {
                button82.BackColor = Color.MidnightBlue;
                text[81] = "O";
            }
            else if (color == 6)
            {
                button82.BackColor = Color.Magenta;
                text[81] = "C";
            }
        }

        private void button83_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button83.BackColor = Color.Green;
                text[82] = "W";
            }
            else if (color == 2)
            {
                button83.BackColor = Color.Red;
                text[82] = "E";
            }
            else if (color == 3)
            {
                button83.BackColor = Color.Blue;
                text[82] = "H";
            }
            else if (color == 4)
            {
                button83.BackColor = Color.Yellow;
                text[82] = "F";
            }
            else if (color == 5)
            {
                button83.BackColor = Color.MidnightBlue;
                text[82] = "O";
            }
            else if (color == 6)
            {
                button83.BackColor = Color.Magenta;
                text[82] = "C";
            }
        }

        private void button84_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button84.BackColor = Color.Green;
                text[83] = "W";
            }
            else if (color == 2)
            {
                button84.BackColor = Color.Red;
                text[83] = "E";
            }
            else if (color == 3)
            {
                button84.BackColor = Color.Blue;
                text[83] = "H";
            }
            else if (color == 4)
            {
                button84.BackColor = Color.Yellow;
                text[83] = "F";
            }
            else if (color == 5)
            {
                button84.BackColor = Color.MidnightBlue;
                text[83] = "O";
            }
            else if (color == 6)
            {
                button84.BackColor = Color.Magenta;
                text[83] = "C";
            }
        }

        private void button85_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button85.BackColor = Color.Green;
                text[84] = "W";
            }
            else if (color == 2)
            {
                button85.BackColor = Color.Red;
                text[84] = "E";
            }
            else if (color == 3)
            {
                button85.BackColor = Color.Blue;
                text[84] = "H";
            }
            else if (color == 4)
            {
                button85.BackColor = Color.Yellow;
                text[84] = "F";
            }
            else if (color == 5)
            {
                button85.BackColor = Color.MidnightBlue;
                text[84] = "O";
            }
            else if (color == 6)
            {
                button85.BackColor = Color.Magenta;
                text[84] = "C";
            }
        }

        private void button86_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button86.BackColor = Color.Green;
                text[85] = "W";
            }
            else if (color == 2)
            {
                button86.BackColor = Color.Red;
                text[85] = "E";
            }
            else if (color == 3)
            {
                button86.BackColor = Color.Blue;
                text[85] = "H";
            }
            else if (color == 4)
            {
                button86.BackColor = Color.Yellow;
                text[85] = "F";
            }
            else if (color == 5)
            {
                button86.BackColor = Color.MidnightBlue;
                text[85] = "O";
            }
            else if (color == 6)
            {
                button86.BackColor = Color.Magenta;
                text[85] = "C";
            }
        }

        private void button87_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button87.BackColor = Color.Green;
                text[86] = "W";
            }
            else if (color == 2)
            {
                button87.BackColor = Color.Red;
                text[86] = "E";
            }
            else if (color == 3)
            {
                button87.BackColor = Color.Blue;
                text[86] = "H";
            }
            else if (color == 4)
            {
                button87.BackColor = Color.Yellow;
                text[86] = "F";
            }
            else if (color == 5)
            {
                button87.BackColor = Color.MidnightBlue;
                text[86] = "O";
            }
            else if (color == 6)
            {
                button87.BackColor = Color.Magenta;
                text[86] = "C";
            }
        }

        private void button88_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button88.BackColor = Color.Green;
                text[87] = "W";
            }
            else if (color == 2)
            {
                button88.BackColor = Color.Red;
                text[87] = "E";
            }
            else if (color == 3)
            {
                button88.BackColor = Color.Blue;
                text[87] = "H";
            }
            else if (color == 4)
            {
                button88.BackColor = Color.Yellow;
                text[87] = "F";
            }
            else if (color == 5)
            {
                button88.BackColor = Color.MidnightBlue;
                text[87] = "O";
            }
            else if (color == 6)
            {
                button88.BackColor = Color.Magenta;
                text[87] = "C";
            }
        }

        private void button89_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button89.BackColor = Color.Green;
                text[88] = "W";
            }
            else if (color == 2)
            {
                button89.BackColor = Color.Red;
                text[88] = "E";
            }
            else if (color == 3)
            {
                button89.BackColor = Color.Blue;
                text[88] = "H";
            }
            else if (color == 4)
            {
                button89.BackColor = Color.Yellow;
                text[88] = "F";
            }
            else if (color == 5)
            {
                button89.BackColor = Color.MidnightBlue;
                text[88] = "O";
            }
            else if (color == 6)
            {
                button89.BackColor = Color.Magenta;
                text[88] = "C";
            }
        }

        private void button90_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button90.BackColor = Color.Green;
                text[89] = "W";
            }
            else if (color == 2)
            {
                button90.BackColor = Color.Red;
                text[89] = "E";
            }
            else if (color == 3)
            {
                button90.BackColor = Color.Blue;
                text[89] = "H";
            }
            else if (color == 4)
            {
                button90.BackColor = Color.Yellow;
                text[89] = "F";
            }
            else if (color == 5)
            {
                button90.BackColor = Color.MidnightBlue;
                text[89] = "O";
            }
            else if (color == 6)
            {
                button90.BackColor = Color.Magenta;
                text[89] = "C";
            }
        }

        private void button91_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button91.BackColor = Color.Green;
                text[90] = "W";
            }
            else if (color == 2)
            {
                button91.BackColor = Color.Red;
                text[90] = "E";
            }
            else if (color == 3)
            {
                button91.BackColor = Color.Blue;
                text[90] = "H";
            }
            else if (color == 4)
            {
                button91.BackColor = Color.Yellow;
                text[90] = "F";
            }
            else if (color == 5)
            {
                button91.BackColor = Color.MidnightBlue;
                text[90] = "O";
            }
            else if (color == 6)
            {
                button91.BackColor = Color.Magenta;
                text[90] = "C";
            }
        }

        private void button92_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button92.BackColor = Color.Green;
                text[91] = "W";
            }
            else if (color == 2)
            {
                button92.BackColor = Color.Red;
                text[91] = "E";
            }
            else if (color == 3)
            {
                button92.BackColor = Color.Blue;
                text[91] = "H";
            }
            else if (color == 4)
            {
                button92.BackColor = Color.Yellow;
                text[91] = "F";
            }
            else if (color == 5)
            {
                button92.BackColor = Color.MidnightBlue;
                text[91] = "O";
            }
            else if (color == 6)
            {
                button92.BackColor = Color.Magenta;
                text[91] = "C";
            }
        }

        private void button93_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button93.BackColor = Color.Green;
                text[92] = "W";
            }
            else if (color == 2)
            {
                button93.BackColor = Color.Red;
                text[92] = "E";
            }
            else if (color == 3)
            {
                button93.BackColor = Color.Blue;
                text[92] = "H";
            }
            else if (color == 4)
            {
                button93.BackColor = Color.Yellow;
                text[92] = "F";
            }
            else if (color == 5)
            {
                button93.BackColor = Color.MidnightBlue;
                text[92] = "O";
            }
            else if (color == 6)
            {
                button93.BackColor = Color.Magenta;
                text[92] = "C";
            }
        }

        private void button94_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button94.BackColor = Color.Green;
                text[93] = "W";
            }
            else if (color == 2)
            {
                button94.BackColor = Color.Red;
                text[93] = "E";
            }
            else if (color == 3)
            {
                button94.BackColor = Color.Blue;
                text[93] = "H";
            }
            else if (color == 4)
            {
                button94.BackColor = Color.Yellow;
                text[93] = "F";
            }
            else if (color == 5)
            {
                button94.BackColor = Color.MidnightBlue;
                text[93] = "O";
            }
            else if (color == 6)
            {
                button94.BackColor = Color.Magenta;
                text[93] = "C";
            }
        }

        private void button95_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button95.BackColor = Color.Green;
                text[94] = "W";
            }
            else if (color == 2)
            {
                button95.BackColor = Color.Red;
                text[94] = "E";
            }
            else if (color == 3)
            {
                button95.BackColor = Color.Blue;
                text[94] = "H";
            }
            else if (color == 4)
            {
                button95.BackColor = Color.Yellow;
                text[94] = "F";
            }
            else if (color == 5)
            {
                button95.BackColor = Color.MidnightBlue;
                text[94] = "O";
            }
            else if (color == 6)
            {
                button95.BackColor = Color.Magenta;
                text[94] = "C";
            }
        }

        private void button96_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button96.BackColor = Color.Green;
                text[95] = "W";
            }
            else if (color == 2)
            {
                button96.BackColor = Color.Red;
                text[95] = "E";
            }
            else if (color == 3)
            {
                button96.BackColor = Color.Blue;
                text[95] = "H";
            }
            else if (color == 4)
            {
                button96.BackColor = Color.Yellow;
                text[95] = "F";
            }
            else if (color == 5)
            {
                button96.BackColor = Color.MidnightBlue;
                text[95] = "O";
            }
            else if (color == 6)
            {
                button96.BackColor = Color.Magenta;
                text[95] = "C";
            }
        }
        #endregion

        #region Center Code
        private void button97_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button97.BackColor = Color.Green;
                text[96] = "W";
            }
            else if (color == 2)
            {
                button97.BackColor = Color.Red;
                text[96] = "E";
            }
            else if (color == 3)
            {
                button97.BackColor = Color.Blue;
                text[96] = "H";
            }
            else if (color == 4)
            {
                button97.BackColor = Color.Yellow;
                text[96] = "F";
            }
            else if (color == 5)
            {
                button97.BackColor = Color.MidnightBlue;
                text[96] = "O";
            }
            else if (color == 6)
            {
                button97.BackColor = Color.Magenta;
                text[96] = "C";
            }
        }

        private void button98_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button98.BackColor = Color.Green;
                text[97] = "W";
            }
            else if (color == 2)
            {
                button98.BackColor = Color.Red;
                text[97] = "E";
            }
            else if (color == 3)
            {
                button98.BackColor = Color.Blue;
                text[97] = "H";
            }
            else if (color == 4)
            {
                button98.BackColor = Color.Yellow;
                text[97] = "F";
            }
            else if (color == 5)
            {
                button98.BackColor = Color.MidnightBlue;
                text[97] = "O";
            }
            else if (color == 6)
            {
                button98.BackColor = Color.Magenta;
                text[97] = "C";
            }
        }

        private void button99_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button99.BackColor = Color.Green;
                text[98] = "W";
            }
            else if (color == 2)
            {
                button99.BackColor = Color.Red;
                text[98] = "E";
            }
            else if (color == 3)
            {
                button99.BackColor = Color.Blue;
                text[98] = "H";
            }
            else if (color == 4)
            {
                button99.BackColor = Color.Yellow;
                text[98] = "F";
            }
            else if (color == 5)
            {
                button99.BackColor = Color.MidnightBlue;
                text[98] = "O";
            }
            else if (color == 6)
            {
                button99.BackColor = Color.Magenta;
                text[98] = "C";
            }
        }

        private void button100_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button100.BackColor = Color.Green;
                text[99] = "W";
            }
            else if (color == 2)
            {
                button100.BackColor = Color.Red;
                text[99] = "E";
            }
            else if (color == 3)
            {
                button100.BackColor = Color.Blue;
                text[99] = "H";
            }
            else if (color == 4)
            {
                button100.BackColor = Color.Yellow;
                text[99] = "F";
            }
            else if (color == 5)
            {
                button100.BackColor = Color.MidnightBlue;
                text[99] = "O";
            }
            else if (color == 6)
            {
                button100.BackColor = Color.Magenta;
                text[99] = "C";
            }
        }

        private void button101_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button101.BackColor = Color.Green;
                text[100] = "W";
            }
            else if (color == 2)
            {
                button101.BackColor = Color.Red;
                text[100] = "E";
            }
            else if (color == 3)
            {
                button101.BackColor = Color.Blue;
                text[100] = "H";
            }
            else if (color == 4)
            {
                button101.BackColor = Color.Yellow;
                text[100] = "F";
            }
            else if (color == 5)
            {
                button101.BackColor = Color.MidnightBlue;
                text[100] = "O";
            }
            else if (color == 6)
            {
                button101.BackColor = Color.Magenta;
                text[100] = "C";
            }
        }

        private void button102_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button102.BackColor = Color.Green;
                text[101] = "W";
            }
            else if (color == 2)
            {
                button102.BackColor = Color.Red;
                text[101] = "E";
            }
            else if (color == 3)
            {
                button102.BackColor = Color.Blue;
                text[101] = "H";
            }
            else if (color == 4)
            {
                button102.BackColor = Color.Yellow;
                text[101] = "F";
            }
            else if (color == 5)
            {
                button102.BackColor = Color.MidnightBlue;
                text[101] = "O";
            }
            else if (color == 6)
            {
                button102.BackColor = Color.Magenta;
                text[101] = "C";
            }
        }

        private void button103_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button103.BackColor = Color.Green;
                text[102] = "W";
            }
            else if (color == 2)
            {
                button103.BackColor = Color.Red;
                text[102] = "E";
            }
            else if (color == 3)
            {
                button103.BackColor = Color.Blue;
                text[102] = "H";
            }
            else if (color == 4)
            {
                button103.BackColor = Color.Yellow;
                text[102] = "F";
            }
            else if (color == 5)
            {
                button103.BackColor = Color.MidnightBlue;
                text[102] = "O";
            }
            else if (color == 6)
            {
                button103.BackColor = Color.Magenta;
                text[102] = "C";
            }
        }

        private void button104_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button104.BackColor = Color.Green;
                text[103] = "W";
            }
            else if (color == 2)
            {
                button104.BackColor = Color.Red;
                text[103] = "E";
            }
            else if (color == 3)
            {
                button104.BackColor = Color.Blue;
                text[103] = "H";
            }
            else if (color == 4)
            {
                button104.BackColor = Color.Yellow;
                text[103] = "F";
            }
            else if (color == 5)
            {
                button104.BackColor = Color.MidnightBlue;
                text[103] = "O";
            }
            else if (color == 6)
            {
                button104.BackColor = Color.Magenta;
                text[103] = "C";
            }
        }

        private void button105_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button105.BackColor = Color.Green;
                text[104] = "W";
            }
            else if (color == 2)
            {
                button105.BackColor = Color.Red;
                text[104] = "E";
            }
            else if (color == 3)
            {
                button105.BackColor = Color.Blue;
                text[104] = "H";
            }
            else if (color == 4)
            {
                button105.BackColor = Color.Yellow;
                text[104] = "F";
            }
            else if (color == 5)
            {
                button105.BackColor = Color.MidnightBlue;
                text[104] = "O";
            }
            else if (color == 6)
            {
                button105.BackColor = Color.Magenta;
                text[104] = "C";
            }
        }

        private void button106_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button106.BackColor = Color.Green;
                text[105] = "W";
            }
            else if (color == 2)
            {
                button106.BackColor = Color.Red;
                text[105] = "E";
            }
            else if (color == 3)
            {
                button106.BackColor = Color.Blue;
                text[105] = "H";
            }
            else if (color == 4)
            {
                button106.BackColor = Color.Yellow;
                text[105] = "F";
            }
            else if (color == 5)
            {
                button106.BackColor = Color.MidnightBlue;
                text[105] = "O";
            }
            else if (color == 6)
            {
                button106.BackColor = Color.Magenta;
                text[105] = "C";
            }
        }

        private void button107_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button107.BackColor = Color.Green;
                text[106] = "W";
            }
            else if (color == 2)
            {
                button107.BackColor = Color.Red;
                text[106] = "E";
            }
            else if (color == 3)
            {
                button107.BackColor = Color.Blue;
                text[106] = "H";
            }
            else if (color == 4)
            {
                button107.BackColor = Color.Yellow;
                text[106] = "F";
            }
            else if (color == 5)
            {
                button107.BackColor = Color.MidnightBlue;
                text[106] = "O";
            }
            else if (color == 6)
            {
                button107.BackColor = Color.Magenta;
                text[106] = "C";
            }
        }

        private void button108_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button108.BackColor = Color.Green;
                text[107] = "W";
            }
            else if (color == 2)
            {
                button108.BackColor = Color.Red;
                text[107] = "E";
            }
            else if (color == 3)
            {
                button108.BackColor = Color.Blue;
                text[107] = "H";
            }
            else if (color == 4)
            {
                button108.BackColor = Color.Yellow;
                text[107] = "F";
            }
            else if (color == 5)
            {
                button108.BackColor = Color.MidnightBlue;
                text[107] = "O";
            }
            else if (color == 6)
            {
                button108.BackColor = Color.Magenta;
                text[107] = "C";
            }
        }

        private void button109_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button109.BackColor = Color.Green;
                text[108] = "W";
            }
            else if (color == 2)
            {
                button109.BackColor = Color.Red;
                text[108] = "E";
            }
            else if (color == 3)
            {
                button109.BackColor = Color.Blue;
                text[108] = "H";
            }
            else if (color == 4)
            {
                button109.BackColor = Color.Yellow;
                text[108] = "F";
            }
            else if (color == 5)
            {
                button109.BackColor = Color.MidnightBlue;
                text[108] = "O";
            }
            else if (color == 6)
            {
                button109.BackColor = Color.Magenta;
                text[108] = "C";
            }
        }

        private void button110_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button110.BackColor = Color.Green;
                text[109] = "W";
            }
            else if (color == 2)
            {
                button110.BackColor = Color.Red;
                text[109] = "E";
            }
            else if (color == 3)
            {
                button110.BackColor = Color.Blue;
                text[109] = "H";
            }
            else if (color == 4)
            {
                button110.BackColor = Color.Yellow;
                text[109] = "F";
            }
            else if (color == 5)
            {
                button110.BackColor = Color.MidnightBlue;
                text[109] = "O";
            }
            else if (color == 6)
            {
                button110.BackColor = Color.Magenta;
                text[109] = "C";
            }
        }

        private void button111_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button111.BackColor = Color.Green;
                text[110] = "W";
            }
            else if (color == 2)
            {
                button111.BackColor = Color.Red;
                text[110] = "E";
            }
            else if (color == 3)
            {
                button111.BackColor = Color.Blue;
                text[110] = "H";
            }
            else if (color == 4)
            {
                button111.BackColor = Color.Yellow;
                text[110] = "F";
            }
            else if (color == 5)
            {
                button111.BackColor = Color.MidnightBlue;
                text[110] = "O";
            }
            else if (color == 6)
            {
                button111.BackColor = Color.Magenta;
                text[110] = "C";
            }
        }

        private void button112_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button112.BackColor = Color.Green;
                text[111] = "W";
            }
            else if (color == 2)
            {
                button112.BackColor = Color.Red;
                text[111] = "E";
            }
            else if (color == 3)
            {
                button112.BackColor = Color.Blue;
                text[111] = "H";
            }
            else if (color == 4)
            {
                button112.BackColor = Color.Yellow;
                text[111] = "F";
            }
            else if (color == 5)
            {
                button112.BackColor = Color.MidnightBlue;
                text[111] = "O";
            }
            else if (color == 6)
            {
                button112.BackColor = Color.Magenta;
                text[111] = "C";
            }
        }

        private void button113_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button113.BackColor = Color.Green;
                text[112] = "W";
            }
            else if (color == 2)
            {
                button113.BackColor = Color.Red;
                text[112] = "E";
            }
            else if (color == 3)
            {
                button113.BackColor = Color.Blue;
                text[112] = "H";
            }
            else if (color == 4)
            {
                button113.BackColor = Color.Yellow;
                text[112] = "F";
            }
            else if (color == 5)
            {
                button113.BackColor = Color.MidnightBlue;
                text[112] = "O";
            }
            else if (color == 6)
            {
                button113.BackColor = Color.Magenta;
                text[112] = "C";
            }
        }

        private void button114_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button114.BackColor = Color.Green;
                text[113] = "W";
            }
            else if (color == 2)
            {
                button114.BackColor = Color.Red;
                text[113] = "E";
            }
            else if (color == 3)
            {
                button114.BackColor = Color.Blue;
                text[113] = "H";
            }
            else if (color == 4)
            {
                button114.BackColor = Color.Yellow;
                text[113] = "F";
            }
            else if (color == 5)
            {
                button114.BackColor = Color.MidnightBlue;
                text[113] = "O";
            }
            else if (color == 6)
            {
                button114.BackColor = Color.Magenta;
                text[113] = "C";
            }
        }

        private void button115_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button115.BackColor = Color.Green;
                text[114] = "W";
            }
            else if (color == 2)
            {
                button115.BackColor = Color.Red;
                text[114] = "E";
            }
            else if (color == 3)
            {
                button115.BackColor = Color.Blue;
                text[114] = "H";
            }
            else if (color == 4)
            {
                button115.BackColor = Color.Yellow;
                text[114] = "F";
            }
            else if (color == 5)
            {
                button115.BackColor = Color.MidnightBlue;
                text[114] = "O";
            }
            else if (color == 6)
            {
                button115.BackColor = Color.Magenta;
                text[114] = "C";
            }
        }

        private void button116_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button116.BackColor = Color.Green;
                text[115] = "W";
            }
            else if (color == 2)
            {
                button116.BackColor = Color.Red;
                text[115] = "E";
            }
            else if (color == 3)
            {
                button116.BackColor = Color.Blue;
                text[115] = "H";
            }
            else if (color == 4)
            {
                button116.BackColor = Color.Yellow;
                text[115] = "F";
            }
            else if (color == 5)
            {
                button116.BackColor = Color.MidnightBlue;
                text[115] = "O";
            }
            else if (color == 6)
            {
                button116.BackColor = Color.Magenta;
                text[115] = "C";
            }
        }

        private void button117_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button117.BackColor = Color.Green;
                text[116] = "W";
            }
            else if (color == 2)
            {
                button117.BackColor = Color.Red;
                text[116] = "E";
            }
            else if (color == 3)
            {
                button117.BackColor = Color.Blue;
                text[116] = "H";
            }
            else if (color == 4)
            {
                button117.BackColor = Color.Yellow;
                text[116] = "F";
            }
            else if (color == 5)
            {
                button117.BackColor = Color.MidnightBlue;
                text[116] = "O";
            }
            else if (color == 6)
            {
                button117.BackColor = Color.Magenta;
                text[116] = "C";
            }
        }

        private void button118_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button118.BackColor = Color.Green;
                text[117] = "W";
            }
            else if (color == 2)
            {
                button118.BackColor = Color.Red;
                text[117] = "E";
            }
            else if (color == 3)
            {
                button118.BackColor = Color.Blue;
                text[117] = "H";
            }
            else if (color == 4)
            {
                button118.BackColor = Color.Yellow;
                text[117] = "F";
            }
            else if (color == 5)
            {
                button118.BackColor = Color.MidnightBlue;
                text[117] = "O";
            }
            else if (color == 6)
            {
                button118.BackColor = Color.Magenta;
                text[117] = "C";
            }
        }

        private void button119_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button119.BackColor = Color.Green;
                text[118] = "W";
            }
            else if (color == 2)
            {
                button119.BackColor = Color.Red;
                text[118] = "E";
            }
            else if (color == 3)
            {
                button119.BackColor = Color.Blue;
                text[118] = "H";
            }
            else if (color == 4)
            {
                button119.BackColor = Color.Yellow;
                text[118] = "F";
            }
            else if (color == 5)
            {
                button119.BackColor = Color.MidnightBlue;
                text[118] = "O";
            }
            else if (color == 6)
            {
                button119.BackColor = Color.Magenta;
                text[118] = "C";
            }
        }

        private void button120_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button120.BackColor = Color.Green;
                text[119] = "W";
            }
            else if (color == 2)
            {
                button120.BackColor = Color.Red;
                text[119] = "E";
            }
            else if (color == 3)
            {
                button120.BackColor = Color.Blue;
                text[119] = "H";
            }
            else if (color == 4)
            {
                button120.BackColor = Color.Yellow;
                text[119] = "F";
            }
            else if (color == 5)
            {
                button120.BackColor = Color.MidnightBlue;
                text[119] = "O";
            }
            else if (color == 6)
            {
                button120.BackColor = Color.Magenta;
                text[119] = "C";
            }
        }

        private void button121_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button121.BackColor = Color.Green;
                text[120] = "W";
            }
            else if (color == 2)
            {
                button121.BackColor = Color.Red;
                text[120] = "E";
            }
            else if (color == 3)
            {
                button121.BackColor = Color.Blue;
                text[120] = "H";
            }
            else if (color == 4)
            {
                button121.BackColor = Color.Yellow;
                text[120] = "F";
            }
            else if (color == 5)
            {
                button121.BackColor = Color.MidnightBlue;
                text[120] = "O";
            }
            else if (color == 6)
            {
                button121.BackColor = Color.Magenta;
                text[120] = "C";
            }
        }

        private void button122_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button122.BackColor = Color.Green;
                text[121] = "W";
            }
            else if (color == 2)
            {
                button122.BackColor = Color.Red;
                text[121] = "E";
            }
            else if (color == 3)
            {
                button122.BackColor = Color.Blue;
                text[121] = "H";
            }
            else if (color == 4)
            {
                button122.BackColor = Color.Yellow;
                text[121] = "F";
            }
            else if (color == 5)
            {
                button122.BackColor = Color.MidnightBlue;
                text[121] = "O";
            }
            else if (color == 6)
            {
                button122.BackColor = Color.Magenta;
                text[121] = "C";
            }
        }

        private void button123_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button123.BackColor = Color.Green;
                text[122] = "W";
            }
            else if (color == 2)
            {
                button123.BackColor = Color.Red;
                text[122] = "E";
            }
            else if (color == 3)
            {
                button123.BackColor = Color.Blue;
                text[122] = "H";
            }
            else if (color == 4)
            {
                button123.BackColor = Color.Yellow;
                text[122] = "F";
            }
            else if (color == 5)
            {
                button123.BackColor = Color.MidnightBlue;
                text[122] = "O";
            }
            else if (color == 6)
            {
                button123.BackColor = Color.Magenta;
                text[122] = "C";
            }
        }

        private void button124_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button124.BackColor = Color.Green;
                text[123] = "W";
            }
            else if (color == 2)
            {
                button124.BackColor = Color.Red;
                text[123] = "E";
            }
            else if (color == 3)
            {
                button124.BackColor = Color.Blue;
                text[123] = "H";
            }
            else if (color == 4)
            {
                button124.BackColor = Color.Yellow;
                text[123] = "F";
            }
            else if (color == 5)
            {
                button124.BackColor = Color.MidnightBlue;
                text[123] = "O";
            }
            else if (color == 6)
            {
                button124.BackColor = Color.Magenta;
                text[123] = "C";
            }
        }

        private void button125_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button125.BackColor = Color.Green;
                text[124] = "W";
            }
            else if (color == 2)
            {
                button125.BackColor = Color.Red;
                text[124] = "E";
            }
            else if (color == 3)
            {
                button125.BackColor = Color.Blue;
                text[124] = "H";
            }
            else if (color == 4)
            {
                button125.BackColor = Color.Yellow;
                text[124] = "F";
            }
            else if (color == 5)
            {
                button125.BackColor = Color.MidnightBlue;
                text[124] = "O";
            }
            else if (color == 6)
            {
                button125.BackColor = Color.Magenta;
                text[124] = "C";
            }
        }

        private void button126_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button126.BackColor = Color.Green;
                text[125] = "W";
            }
            else if (color == 2)
            {
                button126.BackColor = Color.Red;
                text[125] = "E";
            }
            else if (color == 3)
            {
                button126.BackColor = Color.Blue;
                text[125] = "H";
            }
            else if (color == 4)
            {
                button126.BackColor = Color.Yellow;
                text[125] = "F";
            }
            else if (color == 5)
            {
                button126.BackColor = Color.MidnightBlue;
                text[125] = "O";
            }
            else if (color == 6)
            {
                button126.BackColor = Color.Magenta;
                text[125] = "C";
            }
        }

        private void button127_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button127.BackColor = Color.Green;
                text[126] = "W";
            }
            else if (color == 2)
            {
                button127.BackColor = Color.Red;
                text[126] = "E";
            }
            else if (color == 3)
            {
                button127.BackColor = Color.Blue;
                text[126] = "H";
            }
            else if (color == 4)
            {
                button127.BackColor = Color.Yellow;
                text[126] = "F";
            }
            else if (color == 5)
            {
                button127.BackColor = Color.MidnightBlue;
                text[126] = "O";
            }
            else if (color == 6)
            {
                button127.BackColor = Color.Magenta;
                text[126] = "C";
            }
        }

        private void button128_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button128.BackColor = Color.Green;
                text[127] = "W";
            }
            else if (color == 2)
            {
                button128.BackColor = Color.Red;
                text[127] = "E";
            }
            else if (color == 3)
            {
                button128.BackColor = Color.Blue;
                text[127] = "H";
            }
            else if (color == 4)
            {
                button128.BackColor = Color.Yellow;
                text[127] = "F";
            }
            else if (color == 5)
            {
                button128.BackColor = Color.MidnightBlue;
                text[127] = "O";
            }
            else if (color == 6)
            {
                button128.BackColor = Color.Magenta;
                text[127] = "C";
            }
        }

        private void button129_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button129.BackColor = Color.Green;
                text[128] = "W";
            }
            else if (color == 2)
            {
                button129.BackColor = Color.Red;
                text[128] = "E";
            }
            else if (color == 3)
            {
                button129.BackColor = Color.Blue;
                text[128] = "H";
            }
            else if (color == 4)
            {
                button129.BackColor = Color.Yellow;
                text[128] = "F";
            }
            else if (color == 5)
            {
                button129.BackColor = Color.MidnightBlue;
                text[128] = "O";
            }
            else if (color == 6)
            {
                button129.BackColor = Color.Magenta;
                text[128] = "C";
            }
        }

        private void button130_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button130.BackColor = Color.Green;
                text[129] = "W";
            }
            else if (color == 2)
            {
                button130.BackColor = Color.Red;
                text[129] = "E";
            }
            else if (color == 3)
            {
                button130.BackColor = Color.Blue;
                text[129] = "H";
            }
            else if (color == 4)
            {
                button130.BackColor = Color.Yellow;
                text[129] = "F";
            }
            else if (color == 5)
            {
                button130.BackColor = Color.MidnightBlue;
                text[129] = "O";
            }
            else if (color == 6)
            {
                button130.BackColor = Color.Magenta;
                text[129] = "C";
            }
        }

        private void button131_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button131.BackColor = Color.Green;
                text[130] = "W";
            }
            else if (color == 2)
            {
                button131.BackColor = Color.Red;
                text[130] = "E";
            }
            else if (color == 3)
            {
                button131.BackColor = Color.Blue;
                text[130] = "H";
            }
            else if (color == 4)
            {
                button131.BackColor = Color.Yellow;
                text[130] = "F";
            }
            else if (color == 5)
            {
                button131.BackColor = Color.MidnightBlue;
                text[130] = "O";
            }
            else if (color == 6)
            {
                button131.BackColor = Color.Magenta;
                text[130] = "C";
            }
        }

        private void button132_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button132.BackColor = Color.Green;
                text[131] = "W";
            }
            else if (color == 2)
            {
                button132.BackColor = Color.Red;
                text[131] = "E";
            }
            else if (color == 3)
            {
                button132.BackColor = Color.Blue;
                text[131] = "H";
            }
            else if (color == 4)
            {
                button132.BackColor = Color.Yellow;
                text[131] = "F";
            }
            else if (color == 5)
            {
                button132.BackColor = Color.MidnightBlue;
                text[131] = "O";
            }
            else if (color == 6)
            {
                button132.BackColor = Color.Magenta;
                text[131] = "C";
            }
        }

        private void button133_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button133.BackColor = Color.Green;
                text[132] = "W";
            }
            else if (color == 2)
            {
                button133.BackColor = Color.Red;
                text[132] = "E";
            }
            else if (color == 3)
            {
                button133.BackColor = Color.Blue;
                text[132] = "H";
            }
            else if (color == 4)
            {
                button133.BackColor = Color.Yellow;
                text[132] = "F";
            }
            else if (color == 5)
            {
                button133.BackColor = Color.MidnightBlue;
                text[132] = "O";
            }
            else if (color == 6)
            {
                button133.BackColor = Color.Magenta;
                text[132] = "C";
            }
        }

        private void button134_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button134.BackColor = Color.Green;
                text[133] = "W";
            }
            else if (color == 2)
            {
                button134.BackColor = Color.Red;
                text[133] = "E";
            }
            else if (color == 3)
            {
                button134.BackColor = Color.Blue;
                text[133] = "H";
            }
            else if (color == 4)
            {
                button134.BackColor = Color.Yellow;
                text[133] = "F";
            }
            else if (color == 5)
            {
                button134.BackColor = Color.MidnightBlue;
                text[133] = "O";
            }
            else if (color == 6)
            {
                button134.BackColor = Color.Magenta;
                text[133] = "C";
            }
        }

        private void button135_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button135.BackColor = Color.Green;
                text[134] = "W";
            }
            else if (color == 2)
            {
                button135.BackColor = Color.Red;
                text[134] = "E";
            }
            else if (color == 3)
            {
                button135.BackColor = Color.Blue;
                text[134] = "H";
            }
            else if (color == 4)
            {
                button135.BackColor = Color.Yellow;
                text[134] = "F";
            }
            else if (color == 5)
            {
                button135.BackColor = Color.MidnightBlue;
                text[134] = "O";
            }
            else if (color == 6)
            {
                button135.BackColor = Color.Magenta;
                text[134] = "C";
            }
        }

        private void button136_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button136.BackColor = Color.Green;
                text[135] = "W";
            }
            else if (color == 2)
            {
                button136.BackColor = Color.Red;
                text[135] = "E";
            }
            else if (color == 3)
            {
                button136.BackColor = Color.Blue;
                text[135] = "H";
            }
            else if (color == 4)
            {
                button136.BackColor = Color.Yellow;
                text[135] = "F";
            }
            else if (color == 5)
            {
                button136.BackColor = Color.MidnightBlue;
                text[135] = "O";
            }
            else if (color == 6)
            {
                button136.BackColor = Color.Magenta;
                text[135] = "C";
            }
        }

        private void button137_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button137.BackColor = Color.Green;
                text[136] = "W";
            }
            else if (color == 2)
            {
                button137.BackColor = Color.Red;
                text[136] = "E";
            }
            else if (color == 3)
            {
                button137.BackColor = Color.Blue;
                text[136] = "H";
            }
            else if (color == 4)
            {
                button137.BackColor = Color.Yellow;
                text[136] = "F";
            }
            else if (color == 5)
            {
                button137.BackColor = Color.MidnightBlue;
                text[136] = "O";
            }
            else if (color == 6)
            {
                button137.BackColor = Color.Magenta;
                text[136] = "C";
            }
        }

        private void button138_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button138.BackColor = Color.Green;
                text[137] = "W";
            }
            else if (color == 2)
            {
                button138.BackColor = Color.Red;
                text[137] = "E";
            }
            else if (color == 3)
            {
                button138.BackColor = Color.Blue;
                text[137] = "H";
            }
            else if (color == 4)
            {
                button138.BackColor = Color.Yellow;
                text[137] = "F";
            }
            else if (color == 5)
            {
                button138.BackColor = Color.MidnightBlue;
                text[137] = "O";
            }
            else if (color == 6)
            {
                button138.BackColor = Color.Magenta;
                text[137] = "C";
            }
        }

        private void button139_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button139.BackColor = Color.Green;
                text[138] = "W";
            }
            else if (color == 2)
            {
                button139.BackColor = Color.Red;
                text[138] = "E";
            }
            else if (color == 3)
            {
                button139.BackColor = Color.Blue;
                text[138] = "H";
            }
            else if (color == 4)
            {
                button139.BackColor = Color.Yellow;
                text[138] = "F";
            }
            else if (color == 5)
            {
                button139.BackColor = Color.MidnightBlue;
                text[138] = "O";
            }
            else if (color == 6)
            {
                button139.BackColor = Color.Magenta;
                text[138] = "C";
            }
        }

        private void button140_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button140.BackColor = Color.Green;
                text[139] = "W";
            }
            else if (color == 2)
            {
                button140.BackColor = Color.Red;
                text[139] = "E";
            }
            else if (color == 3)
            {
                button140.BackColor = Color.Blue;
                text[139] = "H";
            }
            else if (color == 4)
            {
                button140.BackColor = Color.Yellow;
                text[139] = "F";
            }
            else if (color == 5)
            {
                button140.BackColor = Color.MidnightBlue;
                text[139] = "O";
            }
            else if (color == 6)
            {
                button140.BackColor = Color.Magenta;
                text[139] = "C";
            }
        }

        private void button141_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button141.BackColor = Color.Green;
                text[140] = "W";
            }
            else if (color == 2)
            {
                button141.BackColor = Color.Red;
                text[140] = "E";
            }
            else if (color == 3)
            {
                button141.BackColor = Color.Blue;
                text[140] = "H";
            }
            else if (color == 4)
            {
                button141.BackColor = Color.Yellow;
                text[140] = "F";
            }
            else if (color == 5)
            {
                button141.BackColor = Color.MidnightBlue;
                text[140] = "O";
            }
            else if (color == 6)
            {
                button141.BackColor = Color.Magenta;
                text[140] = "C";
            }
        }

        private void button142_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button142.BackColor = Color.Green;
                text[141] = "W";
            }
            else if (color == 2)
            {
                button142.BackColor = Color.Red;
                text[141] = "E";
            }
            else if (color == 3)
            {
                button142.BackColor = Color.Blue;
                text[141] = "H";
            }
            else if (color == 4)
            {
                button142.BackColor = Color.Yellow;
                text[141] = "F";
            }
            else if (color == 5)
            {
                button142.BackColor = Color.MidnightBlue;
                text[141] = "O";
            }
            else if (color == 6)
            {
                button142.BackColor = Color.Magenta;
                text[141] = "C";
            }
        }

        private void button143_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button143.BackColor = Color.Green;
                text[142] = "W";
            }
            else if (color == 2)
            {
                button143.BackColor = Color.Red;
                text[142] = "E";
            }
            else if (color == 3)
            {
                button143.BackColor = Color.Blue;
                text[142] = "H";
            }
            else if (color == 4)
            {
                button143.BackColor = Color.Yellow;
                text[142] = "F";
            }
            else if (color == 5)
            {
                button143.BackColor = Color.MidnightBlue;
                text[142] = "O";
            }
            else if (color == 6)
            {
                button143.BackColor = Color.Magenta;
                text[142] = "C";
            }
        }

        private void button144_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button144.BackColor = Color.Green;
                text[143] = "W";
            }
            else if (color == 2)
            {
                button144.BackColor = Color.Red;
                text[143] = "E";
            }
            else if (color == 3)
            {
                button144.BackColor = Color.Blue;
                text[143] = "H";
            }
            else if (color == 4)
            {
                button144.BackColor = Color.Yellow;
                text[143] = "F";
            }
            else if (color == 5)
            {
                button144.BackColor = Color.MidnightBlue;
                text[143] = "O";
            }
            else if (color == 6)
            {
                button144.BackColor = Color.Magenta;
                text[143] = "C";
            }
        }
        #endregion

        #region Down 1 Code
        private void button145_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button145.BackColor = Color.Green;
                text[144] = "W";
            }
            else if (color == 2)
            {
                button145.BackColor = Color.Red;
                text[144] = "E";
            }
            else if (color == 3)
            {
                button145.BackColor = Color.Blue;
                text[144] = "H";
            }
            else if (color == 4)
            {
                button145.BackColor = Color.Yellow;
                text[144] = "F";
            }
            else if (color == 5)
            {
                button145.BackColor = Color.MidnightBlue;
                text[144] = "O";
            }
            else if (color == 6)
            {
                button145.BackColor = Color.Magenta;
                text[144] = "C";
            }
        }

        private void button146_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button146.BackColor = Color.Green;
                text[145] = "W";
            }
            else if (color == 2)
            {
                button146.BackColor = Color.Red;
                text[145] = "E";
            }
            else if (color == 3)
            {
                button146.BackColor = Color.Blue;
                text[145] = "H";
            }
            else if (color == 4)
            {
                button146.BackColor = Color.Yellow;
                text[145] = "F";
            }
            else if (color == 5)
            {
                button146.BackColor = Color.MidnightBlue;
                text[145] = "O";
            }
            else if (color == 6)
            {
                button146.BackColor = Color.Magenta;
                text[145] = "C";
            }
        }

        private void button147_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button147.BackColor = Color.Green;
                text[146] = "W";
            }
            else if (color == 2)
            {
                button147.BackColor = Color.Red;
                text[146] = "E";
            }
            else if (color == 3)
            {
                button147.BackColor = Color.Blue;
                text[146] = "H";
            }
            else if (color == 4)
            {
                button147.BackColor = Color.Yellow;
                text[146] = "F";
            }
            else if (color == 5)
            {
                button147.BackColor = Color.MidnightBlue;
                text[146] = "O";
            }
            else if (color == 6)
            {
                button147.BackColor = Color.Magenta;
                text[146] = "C";
            }
        }

        private void button148_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button148.BackColor = Color.Green;
                text[147] = "W";
            }
            else if (color == 2)
            {
                button148.BackColor = Color.Red;
                text[147] = "E";
            }
            else if (color == 3)
            {
                button148.BackColor = Color.Blue;
                text[147] = "H";
            }
            else if (color == 4)
            {
                button148.BackColor = Color.Yellow;
                text[147] = "F";
            }
            else if (color == 5)
            {
                button148.BackColor = Color.MidnightBlue;
                text[147] = "O";
            }
            else if (color == 6)
            {
                button148.BackColor = Color.Magenta;
                text[147] = "C";
            }
        }

        private void button149_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button149.BackColor = Color.Green;
                text[148] = "W";
            }
            else if (color == 2)
            {
                button149.BackColor = Color.Red;
                text[148] = "E";
            }
            else if (color == 3)
            {
                button149.BackColor = Color.Blue;
                text[148] = "H";
            }
            else if (color == 4)
            {
                button149.BackColor = Color.Yellow;
                text[148] = "F";
            }
            else if (color == 5)
            {
                button149.BackColor = Color.MidnightBlue;
                text[148] = "O";
            }
            else if (color == 6)
            {
                button149.BackColor = Color.Magenta;
                text[148] = "C";
            }
        }

        private void button150_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button150.BackColor = Color.Green;
                text[149] = "W";
            }
            else if (color == 2)
            {
                button150.BackColor = Color.Red;
                text[149] = "E";
            }
            else if (color == 3)
            {
                button150.BackColor = Color.Blue;
                text[149] = "H";
            }
            else if (color == 4)
            {
                button150.BackColor = Color.Yellow;
                text[149] = "F";
            }
            else if (color == 5)
            {
                button150.BackColor = Color.MidnightBlue;
                text[149] = "O";
            }
            else if (color == 6)
            {
                button150.BackColor = Color.Magenta;
                text[149] = "C";
            }
        }

        private void button151_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button151.BackColor = Color.Green;
                text[150] = "W";
            }
            else if (color == 2)
            {
                button151.BackColor = Color.Red;
                text[150] = "E";
            }
            else if (color == 3)
            {
                button151.BackColor = Color.Blue;
                text[150] = "H";
            }
            else if (color == 4)
            {
                button151.BackColor = Color.Yellow;
                text[150] = "F";
            }
            else if (color == 5)
            {
                button151.BackColor = Color.MidnightBlue;
                text[150] = "O";
            }
            else if (color == 6)
            {
                button151.BackColor = Color.Magenta;
                text[150] = "C";
            }
        }

        private void button152_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button152.BackColor = Color.Green;
                text[151] = "W";
            }
            else if (color == 2)
            {
                button152.BackColor = Color.Red;
                text[151] = "E";
            }
            else if (color == 3)
            {
                button152.BackColor = Color.Blue;
                text[151] = "H";
            }
            else if (color == 4)
            {
                button152.BackColor = Color.Yellow;
                text[151] = "F";
            }
            else if (color == 5)
            {
                button152.BackColor = Color.MidnightBlue;
                text[151] = "O";
            }
            else if (color == 6)
            {
                button152.BackColor = Color.Magenta;
                text[151] = "C";
            }
        }

        private void button153_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button153.BackColor = Color.Green;
                text[152] = "W";
            }
            else if (color == 2)
            {
                button153.BackColor = Color.Red;
                text[152] = "E";
            }
            else if (color == 3)
            {
                button153.BackColor = Color.Blue;
                text[152] = "H";
            }
            else if (color == 4)
            {
                button153.BackColor = Color.Yellow;
                text[152] = "F";
            }
            else if (color == 5)
            {
                button153.BackColor = Color.MidnightBlue;
                text[152] = "O";
            }
            else if (color == 6)
            {
                button153.BackColor = Color.Magenta;
                text[152] = "C";
            }
        }

        private void button154_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button154.BackColor = Color.Green;
                text[153] = "W";
            }
            else if (color == 2)
            {
                button154.BackColor = Color.Red;
                text[153] = "E";
            }
            else if (color == 3)
            {
                button154.BackColor = Color.Blue;
                text[153] = "H";
            }
            else if (color == 4)
            {
                button154.BackColor = Color.Yellow;
                text[153] = "F";
            }
            else if (color == 5)
            {
                button154.BackColor = Color.MidnightBlue;
                text[153] = "O";
            }
            else if (color == 6)
            {
                button154.BackColor = Color.Magenta;
                text[153] = "C";
            }
        }

        private void button155_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button155.BackColor = Color.Green;
                text[154] = "W";
            }
            else if (color == 2)
            {
                button155.BackColor = Color.Red;
                text[154] = "E";
            }
            else if (color == 3)
            {
                button155.BackColor = Color.Blue;
                text[154] = "H";
            }
            else if (color == 4)
            {
                button155.BackColor = Color.Yellow;
                text[154] = "F";
            }
            else if (color == 5)
            {
                button155.BackColor = Color.MidnightBlue;
                text[154] = "O";
            }
            else if (color == 6)
            {
                button155.BackColor = Color.Magenta;
                text[154] = "C";
            }
        }

        private void button156_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button156.BackColor = Color.Green;
                text[155] = "W";
            }
            else if (color == 2)
            {
                button156.BackColor = Color.Red;
                text[155] = "E";
            }
            else if (color == 3)
            {
                button156.BackColor = Color.Blue;
                text[155] = "H";
            }
            else if (color == 4)
            {
                button156.BackColor = Color.Yellow;
                text[155] = "F";
            }
            else if (color == 5)
            {
                button156.BackColor = Color.MidnightBlue;
                text[155] = "O";
            }
            else if (color == 6)
            {
                button156.BackColor = Color.Magenta;
                text[155] = "C";
            }
        }

        private void button157_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button157.BackColor = Color.Green;
                text[156] = "W";
            }
            else if (color == 2)
            {
                button157.BackColor = Color.Red;
                text[156] = "E";
            }
            else if (color == 3)
            {
                button157.BackColor = Color.Blue;
                text[156] = "H";
            }
            else if (color == 4)
            {
                button157.BackColor = Color.Yellow;
                text[156] = "F";
            }
            else if (color == 5)
            {
                button157.BackColor = Color.MidnightBlue;
                text[156] = "O";
            }
            else if (color == 6)
            {
                button157.BackColor = Color.Magenta;
                text[156] = "C";
            }
        }

        private void button158_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button158.BackColor = Color.Green;
                text[157] = "W";
            }
            else if (color == 2)
            {
                button158.BackColor = Color.Red;
                text[157] = "E";
            }
            else if (color == 3)
            {
                button158.BackColor = Color.Blue;
                text[157] = "H";
            }
            else if (color == 4)
            {
                button158.BackColor = Color.Yellow;
                text[157] = "F";
            }
            else if (color == 5)
            {
                button158.BackColor = Color.MidnightBlue;
                text[157] = "O";
            }
            else if (color == 6)
            {
                button158.BackColor = Color.Magenta;
                text[157] = "C";
            }
        }

        private void button159_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button159.BackColor = Color.Green;
                text[158] = "W";
            }
            else if (color == 2)
            {
                button159.BackColor = Color.Red;
                text[158] = "E";
            }
            else if (color == 3)
            {
                button159.BackColor = Color.Blue;
                text[158] = "H";
            }
            else if (color == 4)
            {
                button159.BackColor = Color.Yellow;
                text[158] = "F";
            }
            else if (color == 5)
            {
                button159.BackColor = Color.MidnightBlue;
                text[158] = "O";
            }
            else if (color == 6)
            {
                button159.BackColor = Color.Magenta;
                text[158] = "C";
            }
        }

        private void button160_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button160.BackColor = Color.Green;
                text[159] = "W";
            }
            else if (color == 2)
            {
                button160.BackColor = Color.Red;
                text[159] = "E";
            }
            else if (color == 3)
            {
                button160.BackColor = Color.Blue;
                text[159] = "H";
            }
            else if (color == 4)
            {
                button160.BackColor = Color.Yellow;
                text[159] = "F";
            }
            else if (color == 5)
            {
                button160.BackColor = Color.MidnightBlue;
                text[159] = "O";
            }
            else if (color == 6)
            {
                button160.BackColor = Color.Magenta;
                text[159] = "C";
            }
        }

        private void button161_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button161.BackColor = Color.Green;
                text[160] = "W";
            }
            else if (color == 2)
            {
                button161.BackColor = Color.Red;
                text[160] = "E";
            }
            else if (color == 3)
            {
                button161.BackColor = Color.Blue;
                text[160] = "H";
            }
            else if (color == 4)
            {
                button161.BackColor = Color.Yellow;
                text[160] = "F";
            }
            else if (color == 5)
            {
                button161.BackColor = Color.MidnightBlue;
                text[160] = "O";
            }
            else if (color == 6)
            {
                button161.BackColor = Color.Magenta;
                text[160] = "C";
            }
        }

        private void button162_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button162.BackColor = Color.Green;
                text[161] = "W";
            }
            else if (color == 2)
            {
                button162.BackColor = Color.Red;
                text[161] = "E";
            }
            else if (color == 3)
            {
                button162.BackColor = Color.Blue;
                text[161] = "H";
            }
            else if (color == 4)
            {
                button162.BackColor = Color.Yellow;
                text[161] = "F";
            }
            else if (color == 5)
            {
                button162.BackColor = Color.MidnightBlue;
                text[161] = "O";
            }
            else if (color == 6)
            {
                button162.BackColor = Color.Magenta;
                text[161] = "C";
            }
        }

        private void button163_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button163.BackColor = Color.Green;
                text[162] = "W";
            }
            else if (color == 2)
            {
                button163.BackColor = Color.Red;
                text[162] = "E";
            }
            else if (color == 3)
            {
                button163.BackColor = Color.Blue;
                text[162] = "H";
            }
            else if (color == 4)
            {
                button163.BackColor = Color.Yellow;
                text[162] = "F";
            }
            else if (color == 5)
            {
                button163.BackColor = Color.MidnightBlue;
                text[162] = "O";
            }
            else if (color == 6)
            {
                button163.BackColor = Color.Magenta;
                text[162] = "C";
            }
        }

        private void button164_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button164.BackColor = Color.Green;
                text[163] = "W";
            }
            else if (color == 2)
            {
                button164.BackColor = Color.Red;
                text[163] = "E";
            }
            else if (color == 3)
            {
                button164.BackColor = Color.Blue;
                text[163] = "H";
            }
            else if (color == 4)
            {
                button164.BackColor = Color.Yellow;
                text[163] = "F";
            }
            else if (color == 5)
            {
                button164.BackColor = Color.MidnightBlue;
                text[163] = "O";
            }
            else if (color == 6)
            {
                button164.BackColor = Color.Magenta;
                text[163] = "C";
            }
        }

        private void button165_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button165.BackColor = Color.Green;
                text[164] = "W";
            }
            else if (color == 2)
            {
                button165.BackColor = Color.Red;
                text[164] = "E";
            }
            else if (color == 3)
            {
                button165.BackColor = Color.Blue;
                text[164] = "H";
            }
            else if (color == 4)
            {
                button165.BackColor = Color.Yellow;
                text[164] = "F";
            }
            else if (color == 5)
            {
                button165.BackColor = Color.MidnightBlue;
                text[164] = "O";
            }
            else if (color == 6)
            {
                button165.BackColor = Color.Magenta;
                text[164] = "C";
            }
        }

        private void button166_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button166.BackColor = Color.Green;
                text[165] = "W";
            }
            else if (color == 2)
            {
                button166.BackColor = Color.Red;
                text[165] = "E";
            }
            else if (color == 3)
            {
                button166.BackColor = Color.Blue;
                text[165] = "H";
            }
            else if (color == 4)
            {
                button166.BackColor = Color.Yellow;
                text[165] = "F";
            }
            else if (color == 5)
            {
                button166.BackColor = Color.MidnightBlue;
                text[165] = "O";
            }
            else if (color == 6)
            {
                button166.BackColor = Color.Magenta;
                text[165] = "C";
            }
        }

        private void button167_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button167.BackColor = Color.Green;
                text[166] = "W";
            }
            else if (color == 2)
            {
                button167.BackColor = Color.Red;
                text[166] = "E";
            }
            else if (color == 3)
            {
                button167.BackColor = Color.Blue;
                text[166] = "H";
            }
            else if (color == 4)
            {
                button167.BackColor = Color.Yellow;
                text[166] = "F";
            }
            else if (color == 5)
            {
                button167.BackColor = Color.MidnightBlue;
                text[166] = "O";
            }
            else if (color == 6)
            {
                button167.BackColor = Color.Magenta;
                text[166] = "C";
            }
        }

        private void button168_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button168.BackColor = Color.Green;
                text[167] = "W";
            }
            else if (color == 2)
            {
                button168.BackColor = Color.Red;
                text[167] = "E";
            }
            else if (color == 3)
            {
                button168.BackColor = Color.Blue;
                text[167] = "H";
            }
            else if (color == 4)
            {
                button168.BackColor = Color.Yellow;
                text[167] = "F";
            }
            else if (color == 5)
            {
                button168.BackColor = Color.MidnightBlue;
                text[167] = "O";
            }
            else if (color == 6)
            {
                button168.BackColor = Color.Magenta;
                text[167] = "C";
            }
        }

        private void button169_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button169.BackColor = Color.Green;
                text[168] = "W";
            }
            else if (color == 2)
            {
                button169.BackColor = Color.Red;
                text[168] = "E";
            }
            else if (color == 3)
            {
                button169.BackColor = Color.Blue;
                text[168] = "H";
            }
            else if (color == 4)
            {
                button169.BackColor = Color.Yellow;
                text[168] = "F";
            }
            else if (color == 5)
            {
                button169.BackColor = Color.MidnightBlue;
                text[168] = "O";
            }
            else if (color == 6)
            {
                button169.BackColor = Color.Magenta;
                text[168] = "C";
            }
        }

        private void button170_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button170.BackColor = Color.Green;
                text[169] = "W";
            }
            else if (color == 2)
            {
                button170.BackColor = Color.Red;
                text[169] = "E";
            }
            else if (color == 3)
            {
                button170.BackColor = Color.Blue;
                text[169] = "H";
            }
            else if (color == 4)
            {
                button170.BackColor = Color.Yellow;
                text[169] = "F";
            }
            else if (color == 5)
            {
                button170.BackColor = Color.MidnightBlue;
                text[160] = "O";
            }
            else if (color == 6)
            {
                button170.BackColor = Color.Magenta;
                text[169] = "C";
            }
        }

        private void button171_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button171.BackColor = Color.Green;
                text[170] = "W";
            }
            else if (color == 2)
            {
                button171.BackColor = Color.Red;
                text[170] = "E";
            }
            else if (color == 3)
            {
                button171.BackColor = Color.Blue;
                text[170] = "H";
            }
            else if (color == 4)
            {
                button171.BackColor = Color.Yellow;
                text[170] = "F";
            }
            else if (color == 5)
            {
                button171.BackColor = Color.MidnightBlue;
                text[170] = "O";
            }
            else if (color == 6)
            {
                button171.BackColor = Color.Magenta;
                text[170] = "C";
            }
        }

        private void button172_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button172.BackColor = Color.Green;
                text[171] = "W";
            }
            else if (color == 2)
            {
                button172.BackColor = Color.Red;
                text[171] = "E";
            }
            else if (color == 3)
            {
                button172.BackColor = Color.Blue;
                text[171] = "H";
            }
            else if (color == 4)
            {
                button172.BackColor = Color.Yellow;
                text[171] = "F";
            }
            else if (color == 5)
            {
                button172.BackColor = Color.MidnightBlue;
                text[171] = "O";
            }
            else if (color == 6)
            {
                button172.BackColor = Color.Magenta;
                text[171] = "C";
            }
        }

        private void button173_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button173.BackColor = Color.Green;
                text[172] = "W";
            }
            else if (color == 2)
            {
                button173.BackColor = Color.Red;
                text[172] = "E";
            }
            else if (color == 3)
            {
                button173.BackColor = Color.Blue;
                text[172] = "H";
            }
            else if (color == 4)
            {
                button173.BackColor = Color.Yellow;
                text[172] = "F";
            }
            else if (color == 5)
            {
                button173.BackColor = Color.MidnightBlue;
                text[172] = "O";
            }
            else if (color == 6)
            {
                button173.BackColor = Color.Magenta;
                text[172] = "C";
            }
        }

        private void button174_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button174.BackColor = Color.Green;
                text[173] = "W";
            }
            else if (color == 2)
            {
                button174.BackColor = Color.Red;
                text[173] = "E";
            }
            else if (color == 3)
            {
                button174.BackColor = Color.Blue;
                text[173] = "H";
            }
            else if (color == 4)
            {
                button174.BackColor = Color.Yellow;
                text[173] = "F";
            }
            else if (color == 5)
            {
                button174.BackColor = Color.MidnightBlue;
                text[173] = "O";
            }
            else if (color == 6)
            {
                button174.BackColor = Color.Magenta;
                text[173] = "C";
            }
        }

        private void button175_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button175.BackColor = Color.Green;
                text[174] = "W";
            }
            else if (color == 2)
            {
                button175.BackColor = Color.Red;
                text[174] = "E";
            }
            else if (color == 3)
            {
                button175.BackColor = Color.Blue;
                text[174] = "H";
            }
            else if (color == 4)
            {
                button175.BackColor = Color.Yellow;
                text[174] = "F";
            }
            else if (color == 5)
            {
                button175.BackColor = Color.MidnightBlue;
                text[174] = "O";
            }
            else if (color == 6)
            {
                button175.BackColor = Color.Magenta;
                text[174] = "C";
            }
        }

        private void button176_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button176.BackColor = Color.Green;
                text[175] = "W";
            }
            else if (color == 2)
            {
                button176.BackColor = Color.Red;
                text[175] = "E";
            }
            else if (color == 3)
            {
                button176.BackColor = Color.Blue;
                text[175] = "H";
            }
            else if (color == 4)
            {
                button176.BackColor = Color.Yellow;
                text[175] = "F";
            }
            else if (color == 5)
            {
                button176.BackColor = Color.MidnightBlue;
                text[175] = "O";
            }
            else if (color == 6)
            {
                button176.BackColor = Color.Magenta;
                text[175] = "C";
            }
        }

        private void button177_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button177.BackColor = Color.Green;
                text[176] = "W";
            }
            else if (color == 2)
            {
                button177.BackColor = Color.Red;
                text[176] = "E";
            }
            else if (color == 3)
            {
                button177.BackColor = Color.Blue;
                text[176] = "H";
            }
            else if (color == 4)
            {
                button177.BackColor = Color.Yellow;
                text[176] = "F";
            }
            else if (color == 5)
            {
                button177.BackColor = Color.MidnightBlue;
                text[176] = "O";
            }
            else if (color == 6)
            {
                button177.BackColor = Color.Magenta;
                text[176] = "C";
            }
        }

        private void button178_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button178.BackColor = Color.Green;
                text[177] = "W";
            }
            else if (color == 2)
            {
                button178.BackColor = Color.Red;
                text[177] = "E";
            }
            else if (color == 3)
            {
                button178.BackColor = Color.Blue;
                text[177] = "H";
            }
            else if (color == 4)
            {
                button178.BackColor = Color.Yellow;
                text[177] = "F";
            }
            else if (color == 5)
            {
                button178.BackColor = Color.MidnightBlue;
                text[177] = "O";
            }
            else if (color == 6)
            {
                button178.BackColor = Color.Magenta;
                text[177] = "C";
            }
        }

        private void button179_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button179.BackColor = Color.Green;
                text[178] = "W";
            }
            else if (color == 2)
            {
                button179.BackColor = Color.Red;
                text[178] = "E";
            }
            else if (color == 3)
            {
                button179.BackColor = Color.Blue;
                text[178] = "H";
            }
            else if (color == 4)
            {
                button179.BackColor = Color.Yellow;
                text[178] = "F";
            }
            else if (color == 5)
            {
                button179.BackColor = Color.MidnightBlue;
                text[178] = "O";
            }
            else if (color == 6)
            {
                button179.BackColor = Color.Magenta;
                text[178] = "C";
            }
        }

        private void button180_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button180.BackColor = Color.Green;
                text[179] = "W";
            }
            else if (color == 2)
            {
                button180.BackColor = Color.Red;
                text[179] = "E";
            }
            else if (color == 3)
            {
                button180.BackColor = Color.Blue;
                text[179] = "H";
            }
            else if (color == 4)
            {
                button180.BackColor = Color.Yellow;
                text[179] = "F";
            }
            else if (color == 5)
            {
                button180.BackColor = Color.MidnightBlue;
                text[179] = "O";
            }
            else if (color == 6)
            {
                button180.BackColor = Color.Magenta;
                text[179] = "C";
            }
        }

        private void button181_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button181.BackColor = Color.Green;
                text[180] = "W";
            }
            else if (color == 2)
            {
                button181.BackColor = Color.Red;
                text[180] = "E";
            }
            else if (color == 3)
            {
                button181.BackColor = Color.Blue;
                text[180] = "H";
            }
            else if (color == 4)
            {
                button181.BackColor = Color.Yellow;
                text[180] = "F";
            }
            else if (color == 5)
            {
                button181.BackColor = Color.MidnightBlue;
                text[180] = "O";
            }
            else if (color == 6)
            {
                button181.BackColor = Color.Magenta;
                text[180] = "C";
            }
        }

        private void button182_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button182.BackColor = Color.Green;
                text[181] = "W";
            }
            else if (color == 2)
            {
                button182.BackColor = Color.Red;
                text[181] = "E";
            }
            else if (color == 3)
            {
                button182.BackColor = Color.Blue;
                text[181] = "H";
            }
            else if (color == 4)
            {
                button182.BackColor = Color.Yellow;
                text[181] = "F";
            }
            else if (color == 5)
            {
                button182.BackColor = Color.MidnightBlue;
                text[181] = "O";
            }
            else if (color == 6)
            {
                button182.BackColor = Color.Magenta;
                text[181] = "C";
            }
        }

        private void button183_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button183.BackColor = Color.Green;
                text[182] = "W";
            }
            else if (color == 2)
            {
                button183.BackColor = Color.Red;
                text[182] = "E";
            }
            else if (color == 3)
            {
                button183.BackColor = Color.Blue;
                text[182] = "H";
            }
            else if (color == 4)
            {
                button183.BackColor = Color.Yellow;
                text[182] = "F";
            }
            else if (color == 5)
            {
                button183.BackColor = Color.MidnightBlue;
                text[182] = "O";
            }
            else if (color == 6)
            {
                button183.BackColor = Color.Magenta;
                text[182] = "C";
            }
        }

        private void button184_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button184.BackColor = Color.Green;
                text[183] = "W";
            }
            else if (color == 2)
            {
                button184.BackColor = Color.Red;
                text[183] = "E";
            }
            else if (color == 3)
            {
                button184.BackColor = Color.Blue;
                text[183] = "H";
            }
            else if (color == 4)
            {
                button184.BackColor = Color.Yellow;
                text[183] = "F";
            }
            else if (color == 5)
            {
                button184.BackColor = Color.MidnightBlue;
                text[183] = "O";
            }
            else if (color == 6)
            {
                button184.BackColor = Color.Magenta;
                text[183] = "C";
            }
        }

        private void button185_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button185.BackColor = Color.Green;
                text[184] = "W";
            }
            else if (color == 2)
            {
                button185.BackColor = Color.Red;
                text[184] = "E";
            }
            else if (color == 3)
            {
                button185.BackColor = Color.Blue;
                text[184] = "H";
            }
            else if (color == 4)
            {
                button185.BackColor = Color.Yellow;
                text[184] = "F";
            }
            else if (color == 5)
            {
                button185.BackColor = Color.MidnightBlue;
                text[184] = "O";
            }
            else if (color == 6)
            {
                button185.BackColor = Color.Magenta;
                text[184] = "C";
            }
        }

        private void button186_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button186.BackColor = Color.Green;
                text[185] = "W";
            }
            else if (color == 2)
            {
                button186.BackColor = Color.Red;
                text[185] = "E";
            }
            else if (color == 3)
            {
                button186.BackColor = Color.Blue;
                text[185] = "H";
            }
            else if (color == 4)
            {
                button186.BackColor = Color.Yellow;
                text[185] = "F";
            }
            else if (color == 5)
            {
                button186.BackColor = Color.MidnightBlue;
                text[185] = "O";
            }
            else if (color == 6)
            {
                button186.BackColor = Color.Magenta;
                text[185] = "C";
            }
        }

        private void button187_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button187.BackColor = Color.Green;
                text[186] = "W";
            }
            else if (color == 2)
            {
                button187.BackColor = Color.Red;
                text[186] = "E";
            }
            else if (color == 3)
            {
                button187.BackColor = Color.Blue;
                text[186] = "H";
            }
            else if (color == 4)
            {
                button187.BackColor = Color.Yellow;
                text[186] = "F";
            }
            else if (color == 5)
            {
                button187.BackColor = Color.MidnightBlue;
                text[186] = "O";
            }
            else if (color == 6)
            {
                button187.BackColor = Color.Magenta;
                text[186] = "C";
            }
        }

        private void button188_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button188.BackColor = Color.Green;
                text[187] = "W";
            }
            else if (color == 2)
            {
                button188.BackColor = Color.Red;
                text[187] = "E";
            }
            else if (color == 3)
            {
                button188.BackColor = Color.Blue;
                text[187] = "H";
            }
            else if (color == 4)
            {
                button188.BackColor = Color.Yellow;
                text[187] = "F";
            }
            else if (color == 5)
            {
                button188.BackColor = Color.MidnightBlue;
                text[187] = "O";
            }
            else if (color == 6)
            {
                button188.BackColor = Color.Magenta;
                text[187] = "C";
            }
        }

        private void button189_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button189.BackColor = Color.Green;
                text[188] = "W";
            }
            else if (color == 2)
            {
                button189.BackColor = Color.Red;
                text[188] = "E";
            }
            else if (color == 3)
            {
                button189.BackColor = Color.Blue;
                text[188] = "H";
            }
            else if (color == 4)
            {
                button189.BackColor = Color.Yellow;
                text[188] = "F";
            }
            else if (color == 5)
            {
                button189.BackColor = Color.MidnightBlue;
                text[188] = "O";
            }
            else if (color == 6)
            {
                button189.BackColor = Color.Magenta;
                text[188] = "C";
            }
        }

        private void button190_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button190.BackColor = Color.Green;
                text[189] = "W";
            }
            else if (color == 2)
            {
                button190.BackColor = Color.Red;
                text[189] = "E";
            }
            else if (color == 3)
            {
                button190.BackColor = Color.Blue;
                text[180] = "H";
            }
            else if (color == 4)
            {
                button190.BackColor = Color.Yellow;
                text[189] = "F";
            }
            else if (color == 5)
            {
                button190.BackColor = Color.MidnightBlue;
                text[189] = "O";
            }
            else if (color == 6)
            {
                button190.BackColor = Color.Magenta;
                text[189] = "C";
            }
        }

        private void button191_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button191.BackColor = Color.Green;
                text[190] = "W";
            }
            else if (color == 2)
            {
                button191.BackColor = Color.Red;
                text[190] = "E";
            }
            else if (color == 3)
            {
                button191.BackColor = Color.Blue;
                text[190] = "H";
            }
            else if (color == 4)
            {
                button191.BackColor = Color.Yellow;
                text[190] = "F";
            }
            else if (color == 5)
            {
                button191.BackColor = Color.MidnightBlue;
                text[190] = "O";
            }
            else if (color == 6)
            {
                button191.BackColor = Color.Magenta;
                text[190] = "C";
            }
        }

        private void button192_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button192.BackColor = Color.Green;
                text[191] = "W";
            }
            else if (color == 2)
            {
                button192.BackColor = Color.Red;
                text[191] = "E";
            }
            else if (color == 3)
            {
                button192.BackColor = Color.Blue;
                text[191] = "H";
            }
            else if (color == 4)
            {
                button192.BackColor = Color.Yellow;
                text[191] = "F";
            }
            else if (color == 5)
            {
                button192.BackColor = Color.MidnightBlue;
                text[191] = "O";
            }
            else if (color == 6)
            {
                button192.BackColor = Color.Magenta;
                text[191] = "C";
            }
        }
        #endregion

        #region Down 2 Code
        private void button193_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button193.BackColor = Color.Green;
                text[192] = "W";
            }
            else if (color == 2)
            {
                button193.BackColor = Color.Red;
                text[192] = "E";
            }
            else if (color == 3)
            {
                button193.BackColor = Color.Blue;
                text[192] = "H";
            }
            else if (color == 4)
            {
                button193.BackColor = Color.Yellow;
                text[192] = "F";
            }
            else if (color == 5)
            {
                button193.BackColor = Color.MidnightBlue;
                text[192] = "O";
            }
            else if (color == 6)
            {
                button193.BackColor = Color.Magenta;
                text[192] = "C";
            }
        }

        private void button194_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button194.BackColor = Color.Green;
                text[193] = "W";
            }
            else if (color == 2)
            {
                button194.BackColor = Color.Red;
                text[193] = "E";
            }
            else if (color == 3)
            {
                button194.BackColor = Color.Blue;
                text[193] = "H";
            }
            else if (color == 4)
            {
                button194.BackColor = Color.Yellow;
                text[193] = "F";
            }
            else if (color == 5)
            {
                button193.BackColor = Color.MidnightBlue;
                text[192] = "O";
            }
            else if (color == 6)
            {
                button193.BackColor = Color.Magenta;
                text[192] = "C";
            }
        }

        private void button195_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button195.BackColor = Color.Green;
                text[194] = "W";
            }
            else if (color == 2)
            {
                button195.BackColor = Color.Red;
                text[194] = "E";
            }
            else if (color == 3)
            {
                button195.BackColor = Color.Blue;
                text[194] = "H";
            }
            else if (color == 4)
            {
                button195.BackColor = Color.Yellow;
                text[194] = "F";
            }
            else if (color == 5)
            {
                button195.BackColor = Color.MidnightBlue;
                text[194] = "O";
            }
            else if (color == 6)
            {
                button195.BackColor = Color.Magenta;
                text[194] = "C";
            }
        }

        private void button196_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button196.BackColor = Color.Green;
                text[195] = "W";
            }
            else if (color == 2)
            {
                button196.BackColor = Color.Red;
                text[195] = "E";
            }
            else if (color == 3)
            {
                button196.BackColor = Color.Blue;
                text[195] = "H";
            }
            else if (color == 4)
            {
                button196.BackColor = Color.Yellow;
                text[195] = "F";
            }
            else if (color == 5)
            {
                button196.BackColor = Color.MidnightBlue;
                text[195] = "O";
            }
            else if (color == 6)
            {
                button196.BackColor = Color.Magenta;
                text[195] = "C";
            }
        }

        private void button197_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button197.BackColor = Color.Green;
                text[196] = "W";
            }
            else if (color == 2)
            {
                button197.BackColor = Color.Red;
                text[196] = "E";
            }
            else if (color == 3)
            {
                button197.BackColor = Color.Blue;
                text[196] = "H";
            }
            else if (color == 4)
            {
                button197.BackColor = Color.Yellow;
                text[196] = "F";
            }
            else if (color == 5)
            {
                button197.BackColor = Color.MidnightBlue;
                text[196] = "O";
            }
            else if (color == 6)
            {
                button197.BackColor = Color.Magenta;
                text[196] = "C";
            }
        }

        private void button198_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button198.BackColor = Color.Green;
                text[197] = "W";
            }
            else if (color == 2)
            {
                button198.BackColor = Color.Red;
                text[197] = "E";
            }
            else if (color == 3)
            {
                button198.BackColor = Color.Blue;
                text[197] = "H";
            }
            else if (color == 4)
            {
                button198.BackColor = Color.Yellow;
                text[197] = "F";
            }
            else if (color == 5)
            {
                button198.BackColor = Color.MidnightBlue;
                text[197] = "O";
            }
            else if (color == 6)
            {
                button198.BackColor = Color.Magenta;
                text[197] = "C";
            }
        }

        private void button199_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button199.BackColor = Color.Green;
                text[198] = "W";
            }
            else if (color == 2)
            {
                button199.BackColor = Color.Red;
                text[198] = "E";
            }
            else if (color == 3)
            {
                button199.BackColor = Color.Blue;
                text[198] = "H";
            }
            else if (color == 4)
            {
                button199.BackColor = Color.Yellow;
                text[198] = "F";
            }
            else if (color == 5)
            {
                button199.BackColor = Color.MidnightBlue;
                text[198] = "O";
            }
            else if (color == 6)
            {
                button199.BackColor = Color.Magenta;
                text[198] = "C";
            }
        }

        private void button200_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button200.BackColor = Color.Green;
                text[199] = "W";
            }
            else if (color == 2)
            {
                button200.BackColor = Color.Red;
                text[199] = "E";
            }
            else if (color == 3)
            {
                button200.BackColor = Color.Blue;
                text[199] = "H";
            }
            else if (color == 4)
            {
                button200.BackColor = Color.Yellow;
                text[199] = "F";
            }
            else if (color == 5)
            {
                button200.BackColor = Color.MidnightBlue;
                text[199] = "O";
            }
            else if (color == 6)
            {
                button200.BackColor = Color.Magenta;
                text[199] = "C";
            }
        }

        private void button201_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button201.BackColor = Color.Green;
                text[200] = "W";
            }
            else if (color == 2)
            {
                button201.BackColor = Color.Red;
                text[200] = "E";
            }
            else if (color == 3)
            {
                button201.BackColor = Color.Blue;
                text[200] = "H";
            }
            else if (color == 4)
            {
                button201.BackColor = Color.Yellow;
                text[200] = "F";
            }
            else if (color == 5)
            {
                button201.BackColor = Color.MidnightBlue;
                text[200] = "O";
            }
            else if (color == 6)
            {
                button201.BackColor = Color.Magenta;
                text[200] = "C";
            }
        }

        private void button202_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button202.BackColor = Color.Green;
                text[201] = "W";
            }
            else if (color == 2)
            {
                button202.BackColor = Color.Red;
                text[201] = "E";
            }
            else if (color == 3)
            {
                button202.BackColor = Color.Blue;
                text[201] = "H";
            }
            else if (color == 4)
            {
                button202.BackColor = Color.Yellow;
                text[201] = "F";
            }
            else if (color == 5)
            {
                button202.BackColor = Color.MidnightBlue;
                text[201] = "O";
            }
            else if (color == 6)
            {
                button202.BackColor = Color.Magenta;
                text[201] = "C";
            }
        }

        private void button203_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button203.BackColor = Color.Green;
                text[202] = "W";
            }
            else if (color == 2)
            {
                button203.BackColor = Color.Red;
                text[202] = "E";
            }
            else if (color == 3)
            {
                button203.BackColor = Color.Blue;
                text[202] = "H";
            }
            else if (color == 4)
            {
                button203.BackColor = Color.Yellow;
                text[202] = "F";
            }
            else if (color == 5)
            {
                button203.BackColor = Color.MidnightBlue;
                text[202] = "O";
            }
            else if (color == 6)
            {
                button203.BackColor = Color.Magenta;
                text[202] = "C";
            }
        }

        private void button204_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button204.BackColor = Color.Green;
                text[203] = "W";
            }
            else if (color == 2)
            {
                button204.BackColor = Color.Red;
                text[203] = "E";
            }
            else if (color == 3)
            {
                button204.BackColor = Color.Blue;
                text[203] = "H";
            }
            else if (color == 4)
            {
                button204.BackColor = Color.Yellow;
                text[203] = "F";
            }
            else if (color == 5)
            {
                button204.BackColor = Color.MidnightBlue;
                text[203] = "O";
            }
            else if (color == 6)
            {
                button204.BackColor = Color.Magenta;
                text[203] = "C";
            }
        }

        private void button205_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button205.BackColor = Color.Green;
                text[204] = "W";
            }
            else if (color == 2)
            {
                button205.BackColor = Color.Red;
                text[204] = "E";
            }
            else if (color == 3)
            {
                button205.BackColor = Color.Blue;
                text[204] = "H";
            }
            else if (color == 4)
            {
                button205.BackColor = Color.Yellow;
                text[204] = "F";
            }
            else if (color == 5)
            {
                button205.BackColor = Color.MidnightBlue;
                text[204] = "O";
            }
            else if (color == 6)
            {
                button205.BackColor = Color.Magenta;
                text[204] = "C";
            }
        }

        private void button206_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button206.BackColor = Color.Green;
                text[205] = "W";
            }
            else if (color == 2)
            {
                button206.BackColor = Color.Red;
                text[205] = "E";
            }
            else if (color == 3)
            {
                button206.BackColor = Color.Blue;
                text[205] = "H";
            }
            else if (color == 4)
            {
                button206.BackColor = Color.Yellow;
                text[205] = "F";
            }
            else if (color == 5)
            {
                button206.BackColor = Color.MidnightBlue;
                text[205] = "O";
            }
            else if (color == 6)
            {
                button206.BackColor = Color.Magenta;
                text[205] = "C";
            }
        }

        private void button207_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button207.BackColor = Color.Green;
                text[206] = "W";
            }
            else if (color == 2)
            {
                button207.BackColor = Color.Red;
                text[206] = "E";
            }
            else if (color == 3)
            {
                button207.BackColor = Color.Blue;
                text[206] = "H";
            }
            else if (color == 4)
            {
                button207.BackColor = Color.Yellow;
                text[206] = "F";
            }
            else if (color == 5)
            {
                button207.BackColor = Color.MidnightBlue;
                text[206] = "O";
            }
            else if (color == 6)
            {
                button207.BackColor = Color.Magenta;
                text[206] = "C";
            }
        }

        private void button208_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button208.BackColor = Color.Green;
                text[207] = "W";
            }
            else if (color == 2)
            {
                button208.BackColor = Color.Red;
                text[207] = "E";
            }
            else if (color == 3)
            {
                button208.BackColor = Color.Blue;
                text[207] = "H";
            }
            else if (color == 4)
            {
                button208.BackColor = Color.Yellow;
                text[207] = "F";
            }
            else if (color == 5)
            {
                button208.BackColor = Color.MidnightBlue;
                text[207] = "O";
            }
            else if (color == 6)
            {
                button208.BackColor = Color.Magenta;
                text[207] = "C";
            }
        }

        private void button209_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button209.BackColor = Color.Green;
                text[208] = "W";
            }
            else if (color == 2)
            {
                button209.BackColor = Color.Red;
                text[208] = "E";
            }
            else if (color == 3)
            {
                button209.BackColor = Color.Blue;
                text[208] = "H";
            }
            else if (color == 4)
            {
                button209.BackColor = Color.Yellow;
                text[208] = "F";
            }
            else if (color == 5)
            {
                button209.BackColor = Color.MidnightBlue;
                text[208] = "O";
            }
            else if (color == 6)
            {
                button209.BackColor = Color.Magenta;
                text[208] = "C";
            }
        }

        private void button210_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button210.BackColor = Color.Green;
                text[209] = "W";
            }
            else if (color == 2)
            {
                button210.BackColor = Color.Red;
                text[209] = "E";
            }
            else if (color == 3)
            {
                button210.BackColor = Color.Blue;
                text[209] = "H";
            }
            else if (color == 4)
            {
                button210.BackColor = Color.Yellow;
                text[209] = "F";
            }
            else if (color == 5)
            {
                button210.BackColor = Color.MidnightBlue;
                text[209] = "O";
            }
            else if (color == 6)
            {
                button210.BackColor = Color.Magenta;
                text[209] = "C";
            }
        }

        private void button211_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button211.BackColor = Color.Green;
                text[210] = "W";
            }
            else if (color == 2)
            {
                button211.BackColor = Color.Red;
                text[210] = "E";
            }
            else if (color == 3)
            {
                button211.BackColor = Color.Blue;
                text[210] = "H";
            }
            else if (color == 4)
            {
                button211.BackColor = Color.Yellow;
                text[210] = "F";
            }
            else if (color == 5)
            {
                button211.BackColor = Color.MidnightBlue;
                text[210] = "O";
            }
            else if (color == 6)
            {
                button211.BackColor = Color.Magenta;
                text[210] = "C";
            }
        }

        private void button212_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button212.BackColor = Color.Green;
                text[211] = "W";
            }
            else if (color == 2)
            {
                button212.BackColor = Color.Red;
                text[211] = "E";
            }
            else if (color == 3)
            {
                button212.BackColor = Color.Blue;
                text[211] = "H";
            }
            else if (color == 4)
            {
                button212.BackColor = Color.Yellow;
                text[211] = "F";
            }
            else if (color == 5)
            {
                button212.BackColor = Color.MidnightBlue;
                text[211] = "O";
            }
            else if (color == 6)
            {
                button212.BackColor = Color.Magenta;
                text[211] = "C";
            }
        }

        private void button213_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button213.BackColor = Color.Green;
                text[212] = "W";
            }
            else if (color == 2)
            {
                button213.BackColor = Color.Red;
                text[212] = "E";
            }
            else if (color == 3)
            {
                button213.BackColor = Color.Blue;
                text[212] = "H";
            }
            else if (color == 4)
            {
                button213.BackColor = Color.Yellow;
                text[212] = "F";
            }
            else if (color == 5)
            {
                button213.BackColor = Color.MidnightBlue;
                text[212] = "O";
            }
            else if (color == 6)
            {
                button213.BackColor = Color.Magenta;
                text[212] = "C";
            }
        }

        private void button214_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button214.BackColor = Color.Green;
                text[213] = "W";
            }
            else if (color == 2)
            {
                button214.BackColor = Color.Red;
                text[213] = "E";
            }
            else if (color == 3)
            {
                button214.BackColor = Color.Blue;
                text[213] = "H";
            }
            else if (color == 4)
            {
                button214.BackColor = Color.Yellow;
                text[213] = "F";
            }
            else if (color == 5)
            {
                button214.BackColor = Color.MidnightBlue;
                text[213] = "O";
            }
            else if (color == 6)
            {
                button214.BackColor = Color.Magenta;
                text[213] = "C";
            }
        }

        private void button215_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button215.BackColor = Color.Green;
                text[214] = "W";
            }
            else if (color == 2)
            {
                button215.BackColor = Color.Red;
                text[214] = "E";
            }
            else if (color == 3)
            {
                button215.BackColor = Color.Blue;
                text[214] = "H";
            }
            else if (color == 4)
            {
                button215.BackColor = Color.Yellow;
                text[214] = "F";
            }
            else if (color == 5)
            {
                button215.BackColor = Color.MidnightBlue;
                text[214] = "O";
            }
            else if (color == 6)
            {
                button215.BackColor = Color.Magenta;
                text[214] = "C";
            }
        }

        private void button216_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button216.BackColor = Color.Green;
                text[215] = "W";
            }
            else if (color == 2)
            {
                button216.BackColor = Color.Red;
                text[215] = "E";
            }
            else if (color == 3)
            {
                button216.BackColor = Color.Blue;
                text[215] = "H";
            }
            else if (color == 4)
            {
                button216.BackColor = Color.Yellow;
                text[215] = "F";
            }
            else if (color == 5)
            {
                button216.BackColor = Color.MidnightBlue;
                text[215] = "O";
            }
            else if (color == 6)
            {
                button216.BackColor = Color.Magenta;
                text[215] = "C";
            }
        }

        private void button217_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button217.BackColor = Color.Green;
                text[216] = "W";
            }
            else if (color == 2)
            {
                button217.BackColor = Color.Red;
                text[216] = "E";
            }
            else if (color == 3)
            {
                button217.BackColor = Color.Blue;
                text[216] = "H";
            }
            else if (color == 4)
            {
                button217.BackColor = Color.Yellow;
                text[216] = "F";
            }
            else if (color == 5)
            {
                button217.BackColor = Color.MidnightBlue;
                text[216] = "O";
            }
            else if (color == 6)
            {
                button217.BackColor = Color.Magenta;
                text[216] = "C";
            }
        }

        private void button218_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button218.BackColor = Color.Green;
                text[217] = "W";
            }
            else if (color == 2)
            {
                button218.BackColor = Color.Red;
                text[217] = "E";
            }
            else if (color == 3)
            {
                button218.BackColor = Color.Blue;
                text[217] = "H";
            }
            else if (color == 4)
            {
                button218.BackColor = Color.Yellow;
                text[217] = "F";
            }
            else if (color == 5)
            {
                button218.BackColor = Color.MidnightBlue;
                text[217] = "O";
            }
            else if (color == 6)
            {
                button218.BackColor = Color.Magenta;
                text[217] = "C";
            }
        }

        private void button219_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button219.BackColor = Color.Green;
                text[218] = "W";
            }
            else if (color == 2)
            {
                button219.BackColor = Color.Red;
                text[218] = "E";
            }
            else if (color == 3)
            {
                button219.BackColor = Color.Blue;
                text[218] = "H";
            }
            else if (color == 4)
            {
                button219.BackColor = Color.Yellow;
                text[218] = "F";
            }
            else if (color == 5)
            {
                button219.BackColor = Color.MidnightBlue;
                text[218] = "O";
            }
            else if (color == 6)
            {
                button219.BackColor = Color.Magenta;
                text[218] = "C";
            }
        }

        private void button220_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button220.BackColor = Color.Green;
                text[219] = "W";
            }
            else if (color == 2)
            {
                button210.BackColor = Color.Red;
                text[219] = "E";
            }
            else if (color == 3)
            {
                button220.BackColor = Color.Blue;
                text[219] = "H";
            }
            else if (color == 4)
            {
                button220.BackColor = Color.Yellow;
                text[219] = "F";
            }
            else if (color == 5)
            {
                button220.BackColor = Color.MidnightBlue;
                text[219] = "O";
            }
            else if (color == 6)
            {
                button220.BackColor = Color.Magenta;
                text[219] = "C";
            }
        }

        private void button221_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button221.BackColor = Color.Green;
                text[220] = "W";
            }
            else if (color == 2)
            {
                button221.BackColor = Color.Red;
                text[220] = "E";
            }
            else if (color == 3)
            {
                button221.BackColor = Color.Blue;
                text[220] = "H";
            }
            else if (color == 4)
            {
                button221.BackColor = Color.Yellow;
                text[220] = "F";
            }
            else if (color == 5)
            {
                button221.BackColor = Color.MidnightBlue;
                text[220] = "O";
            }
            else if (color == 6)
            {
                button221.BackColor = Color.Magenta;
                text[220] = "C";
            }
        }

        private void button222_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button222.BackColor = Color.Green;
                text[221] = "W";
            }
            else if (color == 2)
            {
                button222.BackColor = Color.Red;
                text[221] = "E";
            }
            else if (color == 3)
            {
                button222.BackColor = Color.Blue;
                text[221] = "H";
            }
            else if (color == 4)
            {
                button222.BackColor = Color.Yellow;
                text[221] = "F";
            }
            else if (color == 5)
            {
                button222.BackColor = Color.MidnightBlue;
                text[221] = "O";
            }
            else if (color == 6)
            {
                button222.BackColor = Color.Magenta;
                text[221] = "C";
            }
        }

        private void button223_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button223.BackColor = Color.Green;
                text[222] = "W";
            }
            else if (color == 2)
            {
                button223.BackColor = Color.Red;
                text[222] = "E";
            }
            else if (color == 3)
            {
                button223.BackColor = Color.Blue;
                text[222] = "H";
            }
            else if (color == 4)
            {
                button223.BackColor = Color.Yellow;
                text[222] = "F";
            }
            else if (color == 5)
            {
                button223.BackColor = Color.MidnightBlue;
                text[222] = "O";
            }
            else if (color == 6)
            {
                button223.BackColor = Color.Magenta;
                text[222] = "C";
            }
        }

        private void button224_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button224.BackColor = Color.Green;
                text[223] = "W";
            }
            else if (color == 2)
            {
                button224.BackColor = Color.Red;
                text[223] = "E";
            }
            else if (color == 3)
            {
                button224.BackColor = Color.Blue;
                text[223] = "H";
            }
            else if (color == 4)
            {
                button224.BackColor = Color.Yellow;
                text[223] = "F";
            }
            else if (color == 5)
            {
                button224.BackColor = Color.MidnightBlue;
                text[223] = "O";
            }
            else if (color == 6)
            {
                button224.BackColor = Color.Magenta;
                text[223] = "C";
            }
        }

        private void button225_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button225.BackColor = Color.Green;
                text[224] = "W";
            }
            else if (color == 2)
            {
                button225.BackColor = Color.Red;
                text[224] = "E";
            }
            else if (color == 3)
            {
                button225.BackColor = Color.Blue;
                text[224] = "H";
            }
            else if (color == 4)
            {
                button225.BackColor = Color.Yellow;
                text[224] = "F";
            }
            else if (color == 5)
            {
                button225.BackColor = Color.MidnightBlue;
                text[224] = "O";
            }
            else if (color == 6)
            {
                button225.BackColor = Color.Magenta;
                text[224] = "C";
            }
        }

        private void button226_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button226.BackColor = Color.Green;
                text[225] = "W";
            }
            else if (color == 2)
            {
                button226.BackColor = Color.Red;
                text[225] = "E";
            }
            else if (color == 3)
            {
                button226.BackColor = Color.Blue;
                text[225] = "H";
            }
            else if (color == 4)
            {
                button226.BackColor = Color.Yellow;
                text[225] = "F";
            }
            else if (color == 5)
            {
                button226.BackColor = Color.MidnightBlue;
                text[225] = "O";
            }
            else if (color == 6)
            {
                button226.BackColor = Color.Magenta;
                text[225] = "C";
            }
        }

        private void button227_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button227.BackColor = Color.Green;
                text[226] = "W";
            }
            else if (color == 2)
            {
                button227.BackColor = Color.Red;
                text[226] = "E";
            }
            else if (color == 3)
            {
                button227.BackColor = Color.Blue;
                text[226] = "H";
            }
            else if (color == 4)
            {
                button227.BackColor = Color.Yellow;
                text[226] = "F";
            }
            else if (color == 5)
            {
                button227.BackColor = Color.MidnightBlue;
                text[226] = "O";
            }
            else if (color == 6)
            {
                button227.BackColor = Color.Magenta;
                text[226] = "C";
            }
        }

        private void button228_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button228.BackColor = Color.Green;
                text[227] = "W";
            }
            else if (color == 2)
            {
                button228.BackColor = Color.Red;
                text[227] = "E";
            }
            else if (color == 3)
            {
                button228.BackColor = Color.Blue;
                text[227] = "H";
            }
            else if (color == 4)
            {
                button228.BackColor = Color.Yellow;
                text[227] = "F";
            }
            else if (color == 5)
            {
                button228.BackColor = Color.MidnightBlue;
                text[227] = "O";
            }
            else if (color == 6)
            {
                button228.BackColor = Color.Magenta;
                text[227] = "C";
            }
        }

        private void button229_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button229.BackColor = Color.Green;
                text[228] = "W";
            }
            else if (color == 2)
            {
                button229.BackColor = Color.Red;
                text[228] = "E";
            }
            else if (color == 3)
            {
                button229.BackColor = Color.Blue;
                text[228] = "H";
            }
            else if (color == 4)
            {
                button229.BackColor = Color.Yellow;
                text[228] = "F";
            }
            else if (color == 5)
            {
                button229.BackColor = Color.MidnightBlue;
                text[228] = "O";
            }
            else if (color == 6)
            {
                button229.BackColor = Color.Magenta;
                text[228] = "C";
            }
        }

        private void button230_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button230.BackColor = Color.Green;
                text[229] = "W";
            }
            else if (color == 2)
            {
                button230.BackColor = Color.Red;
                text[229] = "E";
            }
            else if (color == 3)
            {
                button230.BackColor = Color.Blue;
                text[229] = "H";
            }
            else if (color == 4)
            {
                button230.BackColor = Color.Yellow;
                text[229] = "F";
            }
            else if (color == 5)
            {
                button230.BackColor = Color.MidnightBlue;
                text[229] = "O";
            }
            else if (color == 6)
            {
                button230.BackColor = Color.Magenta;
                text[229] = "C";
            }
        }

        private void button231_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button231.BackColor = Color.Green;
                text[230] = "W";
            }
            else if (color == 2)
            {
                button231.BackColor = Color.Red;
                text[230] = "E";
            }
            else if (color == 3)
            {
                button231.BackColor = Color.Blue;
                text[230] = "H";
            }
            else if (color == 4)
            {
                button231.BackColor = Color.Yellow;
                text[230] = "F";
            }
            else if (color == 5)
            {
                button231.BackColor = Color.MidnightBlue;
                text[230] = "O";
            }
            else if (color == 6)
            {
                button231.BackColor = Color.Magenta;
                text[230] = "C";
            }
        }

        private void button232_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button232.BackColor = Color.Green;
                text[231] = "W";
            }
            else if (color == 2)
            {
                button232.BackColor = Color.Red;
                text[231] = "E";
            }
            else if (color == 3)
            {
                button232.BackColor = Color.Blue;
                text[231] = "H";
            }
            else if (color == 4)
            {
                button232.BackColor = Color.Yellow;
                text[231] = "F";
            }
            else if (color == 5)
            {
                button232.BackColor = Color.MidnightBlue;
                text[231] = "O";
            }
            else if (color == 6)
            {
                button232.BackColor = Color.Magenta;
                text[231] = "C";
            }
        }

        private void button233_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button233.BackColor = Color.Green;
                text[232] = "W";
            }
            else if (color == 2)
            {
                button233.BackColor = Color.Red;
                text[232] = "E";
            }
            else if (color == 3)
            {
                button233.BackColor = Color.Blue;
                text[232] = "H";
            }
            else if (color == 4)
            {
                button233.BackColor = Color.Yellow;
                text[232] = "F";
            }
            else if (color == 5)
            {
                button233.BackColor = Color.MidnightBlue;
                text[232] = "O";
            }
            else if (color == 6)
            {
                button233.BackColor = Color.Magenta;
                text[232] = "C";
            }
        }

        private void button234_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button234.BackColor = Color.Green;
                text[233] = "W";
            }
            else if (color == 2)
            {
                button234.BackColor = Color.Red;
                text[233] = "E";
            }
            else if (color == 3)
            {
                button234.BackColor = Color.Blue;
                text[233] = "H";
            }
            else if (color == 4)
            {
                button234.BackColor = Color.Yellow;
                text[233] = "F";
            }
            else if (color == 5)
            {
                button234.BackColor = Color.MidnightBlue;
                text[233] = "O";
            }
            else if (color == 6)
            {
                button234.BackColor = Color.Magenta;
                text[233] = "C";
            }
        }

        private void button235_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button235.BackColor = Color.Green;
                text[234] = "W";
            }
            else if (color == 2)
            {
                button235.BackColor = Color.Red;
                text[234] = "E";
            }
            else if (color == 3)
            {
                button235.BackColor = Color.Blue;
                text[234] = "H";
            }
            else if (color == 4)
            {
                button235.BackColor = Color.Yellow;
                text[234] = "F";
            }
            else if (color == 5)
            {
                button235.BackColor = Color.MidnightBlue;
                text[234] = "O";
            }
            else if (color == 6)
            {
                button235.BackColor = Color.Magenta;
                text[234] = "C";
            }
        }

        private void button236_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button236.BackColor = Color.Green;
                text[235] = "W";
            }
            else if (color == 2)
            {
                button236.BackColor = Color.Red;
                text[235] = "E";
            }
            else if (color == 3)
            {
                button236.BackColor = Color.Blue;
                text[235] = "H";
            }
            else if (color == 4)
            {
                button236.BackColor = Color.Yellow;
                text[235] = "F";
            }
            else if (color == 5)
            {
                button236.BackColor = Color.MidnightBlue;
                text[235] = "O";
            }
            else if (color == 6)
            {
                button236.BackColor = Color.Magenta;
                text[235] = "C";
            }
        }

        private void button237_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button237.BackColor = Color.Green;
                text[236] = "W";
            }
            else if (color == 2)
            {
                button237.BackColor = Color.Red;
                text[236] = "E";
            }
            else if (color == 3)
            {
                button237.BackColor = Color.Blue;
                text[236] = "H";
            }
            else if (color == 4)
            {
                button237.BackColor = Color.Yellow;
                text[236] = "F";
            }
            else if (color == 5)
            {
                button237.BackColor = Color.MidnightBlue;
                text[236] = "O";
            }
            else if (color == 6)
            {
                button237.BackColor = Color.Magenta;
                text[236] = "C";
            }
        }

        private void button238_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button238.BackColor = Color.Green;
                text[237] = "W";
            }
            else if (color == 2)
            {
                button238.BackColor = Color.Red;
                text[237] = "E";
            }
            else if (color == 3)
            {
                button238.BackColor = Color.Blue;
                text[237] = "H";
            }
            else if (color == 4)
            {
                button238.BackColor = Color.Yellow;
                text[237] = "F";
            }
            else if (color == 5)
            {
                button238.BackColor = Color.MidnightBlue;
                text[237] = "O";
            }
            else if (color == 6)
            {
                button238.BackColor = Color.Magenta;
                text[237] = "C";
            }
        }

        private void button239_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button239.BackColor = Color.Green;
                text[238] = "W";
            }
            else if (color == 2)
            {
                button239.BackColor = Color.Red;
                text[238] = "E";
            }
            else if (color == 3)
            {
                button239.BackColor = Color.Blue;
                text[238] = "H";
            }
            else if (color == 4)
            {
                button239.BackColor = Color.Yellow;
                text[238] = "F";
            }
            else if (color == 5)
            {
                button239.BackColor = Color.MidnightBlue;
                text[238] = "O";
            }
            else if (color == 6)
            {
                button239.BackColor = Color.Magenta;
                text[238] = "C";
            }
        }

        private void button240_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button240.BackColor = Color.Green;
                text[239] = "W";
            }
            else if (color == 2)
            {
                button240.BackColor = Color.Red;
                text[239] = "E";
            }
            else if (color == 3)
            {
                button240.BackColor = Color.Blue;
                text[239] = "H";
            }
            else if (color == 4)
            {
                button240.BackColor = Color.Yellow;
                text[239] = "F";
            }
            else if (color == 5)
            {
                button240.BackColor = Color.MidnightBlue;
                text[239] = "O";
            }
            else if (color == 6)
            {
                button240.BackColor = Color.Magenta;
                text[239] = "C";
            }
        }
        #endregion

        #region Left 2 Code
        private void button241_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button241.BackColor = Color.Green;
                text[240] = "W";
            }
            else if (color == 2)
            {
                button241.BackColor = Color.Red;
                text[240] = "E";
            }
            else if (color == 3)
            {
                button241.BackColor = Color.Blue;
                text[240] = "H";
            }
            else if (color == 4)
            {
                button241.BackColor = Color.Yellow;
                text[240] = "F";
            }
            else if (color == 5)
            {
                button241.BackColor = Color.MidnightBlue;
                text[240] = "O";
            }
            else if (color == 6)
            {
                button241.BackColor = Color.Magenta;
                text[240] = "C";
            }
        }

        private void button242_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button242.BackColor = Color.Green;
                text[241] = "W";
            }
            else if (color == 2)
            {
                button242.BackColor = Color.Red;
                text[241] = "E";
            }
            else if (color == 3)
            {
                button242.BackColor = Color.Blue;
                text[241] = "H";
            }
            else if (color == 4)
            {
                button242.BackColor = Color.Yellow;
                text[241] = "F";
            }
            else if (color == 5)
            {
                button242.BackColor = Color.MidnightBlue;
                text[241] = "O";
            }
            else if (color == 6)
            {
                button242.BackColor = Color.Magenta;
                text[241] = "C";
            }
        }

        private void button243_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button243.BackColor = Color.Green;
                text[242] = "W";
            }
            else if (color == 2)
            {
                button243.BackColor = Color.Red;
                text[242] = "E";
            }
            else if (color == 3)
            {
                button243.BackColor = Color.Blue;
                text[242] = "H";
            }
            else if (color == 4)
            {
                button243.BackColor = Color.Yellow;
                text[242] = "F";
            }
            else if (color == 5)
            {
                button243.BackColor = Color.MidnightBlue;
                text[242] = "O";
            }
            else if (color == 6)
            {
                button243.BackColor = Color.Magenta;
                text[242] = "C";
            }
        }

        private void button244_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button244.BackColor = Color.Green;
                text[243] = "W";
            }
            else if (color == 2)
            {
                button244.BackColor = Color.Red;
                text[243] = "E";
            }
            else if (color == 3)
            {
                button244.BackColor = Color.Blue;
                text[243] = "H";
            }
            else if (color == 4)
            {
                button244.BackColor = Color.Yellow;
                text[243] = "F";
            }
            else if (color == 5)
            {
                button244.BackColor = Color.MidnightBlue;
                text[243] = "O";
            }
            else if (color == 6)
            {
                button244.BackColor = Color.Magenta;
                text[243] = "C";
            }
        }

        private void button245_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button245.BackColor = Color.Green;
                text[244] = "W";
            }
            else if (color == 2)
            {
                button245.BackColor = Color.Red;
                text[244] = "E";
            }
            else if (color == 3)
            {
                button245.BackColor = Color.Blue;
                text[244] = "H";
            }
            else if (color == 4)
            {
                button245.BackColor = Color.Yellow;
                text[244] = "F";
            }
            else if (color == 5)
            {
                button245.BackColor = Color.MidnightBlue;
                text[244] = "O";
            }
            else if (color == 6)
            {
                button245.BackColor = Color.Magenta;
                text[244] = "C";
            }
        }

        private void button246_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button246.BackColor = Color.Green;
                text[245] = "W";
            }
            else if (color == 2)
            {
                button246.BackColor = Color.Red;
                text[245] = "E";
            }
            else if (color == 3)
            {
                button246.BackColor = Color.Blue;
                text[245] = "H";
            }
            else if (color == 4)
            {
                button246.BackColor = Color.Yellow;
                text[245] = "F";
            }
            else if (color == 5)
            {
                button246.BackColor = Color.MidnightBlue;
                text[245] = "O";
            }
            else if (color == 6)
            {
                button246.BackColor = Color.Magenta;
                text[245] = "C";
            }
        }

        private void button247_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button247.BackColor = Color.Green;
                text[246] = "W";
            }
            else if (color == 2)
            {
                button247.BackColor = Color.Red;
                text[246] = "E";
            }
            else if (color == 3)
            {
                button247.BackColor = Color.Blue;
                text[246] = "H";
            }
            else if (color == 4)
            {
                button247.BackColor = Color.Yellow;
                text[246] = "F";
            }
            else if (color == 5)
            {
                button247.BackColor = Color.MidnightBlue;
                text[246] = "O";
            }
            else if (color == 6)
            {
                button247.BackColor = Color.Magenta;
                text[246] = "C";
            }
        }

        private void button248_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button248.BackColor = Color.Green;
                text[247] = "W";
            }
            else if (color == 2)
            {
                button248.BackColor = Color.Red;
                text[247] = "E";
            }
            else if (color == 3)
            {
                button248.BackColor = Color.Blue;
                text[247] = "H";
            }
            else if (color == 4)
            {
                button248.BackColor = Color.Yellow;
                text[247] = "F";
            }
            else if (color == 5)
            {
                button248.BackColor = Color.MidnightBlue;
                text[247] = "O";
            }
            else if (color == 6)
            {
                button248.BackColor = Color.Magenta;
                text[247] = "C";
            }
        }

        private void button249_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button249.BackColor = Color.Green;
                text[248] = "W";
            }
            else if (color == 2)
            {
                button249.BackColor = Color.Red;
                text[248] = "E";
            }
            else if (color == 3)
            {
                button249.BackColor = Color.Blue;
                text[248] = "H";
            }
            else if (color == 4)
            {
                button249.BackColor = Color.Yellow;
                text[248] = "F";
            }
            else if (color == 5)
            {
                button249.BackColor = Color.MidnightBlue;
                text[248] = "O";
            }
            else if (color == 6)
            {
                button249.BackColor = Color.Magenta;
                text[248] = "C";
            }
        }

        private void button250_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button250.BackColor = Color.Green;
                text[249] = "W";
            }
            else if (color == 2)
            {
                button250.BackColor = Color.Red;
                text[249] = "E";
            }
            else if (color == 3)
            {
                button250.BackColor = Color.Blue;
                text[249] = "H";
            }
            else if (color == 4)
            {
                button250.BackColor = Color.Yellow;
                text[249] = "F";
            }
            else if (color == 5)
            {
                button250.BackColor = Color.MidnightBlue;
                text[249] = "O";
            }
            else if (color == 6)
            {
                button250.BackColor = Color.Magenta;
                text[249] = "C";
            }
        }

        private void button251_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button251.BackColor = Color.Green;
                text[250] = "W";
            }
            else if (color == 2)
            {
                button251.BackColor = Color.Red;
                text[250] = "E";
            }
            else if (color == 3)
            {
                button251.BackColor = Color.Blue;
                text[250] = "H";
            }
            else if (color == 4)
            {
                button251.BackColor = Color.Yellow;
                text[250] = "F";
            }
            else if (color == 5)
            {
                button251.BackColor = Color.MidnightBlue;
                text[250] = "O";
            }
            else if (color == 6)
            {
                button251.BackColor = Color.Magenta;
                text[250] = "C";
            }
        }

        private void button252_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button252.BackColor = Color.Green;
                text[251] = "W";
            }
            else if (color == 2)
            {
                button252.BackColor = Color.Red;
                text[251] = "E";
            }
            else if (color == 3)
            {
                button252.BackColor = Color.Blue;
                text[251] = "H";
            }
            else if (color == 4)
            {
                button252.BackColor = Color.Yellow;
                text[251] = "F";
            }
            else if (color == 5)
            {
                button252.BackColor = Color.MidnightBlue;
                text[251] = "O";
            }
            else if (color == 6)
            {
                button252.BackColor = Color.Magenta;
                text[251] = "C";
            }
        }

        private void button253_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button253.BackColor = Color.Green;
                text[252] = "W";
            }
            else if (color == 2)
            {
                button253.BackColor = Color.Red;
                text[252] = "E";
            }
            else if (color == 3)
            {
                button253.BackColor = Color.Blue;
                text[252] = "H";
            }
            else if (color == 4)
            {
                button253.BackColor = Color.Yellow;
                text[252] = "F";
            }
            else if (color == 5)
            {
                button253.BackColor = Color.MidnightBlue;
                text[252] = "O";
            }
            else if (color == 6)
            {
                button253.BackColor = Color.Magenta;
                text[252] = "C";
            }
        }

        private void button254_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button254.BackColor = Color.Green;
                text[253] = "W";
            }
            else if (color == 2)
            {
                button254.BackColor = Color.Red;
                text[253] = "E";
            }
            else if (color == 3)
            {
                button254.BackColor = Color.Blue;
                text[253] = "H";
            }
            else if (color == 4)
            {
                button254.BackColor = Color.Yellow;
                text[253] = "F";
            }
            else if (color == 5)
            {
                button254.BackColor = Color.MidnightBlue;
                text[253] = "O";
            }
            else if (color == 6)
            {
                button254.BackColor = Color.Magenta;
                text[253] = "C";
            }
        }

        private void button255_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button255.BackColor = Color.Green;
                text[254] = "W";
            }
            else if (color == 2)
            {
                button255.BackColor = Color.Red;
                text[254] = "E";
            }
            else if (color == 3)
            {
                button255.BackColor = Color.Blue;
                text[254] = "H";
            }
            else if (color == 4)
            {
                button255.BackColor = Color.Yellow;
                text[254] = "F";
            }
            else if (color == 5)
            {
                button255.BackColor = Color.MidnightBlue;
                text[254] = "O";
            }
            else if (color == 6)
            {
                button255.BackColor = Color.Magenta;
                text[254] = "C";
            }
        }

        private void button256_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button256.BackColor = Color.Green;
                text[255] = "W";
            }
            else if (color == 2)
            {
                button256.BackColor = Color.Red;
                text[255] = "E";
            }
            else if (color == 3)
            {
                button256.BackColor = Color.Blue;
                text[255] = "H";
            }
            else if (color == 4)
            {
                button256.BackColor = Color.Yellow;
                text[255] = "F";
            }
            else if (color == 5)
            {
                button256.BackColor = Color.MidnightBlue;
                text[255] = "O";
            }
            else if (color == 6)
            {
                button256.BackColor = Color.Magenta;
                text[255] = "C";
            }
        }

        private void button257_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button257.BackColor = Color.Green;
                text[256] = "W";
            }
            else if (color == 2)
            {
                button257.BackColor = Color.Red;
                text[256] = "E";
            }
            else if (color == 3)
            {
                button257.BackColor = Color.Blue;
                text[256] = "H";
            }
            else if (color == 4)
            {
                button257.BackColor = Color.Yellow;
                text[256] = "F";
            }
            else if (color == 5)
            {
                button257.BackColor = Color.MidnightBlue;
                text[256] = "O";
            }
            else if (color == 6)
            {
                button257.BackColor = Color.Magenta;
                text[256] = "C";
            }
        }

        private void button258_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button258.BackColor = Color.Green;
                text[257] = "W";
            }
            else if (color == 2)
            {
                button258.BackColor = Color.Red;
                text[257] = "E";
            }
            else if (color == 3)
            {
                button258.BackColor = Color.Blue;
                text[257] = "H";
            }
            else if (color == 4)
            {
                button258.BackColor = Color.Yellow;
                text[257] = "F";
            }
            else if (color == 5)
            {
                button258.BackColor = Color.MidnightBlue;
                text[257] = "O";
            }
            else if (color == 6)
            {
                button258.BackColor = Color.Magenta;
                text[257] = "C";
            }
        }

        private void button259_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button259.BackColor = Color.Green;
                text[258] = "W";
            }
            else if (color == 2)
            {
                button259.BackColor = Color.Red;
                text[258] = "E";
            }
            else if (color == 3)
            {
                button259.BackColor = Color.Blue;
                text[258] = "H";
            }
            else if (color == 4)
            {
                button259.BackColor = Color.Yellow;
                text[258] = "F";
            }
            else if (color == 5)
            {
                button259.BackColor = Color.MidnightBlue;
                text[258] = "O";
            }
            else if (color == 6)
            {
                button259.BackColor = Color.Magenta;
                text[258] = "C";
            }
        }

        private void button260_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button260.BackColor = Color.Green;
                text[259] = "W";
            }
            else if (color == 2)
            {
                button260.BackColor = Color.Red;
                text[259] = "E";
            }
            else if (color == 3)
            {
                button260.BackColor = Color.Blue;
                text[259] = "H";
            }
            else if (color == 4)
            {
                button260.BackColor = Color.Yellow;
                text[259] = "F";
            }
            else if (color == 5)
            {
                button260.BackColor = Color.MidnightBlue;
                text[259] = "O";
            }
            else if (color == 6)
            {
                button260.BackColor = Color.Magenta;
                text[259] = "C";
            }
        }

        private void button261_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button261.BackColor = Color.Green;
                text[260] = "W";
            }
            else if (color == 2)
            {
                button261.BackColor = Color.Red;
                text[260] = "E";
            }
            else if (color == 3)
            {
                button261.BackColor = Color.Blue;
                text[260] = "H";
            }
            else if (color == 4)
            {
                button261.BackColor = Color.Yellow;
                text[260] = "F";
            }
            else if (color == 5)
            {
                button261.BackColor = Color.MidnightBlue;
                text[260] = "O";
            }
            else if (color == 6)
            {
                button261.BackColor = Color.Magenta;
                text[260] = "C";
            }
        }

        private void button262_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button262.BackColor = Color.Green;
                text[261] = "W";
            }
            else if (color == 2)
            {
                button262.BackColor = Color.Red;
                text[261] = "E";
            }
            else if (color == 3)
            {
                button262.BackColor = Color.Blue;
                text[261] = "H";
            }
            else if (color == 4)
            {
                button262.BackColor = Color.Yellow;
                text[261] = "F";
            }
            else if (color == 5)
            {
                button262.BackColor = Color.MidnightBlue;
                text[261] = "O";
            }
            else if (color == 6)
            {
                button262.BackColor = Color.Magenta;
                text[261] = "C";
            }
        }

        private void button263_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button263.BackColor = Color.Green;
                text[262] = "W";
            }
            else if (color == 2)
            {
                button263.BackColor = Color.Red;
                text[262] = "E";
            }
            else if (color == 3)
            {
                button263.BackColor = Color.Blue;
                text[262] = "H";
            }
            else if (color == 4)
            {
                button263.BackColor = Color.Yellow;
                text[262] = "F";
            }
            else if (color == 5)
            {
                button263.BackColor = Color.MidnightBlue;
                text[262] = "O";
            }
            else if (color == 6)
            {
                button263.BackColor = Color.Magenta;
                text[262] = "C";
            }
        }

        private void button264_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button264.BackColor = Color.Green;
                text[263] = "W";
            }
            else if (color == 2)
            {
                button264.BackColor = Color.Red;
                text[263] = "E";
            }
            else if (color == 3)
            {
                button264.BackColor = Color.Blue;
                text[263] = "H";
            }
            else if (color == 4)
            {
                button264.BackColor = Color.Yellow;
                text[263] = "F";
            }
            else if (color == 5)
            {
                button264.BackColor = Color.MidnightBlue;
                text[263] = "O";
            }
            else if (color == 6)
            {
                button264.BackColor = Color.Magenta;
                text[263] = "C";
            }
        }

        private void button265_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button265.BackColor = Color.Green;
                text[264] = "W";
            }
            else if (color == 2)
            {
                button265.BackColor = Color.Red;
                text[264] = "E";
            }
            else if (color == 3)
            {
                button265.BackColor = Color.Blue;
                text[264] = "H";
            }
            else if (color == 4)
            {
                button265.BackColor = Color.Yellow;
                text[264] = "F";
            }
            else if (color == 5)
            {
                button265.BackColor = Color.MidnightBlue;
                text[264] = "O";
            }
            else if (color == 6)
            {
                button265.BackColor = Color.Magenta;
                text[264] = "C";
            }
        }

        private void button266_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button266.BackColor = Color.Green;
                text[265] = "W";
            }
            else if (color == 2)
            {
                button266.BackColor = Color.Red;
                text[265] = "E";
            }
            else if (color == 3)
            {
                button266.BackColor = Color.Blue;
                text[265] = "H";
            }
            else if (color == 4)
            {
                button266.BackColor = Color.Yellow;
                text[265] = "F";
            }
            else if (color == 5)
            {
                button266.BackColor = Color.MidnightBlue;
                text[265] = "O";
            }
            else if (color == 6)
            {
                button266.BackColor = Color.Magenta;
                text[265] = "C";
            }
        }

        private void button267_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button267.BackColor = Color.Green;
                text[266] = "W";
            }
            else if (color == 2)
            {
                button267.BackColor = Color.Red;
                text[266] = "E";
            }
            else if (color == 3)
            {
                button267.BackColor = Color.Blue;
                text[266] = "H";
            }
            else if (color == 4)
            {
                button267.BackColor = Color.Yellow;
                text[266] = "F";
            }
            else if (color == 5)
            {
                button267.BackColor = Color.MidnightBlue;
                text[266] = "O";
            }
            else if (color == 6)
            {
                button267.BackColor = Color.Magenta;
                text[266] = "C";
            }
        }

        private void button268_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button268.BackColor = Color.Green;
                text[267] = "W";
            }
            else if (color == 2)
            {
                button268.BackColor = Color.Red;
                text[267] = "E";
            }
            else if (color == 3)
            {
                button268.BackColor = Color.Blue;
                text[267] = "H";
            }
            else if (color == 4)
            {
                button268.BackColor = Color.Yellow;
                text[267] = "F";
            }
            else if (color == 5)
            {
                button268.BackColor = Color.MidnightBlue;
                text[267] = "O";
            }
            else if (color == 6)
            {
                button268.BackColor = Color.Magenta;
                text[267] = "C";
            }
        }

        private void button269_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button269.BackColor = Color.Green;
                text[268] = "W";
            }
            else if (color == 2)
            {
                button269.BackColor = Color.Red;
                text[268] = "E";
            }
            else if (color == 3)
            {
                button269.BackColor = Color.Blue;
                text[268] = "H";
            }
            else if (color == 4)
            {
                button269.BackColor = Color.Yellow;
                text[268] = "F";
            }
            else if (color == 5)
            {
                button269.BackColor = Color.MidnightBlue;
                text[268] = "O";
            }
            else if (color == 6)
            {
                button269.BackColor = Color.Magenta;
                text[268] = "C";
            }
        }

        private void button270_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button270.BackColor = Color.Green;
                text[269] = "W";
            }
            else if (color == 2)
            {
                button270.BackColor = Color.Red;
                text[269] = "E";
            }
            else if (color == 3)
            {
                button270.BackColor = Color.Blue;
                text[269] = "H";
            }
            else if (color == 4)
            {
                button270.BackColor = Color.Yellow;
                text[269] = "F";
            }
            else if (color == 5)
            {
                button270.BackColor = Color.MidnightBlue;
                text[269] = "O";
            }
            else if (color == 6)
            {
                button270.BackColor = Color.Magenta;
                text[269] = "C";
            }
        }

        private void button271_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button271.BackColor = Color.Green;
                text[270] = "W";
            }
            else if (color == 2)
            {
                button271.BackColor = Color.Red;
                text[270] = "E";
            }
            else if (color == 3)
            {
                button271.BackColor = Color.Blue;
                text[270] = "H";
            }
            else if (color == 4)
            {
                button271.BackColor = Color.Yellow;
                text[270] = "F";
            }
            else if (color == 5)
            {
                button271.BackColor = Color.MidnightBlue;
                text[270] = "O";
            }
            else if (color == 6)
            {
                button271.BackColor = Color.Magenta;
                text[270] = "C";
            }
        }

        private void button272_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button272.BackColor = Color.Green;
                text[271] = "W";
            }
            else if (color == 2)
            {
                button272.BackColor = Color.Red;
                text[271] = "E";
            }
            else if (color == 3)
            {
                button272.BackColor = Color.Blue;
                text[271] = "H";
            }
            else if (color == 4)
            {
                button272.BackColor = Color.Yellow;
                text[271] = "F";
            }
            else if (color == 5)
            {
                button272.BackColor = Color.MidnightBlue;
                text[271] = "O";
            }
            else if (color == 6)
            {
                button272.BackColor = Color.Magenta;
                text[271] = "C";
            }
        }

        private void button273_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button273.BackColor = Color.Green;
                text[272] = "W";
            }
            else if (color == 2)
            {
                button273.BackColor = Color.Red;
                text[272] = "E";
            }
            else if (color == 3)
            {
                button273.BackColor = Color.Blue;
                text[272] = "H";
            }
            else if (color == 4)
            {
                button273.BackColor = Color.Yellow;
                text[272] = "F";
            }
            else if (color == 5)
            {
                button273.BackColor = Color.MidnightBlue;
                text[272] = "O";
            }
            else if (color == 6)
            {
                button273.BackColor = Color.Magenta;
                text[272] = "C";
            }
        }

        private void button274_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button274.BackColor = Color.Green;
                text[273] = "W";
            }
            else if (color == 2)
            {
                button274.BackColor = Color.Red;
                text[273] = "E";
            }
            else if (color == 3)
            {
                button274.BackColor = Color.Blue;
                text[273] = "H";
            }
            else if (color == 4)
            {
                button274.BackColor = Color.Yellow;
                text[273] = "F";
            }
            else if (color == 5)
            {
                button274.BackColor = Color.MidnightBlue;
                text[273] = "O";
            }
            else if (color == 6)
            {
                button274.BackColor = Color.Magenta;
                text[273] = "C";
            }
        }

        private void button275_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button275.BackColor = Color.Green;
                text[274] = "W";
            }
            else if (color == 2)
            {
                button275.BackColor = Color.Red;
                text[274] = "E";
            }
            else if (color == 3)
            {
                button275.BackColor = Color.Blue;
                text[274] = "H";
            }
            else if (color == 4)
            {
                button275.BackColor = Color.Yellow;
                text[274] = "F";
            }
            else if (color == 5)
            {
                button275.BackColor = Color.MidnightBlue;
                text[274] = "O";
            }
            else if (color == 6)
            {
                button275.BackColor = Color.Magenta;
                text[274] = "C";
            }
        }

        private void button276_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button276.BackColor = Color.Green;
                text[275] = "W";
            }
            else if (color == 2)
            {
                button276.BackColor = Color.Red;
                text[275] = "E";
            }
            else if (color == 3)
            {
                button276.BackColor = Color.Blue;
                text[275] = "H";
            }
            else if (color == 4)
            {
                button276.BackColor = Color.Yellow;
                text[275] = "F";
            }
            else if (color == 5)
            {
                button276.BackColor = Color.MidnightBlue;
                text[275] = "O";
            }
            else if (color == 6)
            {
                button276.BackColor = Color.Magenta;
                text[275] = "C";
            }
        }

        private void button277_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button277.BackColor = Color.Green;
                text[276] = "W";
            }
            else if (color == 2)
            {
                button277.BackColor = Color.Red;
                text[276] = "E";
            }
            else if (color == 3)
            {
                button277.BackColor = Color.Blue;
                text[276] = "H";
            }
            else if (color == 4)
            {
                button277.BackColor = Color.Yellow;
                text[276] = "F";
            }
            else if (color == 5)
            {
                button277.BackColor = Color.MidnightBlue;
                text[276] = "O";
            }
            else if (color == 6)
            {
                button277.BackColor = Color.Magenta;
                text[276] = "C";
            }
        }

        private void button278_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button278.BackColor = Color.Green;
                text[277] = "W";
            }
            else if (color == 2)
            {
                button278.BackColor = Color.Red;
                text[277] = "E";
            }
            else if (color == 3)
            {
                button278.BackColor = Color.Blue;
                text[277] = "H";
            }
            else if (color == 4)
            {
                button278.BackColor = Color.Yellow;
                text[277] = "F";
            }
            else if (color == 5)
            {
                button278.BackColor = Color.MidnightBlue;
                text[277] = "O";
            }
            else if (color == 6)
            {
                button278.BackColor = Color.Magenta;
                text[277] = "C";
            }
        }

        private void button279_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button279.BackColor = Color.Green;
                text[278] = "W";
            }
            else if (color == 2)
            {
                button279.BackColor = Color.Red;
                text[278] = "E";
            }
            else if (color == 3)
            {
                button279.BackColor = Color.Blue;
                text[278] = "H";
            }
            else if (color == 4)
            {
                button279.BackColor = Color.Yellow;
                text[278] = "F";
            }
            else if (color == 5)
            {
                button279.BackColor = Color.MidnightBlue;
                text[278] = "O";
            }
            else if (color == 6)
            {
                button279.BackColor = Color.Magenta;
                text[278] = "C";
            }
        }

        private void button280_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button280.BackColor = Color.Green;
                text[279] = "W";
            }
            else if (color == 2)
            {
                button280.BackColor = Color.Red;
                text[279] = "E";
            }
            else if (color == 3)
            {
                button280.BackColor = Color.Blue;
                text[279] = "H";
            }
            else if (color == 4)
            {
                button280.BackColor = Color.Yellow;
                text[279] = "F";
            }
            else if (color == 5)
            {
                button280.BackColor = Color.MidnightBlue;
                text[279] = "O";
            }
            else if (color == 6)
            {
                button280.BackColor = Color.Magenta;
                text[279] = "C";
            }
        }

        private void button281_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button281.BackColor = Color.Green;
                text[280] = "W";
            }
            else if (color == 2)
            {
                button281.BackColor = Color.Red;
                text[280] = "E";
            }
            else if (color == 3)
            {
                button281.BackColor = Color.Blue;
                text[280] = "H";
            }
            else if (color == 4)
            {
                button281.BackColor = Color.Yellow;
                text[280] = "F";
            }
            else if (color == 5)
            {
                button281.BackColor = Color.MidnightBlue;
                text[280] = "O";
            }
            else if (color == 6)
            {
                button281.BackColor = Color.Magenta;
                text[280] = "C";
            }
        }

        private void button282_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button282.BackColor = Color.Green;
                text[281] = "W";
            }
            else if (color == 2)
            {
                button282.BackColor = Color.Red;
                text[281] = "E";
            }
            else if (color == 3)
            {
                button282.BackColor = Color.Blue;
                text[281] = "H";
            }
            else if (color == 4)
            {
                button282.BackColor = Color.Yellow;
                text[281] = "F";
            }
            else if (color == 5)
            {
                button282.BackColor = Color.MidnightBlue;
                text[281] = "O";
            }
            else if (color == 6)
            {
                button282.BackColor = Color.Magenta;
                text[281] = "C";
            }
        }

        private void button283_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button283.BackColor = Color.Green;
                text[282] = "W";
            }
            else if (color == 2)
            {
                button283.BackColor = Color.Red;
                text[282] = "E";
            }
            else if (color == 3)
            {
                button283.BackColor = Color.Blue;
                text[280] = "H";
            }
            else if (color == 4)
            {
                button283.BackColor = Color.Yellow;
                text[282] = "F";
            }
            else if (color == 5)
            {
                button283.BackColor = Color.MidnightBlue;
                text[282] = "O";
            }
            else if (color == 6)
            {
                button283.BackColor = Color.Magenta;
                text[282] = "C";
            }
        }

        private void button284_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button284.BackColor = Color.Green;
                text[283] = "W";
            }
            else if (color == 2)
            {
                button284.BackColor = Color.Red;
                text[283] = "E";
            }
            else if (color == 3)
            {
                button284.BackColor = Color.Blue;
                text[283] = "H";
            }
            else if (color == 4)
            {
                button284.BackColor = Color.Yellow;
                text[283] = "F";
            }
            else if (color == 5)
            {
                button284.BackColor = Color.MidnightBlue;
                text[283] = "O";
            }
            else if (color == 6)
            {
                button284.BackColor = Color.Magenta;
                text[283] = "C";
            }
        }

        private void button285_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button285.BackColor = Color.Green;
                text[284] = "W";
            }
            else if (color == 2)
            {
                button285.BackColor = Color.Red;
                text[284] = "E";
            }
            else if (color == 3)
            {
                button285.BackColor = Color.Blue;
                text[284] = "H";
            }
            else if (color == 4)
            {
                button285.BackColor = Color.Yellow;
                text[284] = "F";
            }
            else if (color == 5)
            {
                button285.BackColor = Color.MidnightBlue;
                text[284] = "O";
            }
            else if (color == 6)
            {
                button285.BackColor = Color.Magenta;
                text[284] = "C";
            }
        }

        private void button286_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button286.BackColor = Color.Green;
                text[285] = "W";
            }
            else if (color == 2)
            {
                button286.BackColor = Color.Red;
                text[285] = "E";
            }
            else if (color == 3)
            {
                button286.BackColor = Color.Blue;
                text[285] = "H";
            }
            else if (color == 4)
            {
                button286.BackColor = Color.Yellow;
                text[285] = "F";
            }
            else if (color == 5)
            {
                button286.BackColor = Color.MidnightBlue;
                text[285] = "O";
            }
            else if (color == 6)
            {
                button286.BackColor = Color.Magenta;
                text[285] = "C";
            }
        }

        private void button287_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button287.BackColor = Color.Green;
                text[286] = "W";
            }
            else if (color == 2)
            {
                button287.BackColor = Color.Red;
                text[286] = "E";
            }
            else if (color == 3)
            {
                button287.BackColor = Color.Blue;
                text[286] = "H";
            }
            else if (color == 4)
            {
                button287.BackColor = Color.Yellow;
                text[286] = "F";
            }
            else if (color == 5)
            {
                button287.BackColor = Color.MidnightBlue;
                text[286] = "O";
            }
            else if (color == 6)
            {
                button287.BackColor = Color.Magenta;
                text[286] = "C";
            }
        }

        private void button288_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button288.BackColor = Color.Green;
                text[287] = "W";
            }
            else if (color == 2)
            {
                button288.BackColor = Color.Red;
                text[287] = "E";
            }
            else if (color == 3)
            {
                button288.BackColor = Color.Blue;
                text[287] = "H";
            }
            else if (color == 4)
            {
                button288.BackColor = Color.Yellow;
                text[287] = "F";
            }
            else if (color == 5)
            {
                button288.BackColor = Color.MidnightBlue;
                text[287] = "O";
            }
            else if (color == 6)
            {
                button288.BackColor = Color.Magenta;
                text[287] = "C";
            }
        }
        #endregion

        #region Left 1 Code
        private void button289_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button289.BackColor = Color.Green;
                text[288] = "W";
            }
            else if (color == 2)
            {
                button289.BackColor = Color.Red;
                text[288] = "E";
            }
            else if (color == 3)
            {
                button289.BackColor = Color.Blue;
                text[288] = "H";
            }
            else if (color == 4)
            {
                button289.BackColor = Color.Yellow;
                text[288] = "F";
            }
            else if (color == 5)
            {
                button289.BackColor = Color.MidnightBlue;
                text[288] = "O";
            }
            else if (color == 6)
            {
                button289.BackColor = Color.Magenta;
                text[288] = "C";
            }
        }

        private void button290_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button290.BackColor = Color.Green;
                text[289] = "W";
            }
            else if (color == 2)
            {
                button290.BackColor = Color.Red;
                text[289] = "E";
            }
            else if (color == 3)
            {
                button290.BackColor = Color.Blue;
                text[289] = "H";
            }
            else if (color == 4)
            {
                button290.BackColor = Color.Yellow;
                text[289] = "F";
            }
            else if (color == 5)
            {
                button290.BackColor = Color.MidnightBlue;
                text[289] = "O";
            }
            else if (color == 6)
            {
                button290.BackColor = Color.Magenta;
                text[289] = "C";
            }
        }

        private void button291_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button291.BackColor = Color.Green;
                text[290] = "W";
            }
            else if (color == 2)
            {
                button291.BackColor = Color.Red;
                text[290] = "E";
            }
            else if (color == 3)
            {
                button291.BackColor = Color.Blue;
                text[290] = "H";
            }
            else if (color == 4)
            {
                button291.BackColor = Color.Yellow;
                text[290] = "F";
            }
            else if (color == 5)
            {
                button291.BackColor = Color.MidnightBlue;
                text[290] = "O";
            }
            else if (color == 6)
            {
                button291.BackColor = Color.Magenta;
                text[290] = "C";
            }
        }

        private void button292_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button292.BackColor = Color.Green;
                text[291] = "W";
            }
            else if (color == 2)
            {
                button292.BackColor = Color.Red;
                text[291] = "E";
            }
            else if (color == 3)
            {
                button292.BackColor = Color.Blue;
                text[291] = "H";
            }
            else if (color == 4)
            {
                button292.BackColor = Color.Yellow;
                text[291] = "F";
            }
            else if (color == 5)
            {
                button292.BackColor = Color.MidnightBlue;
                text[291] = "O";
            }
            else if (color == 6)
            {
                button292.BackColor = Color.Magenta;
                text[291] = "C";
            }
        }

        private void button293_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button293.BackColor = Color.Green;
                text[292] = "W";
            }
            else if (color == 2)
            {
                button293.BackColor = Color.Red;
                text[292] = "E";
            }
            else if (color == 3)
            {
                button293.BackColor = Color.Blue;
                text[292] = "H";
            }
            else if (color == 4)
            {
                button293.BackColor = Color.Yellow;
                text[292] = "F";
            }
            else if (color == 5)
            {
                button293.BackColor = Color.MidnightBlue;
                text[292] = "O";
            }
            else if (color == 6)
            {
                button293.BackColor = Color.Magenta;
                text[292] = "C";
            }
        }

        private void button294_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button294.BackColor = Color.Green;
                text[293] = "W";
            }
            else if (color == 2)
            {
                button294.BackColor = Color.Red;
                text[293] = "E";
            }
            else if (color == 3)
            {
                button294.BackColor = Color.Blue;
                text[293] = "H";
            }
            else if (color == 4)
            {
                button294.BackColor = Color.Yellow;
                text[293] = "F";
            }
            else if (color == 5)
            {
                button294.BackColor = Color.MidnightBlue;
                text[293] = "O";
            }
            else if (color == 6)
            {
                button294.BackColor = Color.Magenta;
                text[293] = "C";
            }
        }

        private void button295_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button295.BackColor = Color.Green;
                text[294] = "W";
            }
            else if (color == 2)
            {
                button295.BackColor = Color.Red;
                text[294] = "E";
            }
            else if (color == 3)
            {
                button295.BackColor = Color.Blue;
                text[294] = "H";
            }
            else if (color == 4)
            {
                button295.BackColor = Color.Yellow;
                text[294] = "F";
            }
            else if (color == 5)
            {
                button295.BackColor = Color.MidnightBlue;
                text[294] = "O";
            }
            else if (color == 6)
            {
                button295.BackColor = Color.Magenta;
                text[294] = "C";
            }
        }

        private void button296_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button296.BackColor = Color.Green;
                text[295] = "W";
            }
            else if (color == 2)
            {
                button296.BackColor = Color.Red;
                text[295] = "E";
            }
            else if (color == 3)
            {
                button296.BackColor = Color.Blue;
                text[295] = "H";
            }
            else if (color == 4)
            {
                button296.BackColor = Color.Yellow;
                text[295] = "F";
            }
            else if (color == 5)
            {
                button296.BackColor = Color.MidnightBlue;
                text[295] = "O";
            }
            else if (color == 6)
            {
                button296.BackColor = Color.Magenta;
                text[295] = "C";
            }
        }

        private void button297_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button297.BackColor = Color.Green;
                text[296] = "W";
            }
            else if (color == 2)
            {
                button297.BackColor = Color.Red;
                text[296] = "E";
            }
            else if (color == 3)
            {
                button297.BackColor = Color.Blue;
                text[296] = "H";
            }
            else if (color == 4)
            {
                button297.BackColor = Color.Yellow;
                text[296] = "F";
            }
            else if (color == 5)
            {
                button297.BackColor = Color.MidnightBlue;
                text[296] = "O";
            }
            else if (color == 6)
            {
                button297.BackColor = Color.Magenta;
                text[296] = "C";
            }
        }

        private void button298_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button298.BackColor = Color.Green;
                text[297] = "W";
            }
            else if (color == 2)
            {
                button298.BackColor = Color.Red;
                text[297] = "E";
            }
            else if (color == 3)
            {
                button298.BackColor = Color.Blue;
                text[297] = "H";
            }
            else if (color == 4)
            {
                button298.BackColor = Color.Yellow;
                text[297] = "F";
            }
            else if (color == 5)
            {
                button298.BackColor = Color.MidnightBlue;
                text[297] = "O";
            }
            else if (color == 6)
            {
                button298.BackColor = Color.Magenta;
                text[297] = "C";
            }
        }

        private void button299_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button299.BackColor = Color.Green;
                text[298] = "W";
            }
            else if (color == 2)
            {
                button299.BackColor = Color.Red;
                text[298] = "E";
            }
            else if (color == 3)
            {
                button299.BackColor = Color.Blue;
                text[298] = "H";
            }
            else if (color == 4)
            {
                button299.BackColor = Color.Yellow;
                text[298] = "F";
            }
            else if (color == 5)
            {
                button299.BackColor = Color.MidnightBlue;
                text[298] = "O";
            }
            else if (color == 6)
            {
                button299.BackColor = Color.Magenta;
                text[298] = "C";
            }
        }

        private void button300_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button300.BackColor = Color.Green;
                text[299] = "W";
            }
            else if (color == 2)
            {
                button300.BackColor = Color.Red;
                text[299] = "E";
            }
            else if (color == 3)
            {
                button300.BackColor = Color.Blue;
                text[299] = "H";
            }
            else if (color == 4)
            {
                button300.BackColor = Color.Yellow;
                text[299] = "F";
            }
            else if (color == 5)
            {
                button300.BackColor = Color.MidnightBlue;
                text[299] = "O";
            }
            else if (color == 6)
            {
                button300.BackColor = Color.Magenta;
                text[299] = "C";
            }
        }

        private void button301_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button301.BackColor = Color.Green;
                text[300] = "W";
            }
            else if (color == 2)
            {
                button301.BackColor = Color.Red;
                text[300] = "E";
            }
            else if (color == 3)
            {
                button301.BackColor = Color.Blue;
                text[300] = "H";
            }
            else if (color == 4)
            {
                button301.BackColor = Color.Yellow;
                text[300] = "F";
            }
            else if (color == 5)
            {
                button301.BackColor = Color.MidnightBlue;
                text[300] = "O";
            }
            else if (color == 6)
            {
                button301.BackColor = Color.Magenta;
                text[300] = "C";
            }
        }

        private void button302_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button302.BackColor = Color.Green;
                text[301] = "W";
            }
            else if (color == 2)
            {
                button302.BackColor = Color.Red;
                text[301] = "E";
            }
            else if (color == 3)
            {
                button302.BackColor = Color.Blue;
                text[301] = "H";
            }
            else if (color == 4)
            {
                button302.BackColor = Color.Yellow;
                text[301] = "F";
            }
            else if (color == 5)
            {
                button302.BackColor = Color.MidnightBlue;
                text[301] = "O";
            }
            else if (color == 6)
            {
                button302.BackColor = Color.Magenta;
                text[301] = "C";
            }
        }

        private void button303_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button303.BackColor = Color.Green;
                text[302] = "W";
            }
            else if (color == 2)
            {
                button303.BackColor = Color.Red;
                text[302] = "E";
            }
            else if (color == 3)
            {
                button303.BackColor = Color.Blue;
                text[302] = "H";
            }
            else if (color == 4)
            {
                button303.BackColor = Color.Yellow;
                text[302] = "F";
            }
            else if (color == 5)
            {
                button303.BackColor = Color.MidnightBlue;
                text[302] = "O";
            }
            else if (color == 6)
            {
                button303.BackColor = Color.Magenta;
                text[302] = "C";
            }
        }

        private void button304_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button304.BackColor = Color.Green;
                text[303] = "W";
            }
            else if (color == 2)
            {
                button304.BackColor = Color.Red;
                text[303] = "E";
            }
            else if (color == 3)
            {
                button304.BackColor = Color.Blue;
                text[303] = "H";
            }
            else if (color == 4)
            {
                button304.BackColor = Color.Yellow;
                text[303] = "F";
            }
            else if (color == 5)
            {
                button304.BackColor = Color.MidnightBlue;
                text[303] = "O";
            }
            else if (color == 6)
            {
                button304.BackColor = Color.Magenta;
                text[303] = "C";
            }
        }

        private void button305_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button305.BackColor = Color.Green;
                text[304] = "W";
            }
            else if (color == 2)
            {
                button305.BackColor = Color.Red;
                text[304] = "E";
            }
            else if (color == 3)
            {
                button305.BackColor = Color.Blue;
                text[304] = "H";
            }
            else if (color == 4)
            {
                button305.BackColor = Color.Yellow;
                text[304] = "F";
            }
            else if (color == 5)
            {
                button305.BackColor = Color.MidnightBlue;
                text[304] = "O";
            }
            else if (color == 6)
            {
                button305.BackColor = Color.Magenta;
                text[304] = "C";
            }
        }

        private void button306_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button306.BackColor = Color.Green;
                text[305] = "W";
            }
            else if (color == 2)
            {
                button306.BackColor = Color.Red;
                text[305] = "E";
            }
            else if (color == 3)
            {
                button306.BackColor = Color.Blue;
                text[305] = "H";
            }
            else if (color == 4)
            {
                button306.BackColor = Color.Yellow;
                text[305] = "F";
            }
            else if (color == 5)
            {
                button306.BackColor = Color.MidnightBlue;
                text[305] = "O";
            }
            else if (color == 6)
            {
                button306.BackColor = Color.Magenta;
                text[305] = "C";
            }
        }

        private void button307_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button307.BackColor = Color.Green;
                text[306] = "W";
            }
            else if (color == 2)
            {
                button307.BackColor = Color.Red;
                text[306] = "E";
            }
            else if (color == 3)
            {
                button307.BackColor = Color.Blue;
                text[306] = "H";
            }
            else if (color == 4)
            {
                button307.BackColor = Color.Yellow;
                text[306] = "F";
            }
            else if (color == 5)
            {
                button307.BackColor = Color.MidnightBlue;
                text[306] = "O";
            }
            else if (color == 6)
            {
                button307.BackColor = Color.Magenta;
                text[306] = "C";
            }
        }

        private void button308_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button308.BackColor = Color.Green;
                text[307] = "W";
            }
            else if (color == 2)
            {
                button308.BackColor = Color.Red;
                text[307] = "E";
            }
            else if (color == 3)
            {
                button308.BackColor = Color.Blue;
                text[307] = "H";
            }
            else if (color == 4)
            {
                button308.BackColor = Color.Yellow;
                text[307] = "F";
            }
            else if (color == 5)
            {
                button308.BackColor = Color.MidnightBlue;
                text[307] = "O";
            }
            else if (color == 6)
            {
                button308.BackColor = Color.Magenta;
                text[307] = "C";
            }
        }

        private void button309_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button309.BackColor = Color.Green;
                text[308] = "W";
            }
            else if (color == 2)
            {
                button309.BackColor = Color.Red;
                text[308] = "E";
            }
            else if (color == 3)
            {
                button309.BackColor = Color.Blue;
                text[308] = "H";
            }
            else if (color == 4)
            {
                button309.BackColor = Color.Yellow;
                text[308] = "F";
            }
            else if (color == 5)
            {
                button309.BackColor = Color.MidnightBlue;
                text[308] = "O";
            }
            else if (color == 6)
            {
                button309.BackColor = Color.Magenta;
                text[308] = "C";
            }
        }

        private void button310_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button310.BackColor = Color.Green;
                text[309] = "W";
            }
            else if (color == 2)
            {
                button310.BackColor = Color.Red;
                text[309] = "E";
            }
            else if (color == 3)
            {
                button310.BackColor = Color.Blue;
                text[309] = "H";
            }
            else if (color == 4)
            {
                button310.BackColor = Color.Yellow;
                text[309] = "F";
            }
            else if (color == 5)
            {
                button310.BackColor = Color.MidnightBlue;
                text[309] = "O";
            }
            else if (color == 6)
            {
                button310.BackColor = Color.Magenta;
                text[309] = "C";
            }
        }

        private void button311_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button311.BackColor = Color.Green;
                text[310] = "W";
            }
            else if (color == 2)
            {
                button311.BackColor = Color.Red;
                text[310] = "E";
            }
            else if (color == 3)
            {
                button311.BackColor = Color.Blue;
                text[310] = "H";
            }
            else if (color == 4)
            {
                button311.BackColor = Color.Yellow;
                text[310] = "F";
            }
            else if (color == 5)
            {
                button311.BackColor = Color.MidnightBlue;
                text[310] = "O";
            }
            else if (color == 6)
            {
                button311.BackColor = Color.Magenta;
                text[310] = "C";
            }
        }

        private void button312_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button312.BackColor = Color.Green;
                text[311] = "W";
            }
            else if (color == 2)
            {
                button312.BackColor = Color.Red;
                text[311] = "E";
            }
            else if (color == 3)
            {
                button312.BackColor = Color.Blue;
                text[311] = "H";
            }
            else if (color == 4)
            {
                button312.BackColor = Color.Yellow;
                text[311] = "F";
            }
            else if (color == 5)
            {
                button312.BackColor = Color.MidnightBlue;
                text[311] = "O";
            }
            else if (color == 6)
            {
                button312.BackColor = Color.Magenta;
                text[311] = "C";
            }
        }

        private void button313_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button313.BackColor = Color.Green;
                text[312] = "W";
            }
            else if (color == 2)
            {
                button313.BackColor = Color.Red;
                text[312] = "E";
            }
            else if (color == 3)
            {
                button313.BackColor = Color.Blue;
                text[312] = "H";
            }
            else if (color == 4)
            {
                button313.BackColor = Color.Yellow;
                text[312] = "F";
            }
            else if (color == 5)
            {
                button313.BackColor = Color.MidnightBlue;
                text[312] = "O";
            }
            else if (color == 6)
            {
                button313.BackColor = Color.Magenta;
                text[312] = "C";
            }
        }

        private void button314_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button314.BackColor = Color.Green;
                text[313] = "W";
            }
            else if (color == 2)
            {
                button314.BackColor = Color.Red;
                text[313] = "E";
            }
            else if (color == 3)
            {
                button314.BackColor = Color.Blue;
                text[313] = "H";
            }
            else if (color == 4)
            {
                button314.BackColor = Color.Yellow;
                text[313] = "F";
            }
            else if (color == 5)
            {
                button314.BackColor = Color.MidnightBlue;
                text[313] = "O";
            }
            else if (color == 6)
            {
                button314.BackColor = Color.Magenta;
                text[313] = "C";
            }
        }

        private void button315_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button315.BackColor = Color.Green;
                text[314] = "W";
            }
            else if (color == 2)
            {
                button315.BackColor = Color.Red;
                text[314] = "E";
            }
            else if (color == 3)
            {
                button315.BackColor = Color.Blue;
                text[314] = "H";
            }
            else if (color == 4)
            {
                button315.BackColor = Color.Yellow;
                text[314] = "F";
            }
            else if (color == 5)
            {
                button315.BackColor = Color.MidnightBlue;
                text[314] = "O";
            }
            else if (color == 6)
            {
                button315.BackColor = Color.Magenta;
                text[314] = "C";
            }
        }

        private void button316_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button316.BackColor = Color.Green;
                text[315] = "W";
            }
            else if (color == 2)
            {
                button316.BackColor = Color.Red;
                text[315] = "E";
            }
            else if (color == 3)
            {
                button316.BackColor = Color.Blue;
                text[315] = "H";
            }
            else if (color == 4)
            {
                button316.BackColor = Color.Yellow;
                text[315] = "F";
            }
            else if (color == 5)
            {
                button316.BackColor = Color.MidnightBlue;
                text[315] = "O";
            }
            else if (color == 6)
            {
                button316.BackColor = Color.Magenta;
                text[315] = "C";
            }
        }

        private void button317_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button317.BackColor = Color.Green;
                text[316] = "W";
            }
            else if (color == 2)
            {
                button317.BackColor = Color.Red;
                text[316] = "E";
            }
            else if (color == 3)
            {
                button317.BackColor = Color.Blue;
                text[316] = "H";
            }
            else if (color == 4)
            {
                button317.BackColor = Color.Yellow;
                text[316] = "F";
            }
            else if (color == 5)
            {
                button317.BackColor = Color.MidnightBlue;
                text[316] = "O";
            }
            else if (color == 6)
            {
                button317.BackColor = Color.Magenta;
                text[316] = "C";
            }
        }

        private void button318_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button318.BackColor = Color.Green;
                text[317] = "W";
            }
            else if (color == 2)
            {
                button318.BackColor = Color.Red;
                text[317] = "E";
            }
            else if (color == 3)
            {
                button318.BackColor = Color.Blue;
                text[317] = "H";
            }
            else if (color == 4)
            {
                button318.BackColor = Color.Yellow;
                text[317] = "F";
            }
            else if (color == 5)
            {
                button318.BackColor = Color.MidnightBlue;
                text[317] = "O";
            }
            else if (color == 6)
            {
                button318.BackColor = Color.Magenta;
                text[317] = "C";
            }
        }

        private void button319_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button319.BackColor = Color.Green;
                text[318] = "W";
            }
            else if (color == 2)
            {
                button319.BackColor = Color.Red;
                text[318] = "E";
            }
            else if (color == 3)
            {
                button319.BackColor = Color.Blue;
                text[318] = "H";
            }
            else if (color == 4)
            {
                button319.BackColor = Color.Yellow;
                text[318] = "F";
            }
            else if (color == 5)
            {
                button319.BackColor = Color.MidnightBlue;
                text[318] = "O";
            }
            else if (color == 6)
            {
                button319.BackColor = Color.Magenta;
                text[318] = "C";
            }
        }

        private void button320_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button320.BackColor = Color.Green;
                text[319] = "W";
            }
            else if (color == 2)
            {
                button320.BackColor = Color.Red;
                text[319] = "E";
            }
            else if (color == 3)
            {
                button320.BackColor = Color.Blue;
                text[319] = "H";
            }
            else if (color == 4)
            {
                button320.BackColor = Color.Yellow;
                text[319] = "F";
            }
            else if (color == 5)
            {
                button320.BackColor = Color.MidnightBlue;
                text[319] = "O";
            }
            else if (color == 6)
            {
                button320.BackColor = Color.Magenta;
                text[319] = "C";
            }
        }

        private void button321_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button321.BackColor = Color.Green;
                text[320] = "W";
            }
            else if (color == 2)
            {
                button321.BackColor = Color.Red;
                text[320] = "E";
            }
            else if (color == 3)
            {
                button321.BackColor = Color.Blue;
                text[320] = "H";
            }
            else if (color == 4)
            {
                button321.BackColor = Color.Yellow;
                text[320] = "F";
            }
            else if (color == 5)
            {
                button321.BackColor = Color.MidnightBlue;
                text[320] = "O";
            }
            else if (color == 6)
            {
                button321.BackColor = Color.Magenta;
                text[320] = "C";
            }
        }

        private void button322_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button322.BackColor = Color.Green;
                text[321] = "W";
            }
            else if (color == 2)
            {
                button322.BackColor = Color.Red;
                text[321] = "E";
            }
            else if (color == 3)
            {
                button322.BackColor = Color.Blue;
                text[321] = "H";
            }
            else if (color == 4)
            {
                button322.BackColor = Color.Yellow;
                text[321] = "F";
            }
            else if (color == 5)
            {
                button322.BackColor = Color.MidnightBlue;
                text[321] = "O";
            }
            else if (color == 6)
            {
                button322.BackColor = Color.Magenta;
                text[321] = "C";
            }
        }

        private void button323_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button323.BackColor = Color.Green;
                text[322] = "W";
            }
            else if (color == 2)
            {
                button323.BackColor = Color.Red;
                text[322] = "E";
            }
            else if (color == 3)
            {
                button323.BackColor = Color.Blue;
                text[322] = "H";
            }
            else if (color == 4)
            {
                button323.BackColor = Color.Yellow;
                text[322] = "F";
            }
            else if (color == 5)
            {
                button323.BackColor = Color.MidnightBlue;
                text[322] = "O";
            }
            else if (color == 6)
            {
                button323.BackColor = Color.Magenta;
                text[322] = "C";
            }
        }

        private void button324_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button324.BackColor = Color.Green;
                text[323] = "W";
            }
            else if (color == 2)
            {
                button324.BackColor = Color.Red;
                text[323] = "E";
            }
            else if (color == 3)
            {
                button324.BackColor = Color.Blue;
                text[323] = "H";
            }
            else if (color == 4)
            {
                button324.BackColor = Color.Yellow;
                text[323] = "F";
            }
            else if (color == 5)
            {
                button324.BackColor = Color.MidnightBlue;
                text[323] = "O";
            }
            else if (color == 6)
            {
                button324.BackColor = Color.Magenta;
                text[323] = "C";
            }
        }

        private void button325_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button325.BackColor = Color.Green;
                text[324] = "W";
            }
            else if (color == 2)
            {
                button325.BackColor = Color.Red;
                text[324] = "E";
            }
            else if (color == 3)
            {
                button325.BackColor = Color.Blue;
                text[324] = "H";
            }
            else if (color == 4)
            {
                button325.BackColor = Color.Yellow;
                text[324] = "F";
            }
            else if (color == 5)
            {
                button325.BackColor = Color.MidnightBlue;
                text[324] = "O";
            }
            else if (color == 6)
            {
                button325.BackColor = Color.Magenta;
                text[324] = "C";
            }
        }

        private void button326_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button326.BackColor = Color.Green;
                text[325] = "W";
            }
            else if (color == 2)
            {
                button326.BackColor = Color.Red;
                text[325] = "E";
            }
            else if (color == 3)
            {
                button326.BackColor = Color.Blue;
                text[325] = "H";
            }
            else if (color == 4)
            {
                button326.BackColor = Color.Yellow;
                text[325] = "F";
            }
            else if (color == 5)
            {
                button326.BackColor = Color.MidnightBlue;
                text[325] = "O";
            }
            else if (color == 6)
            {
                button326.BackColor = Color.Magenta;
                text[325] = "C";
            }
        }

        private void button327_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button327.BackColor = Color.Green;
                text[326] = "W";
            }
            else if (color == 2)
            {
                button327.BackColor = Color.Red;
                text[326] = "E";
            }
            else if (color == 3)
            {
                button327.BackColor = Color.Blue;
                text[326] = "H";
            }
            else if (color == 4)
            {
                button327.BackColor = Color.Yellow;
                text[326] = "F";
            }
            else if (color == 5)
            {
                button327.BackColor = Color.MidnightBlue;
                text[326] = "O";
            }
            else if (color == 6)
            {
                button327.BackColor = Color.Magenta;
                text[326] = "C";
            }
        }

        private void button328_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button328.BackColor = Color.Green;
                text[327] = "W";
            }
            else if (color == 2)
            {
                button328.BackColor = Color.Red;
                text[327] = "E";
            }
            else if (color == 3)
            {
                button328.BackColor = Color.Blue;
                text[327] = "H";
            }
            else if (color == 4)
            {
                button328.BackColor = Color.Yellow;
                text[327] = "F";
            }
            else if (color == 5)
            {
                button328.BackColor = Color.MidnightBlue;
                text[327] = "O";
            }
            else if (color == 6)
            {
                button328.BackColor = Color.Magenta;
                text[327] = "C";
            }
        }

        private void button329_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button329.BackColor = Color.Green;
                text[328] = "W";
            }
            else if (color == 2)
            {
                button329.BackColor = Color.Red;
                text[328] = "E";
            }
            else if (color == 3)
            {
                button329.BackColor = Color.Blue;
                text[328] = "H";
            }
            else if (color == 4)
            {
                button329.BackColor = Color.Yellow;
                text[328] = "F";
            }
            else if (color == 5)
            {
                button329.BackColor = Color.MidnightBlue;
                text[328] = "O";
            }
            else if (color == 6)
            {
                button329.BackColor = Color.Magenta;
                text[328] = "C";
            }
        }

        private void button330_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button330.BackColor = Color.Green;
                text[329] = "W";
            }
            else if (color == 2)
            {
                button330.BackColor = Color.Red;
                text[329] = "E";
            }
            else if (color == 3)
            {
                button330.BackColor = Color.Blue;
                text[329] = "H";
            }
            else if (color == 4)
            {
                button330.BackColor = Color.Yellow;
                text[329] = "F";
            }
            else if (color == 5)
            {
                button330.BackColor = Color.MidnightBlue;
                text[329] = "O";
            }
            else if (color == 6)
            {
                button330.BackColor = Color.Magenta;
                text[329] = "C";
            }
        }

        private void button331_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button331.BackColor = Color.Green;
                text[330] = "W";
            }
            else if (color == 2)
            {
                button331.BackColor = Color.Red;
                text[330] = "E";
            }
            else if (color == 3)
            {
                button331.BackColor = Color.Blue;
                text[330] = "H";
            }
            else if (color == 4)
            {
                button331.BackColor = Color.Yellow;
                text[330] = "F";
            }
            else if (color == 5)
            {
                button331.BackColor = Color.MidnightBlue;
                text[330] = "O";
            }
            else if (color == 6)
            {
                button331.BackColor = Color.Magenta;
                text[330] = "C";
            }
        }

        private void button332_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button332.BackColor = Color.Green;
                text[331] = "W";
            }
            else if (color == 2)
            {
                button332.BackColor = Color.Red;
                text[331] = "E";
            }
            else if (color == 3)
            {
                button332.BackColor = Color.Blue;
                text[331] = "H";
            }
            else if (color == 4)
            {
                button332.BackColor = Color.Yellow;
                text[331] = "F";
            }
            else if (color == 5)
            {
                button332.BackColor = Color.MidnightBlue;
                text[331] = "O";
            }
            else if (color == 6)
            {
                button332.BackColor = Color.Magenta;
                text[331] = "C";
            }
        }

        private void button333_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button333.BackColor = Color.Green;
                text[332] = "W";
            }
            else if (color == 2)
            {
                button333.BackColor = Color.Red;
                text[332] = "E";
            }
            else if (color == 3)
            {
                button333.BackColor = Color.Blue;
                text[332] = "H";
            }
            else if (color == 4)
            {
                button333.BackColor = Color.Yellow;
                text[332] = "F";
            }
            else if (color == 5)
            {
                button333.BackColor = Color.MidnightBlue;
                text[332] = "O";
            }
            else if (color == 6)
            {
                button333.BackColor = Color.Magenta;
                text[332] = "C";
            }
        }

        private void button334_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button334.BackColor = Color.Green;
                text[333] = "W";
            }
            else if (color == 2)
            {
                button334.BackColor = Color.Red;
                text[333] = "E";
            }
            else if (color == 3)
            {
                button334.BackColor = Color.Blue;
                text[333] = "H";
            }
            else if (color == 4)
            {
                button334.BackColor = Color.Yellow;
                text[333] = "F";
            }
            else if (color == 5)
            {
                button334.BackColor = Color.MidnightBlue;
                text[333] = "O";
            }
            else if (color == 6)
            {
                button334.BackColor = Color.Magenta;
                text[333] = "C";
            }
        }

        private void button335_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button335.BackColor = Color.Green;
                text[334] = "W";
            }
            else if (color == 2)
            {
                button335.BackColor = Color.Red;
                text[334] = "E";
            }
            else if (color == 3)
            {
                button335.BackColor = Color.Blue;
                text[334] = "H";
            }
            else if (color == 4)
            {
                button335.BackColor = Color.Yellow;
                text[334] = "F";
            }
            else if (color == 5)
            {
                button335.BackColor = Color.MidnightBlue;
                text[334] = "O";
            }
            else if (color == 6)
            {
                button335.BackColor = Color.Magenta;
                text[334] = "C";
            }
        }

        private void button336_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button336.BackColor = Color.Green;
                text[335] = "W";
            }
            else if (color == 2)
            {
                button336.BackColor = Color.Red;
                text[335] = "E";
            }
            else if (color == 3)
            {
                button336.BackColor = Color.Blue;
                text[335] = "H";
            }
            else if (color == 4)
            {
                button336.BackColor = Color.Yellow;
                text[335] = "F";
            }
            else if (color == 5)
            {
                button336.BackColor = Color.MidnightBlue;
                text[335] = "O";
            }
            else if (color == 6)
            {
                button336.BackColor = Color.Magenta;
                text[335] = "C";
            }
        }
        #endregion

        #region Right 1 Code
        private void button337_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button337.BackColor = Color.Green;
                text[336] = "W";
            }
            else if (color == 2)
            {
                button337.BackColor = Color.Red;
                text[336] = "E";
            }
            else if (color == 3)
            {
                button337.BackColor = Color.Blue;
                text[336] = "H";
            }
            else if (color == 4)
            {
                button337.BackColor = Color.Yellow;
                text[336] = "F";
            }
            else if (color == 5)
            {
                button337.BackColor = Color.MidnightBlue;
                text[336] = "O";
            }
            else if (color == 6)
            {
                button337.BackColor = Color.Magenta;
                text[336] = "C";
            }
        }

        private void button338_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button338.BackColor = Color.Green;
                text[337] = "W";
            }
            else if (color == 2)
            {
                button338.BackColor = Color.Red;
                text[337] = "E";
            }
            else if (color == 3)
            {
                button338.BackColor = Color.Blue;
                text[337] = "H";
            }
            else if (color == 4)
            {
                button338.BackColor = Color.Yellow;
                text[337] = "F";
            }
            else if (color == 5)
            {
                button338.BackColor = Color.MidnightBlue;
                text[337] = "O";
            }
            else if (color == 6)
            {
                button338.BackColor = Color.Magenta;
                text[337] = "C";
            }
        }

        private void button339_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button339.BackColor = Color.Green;
                text[338] = "W";
            }
            else if (color == 2)
            {
                button339.BackColor = Color.Red;
                text[338] = "E";
            }
            else if (color == 3)
            {
                button339.BackColor = Color.Blue;
                text[338] = "H";
            }
            else if (color == 4)
            {
                button339.BackColor = Color.Yellow;
                text[338] = "F";
            }
            else if (color == 5)
            {
                button339.BackColor = Color.MidnightBlue;
                text[338] = "O";
            }
            else if (color == 6)
            {
                button339.BackColor = Color.Magenta;
                text[338] = "C";
            }
        }

        private void button340_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button340.BackColor = Color.Green;
                text[339] = "W";
            }
            else if (color == 2)
            {
                button340.BackColor = Color.Red;
                text[339] = "E";
            }
            else if (color == 3)
            {
                button340.BackColor = Color.Blue;
                text[339] = "H";
            }
            else if (color == 4)
            {
                button340.BackColor = Color.Yellow;
                text[339] = "F";
            }
            else if (color == 5)
            {
                button340.BackColor = Color.MidnightBlue;
                text[339] = "O";
            }
            else if (color == 6)
            {
                button340.BackColor = Color.Magenta;
                text[339] = "C";
            }
        }

        private void button341_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button341.BackColor = Color.Green;
                text[340] = "W";
            }
            else if (color == 2)
            {
                button341.BackColor = Color.Red;
                text[340] = "E";
            }
            else if (color == 3)
            {
                button341.BackColor = Color.Blue;
                text[340] = "H";
            }
            else if (color == 4)
            {
                button341.BackColor = Color.Yellow;
                text[340] = "F";
            }
            else if (color == 5)
            {
                button341.BackColor = Color.MidnightBlue;
                text[340] = "O";
            }
            else if (color == 6)
            {
                button341.BackColor = Color.Magenta;
                text[340] = "C";
            }
        }

        private void button342_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button342.BackColor = Color.Green;
                text[341] = "W";
            }
            else if (color == 2)
            {
                button342.BackColor = Color.Red;
                text[341] = "E";
            }
            else if (color == 3)
            {
                button342.BackColor = Color.Blue;
                text[341] = "H";
            }
            else if (color == 4)
            {
                button342.BackColor = Color.Yellow;
                text[341] = "F";
            }
            else if (color == 5)
            {
                button342.BackColor = Color.MidnightBlue;
                text[341] = "O";
            }
            else if (color == 6)
            {
                button342.BackColor = Color.Magenta;
                text[341] = "C";
            }
        }

        private void button343_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button343.BackColor = Color.Green;
                text[342] = "W";
            }
            else if (color == 2)
            {
                button343.BackColor = Color.Red;
                text[342] = "E";
            }
            else if (color == 3)
            {
                button343.BackColor = Color.Blue;
                text[342] = "H";
            }
            else if (color == 4)
            {
                button343.BackColor = Color.Yellow;
                text[342] = "F";
            }
            else if (color == 5)
            {
                button343.BackColor = Color.MidnightBlue;
                text[342] = "O";
            }
            else if (color == 6)
            {
                button343.BackColor = Color.Magenta;
                text[342] = "C";
            }
        }

        private void button344_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button344.BackColor = Color.Green;
                text[343] = "W";
            }
            else if (color == 2)
            {
                button344.BackColor = Color.Red;
                text[343] = "E";
            }
            else if (color == 3)
            {
                button344.BackColor = Color.Blue;
                text[343] = "H";
            }
            else if (color == 4)
            {
                button344.BackColor = Color.Yellow;
                text[343] = "F";
            }
            else if (color == 5)
            {
                button344.BackColor = Color.MidnightBlue;
                text[343] = "O";
            }
            else if (color == 6)
            {
                button344.BackColor = Color.Magenta;
                text[343] = "C";
            }
        }

        private void button345_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button345.BackColor = Color.Green;
                text[344] = "W";
            }
            else if (color == 2)
            {
                button345.BackColor = Color.Red;
                text[344] = "E";
            }
            else if (color == 3)
            {
                button345.BackColor = Color.Blue;
                text[344] = "H";
            }
            else if (color == 4)
            {
                button345.BackColor = Color.Yellow;
                text[344] = "F";
            }
            else if (color == 5)
            {
                button345.BackColor = Color.MidnightBlue;
                text[344] = "O";
            }
            else if (color == 6)
            {
                button345.BackColor = Color.Magenta;
                text[344] = "C";
            }
        }

        private void button346_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button346.BackColor = Color.Green;
                text[345] = "W";
            }
            else if (color == 2)
            {
                button346.BackColor = Color.Red;
                text[345] = "E";
            }
            else if (color == 3)
            {
                button346.BackColor = Color.Blue;
                text[345] = "H";
            }
            else if (color == 4)
            {
                button346.BackColor = Color.Yellow;
                text[345] = "F";
            }
            else if (color == 5)
            {
                button346.BackColor = Color.MidnightBlue;
                text[345] = "O";
            }
            else if (color == 6)
            {
                button346.BackColor = Color.Magenta;
                text[345] = "C";
            }
        }

        private void button347_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button347.BackColor = Color.Green;
                text[346] = "W";
            }
            else if (color == 2)
            {
                button347.BackColor = Color.Red;
                text[346] = "E";
            }
            else if (color == 3)
            {
                button347.BackColor = Color.Blue;
                text[346] = "H";
            }
            else if (color == 4)
            {
                button347.BackColor = Color.Yellow;
                text[346] = "F";
            }
            else if (color == 5)
            {
                button347.BackColor = Color.MidnightBlue;
                text[346] = "O";
            }
            else if (color == 6)
            {
                button347.BackColor = Color.Magenta;
                text[346] = "C";
            }
        }

        private void button348_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button348.BackColor = Color.Green;
                text[347] = "W";
            }
            else if (color == 2)
            {
                button348.BackColor = Color.Red;
                text[347] = "E";
            }
            else if (color == 3)
            {
                button348.BackColor = Color.Blue;
                text[347] = "H";
            }
            else if (color == 4)
            {
                button348.BackColor = Color.Yellow;
                text[347] = "F";
            }
            else if (color == 5)
            {
                button348.BackColor = Color.MidnightBlue;
                text[347] = "O";
            }
            else if (color == 6)
            {
                button348.BackColor = Color.Magenta;
                text[347] = "C";
            }
        }

        private void button349_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button349.BackColor = Color.Green;
                text[348] = "W";
            }
            else if (color == 2)
            {
                button349.BackColor = Color.Red;
                text[348] = "E";
            }
            else if (color == 3)
            {
                button349.BackColor = Color.Blue;
                text[348] = "H";
            }
            else if (color == 4)
            {
                button349.BackColor = Color.Yellow;
                text[348] = "F";
            }
            else if (color == 5)
            {
                button349.BackColor = Color.MidnightBlue;
                text[348] = "O";
            }
            else if (color == 6)
            {
                button349.BackColor = Color.Magenta;
                text[348] = "C";
            }
        }

        private void button350_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button350.BackColor = Color.Green;
                text[349] = "W";
            }
            else if (color == 2)
            {
                button350.BackColor = Color.Red;
                text[349] = "E";
            }
            else if (color == 3)
            {
                button350.BackColor = Color.Blue;
                text[349] = "H";
            }
            else if (color == 4)
            {
                button350.BackColor = Color.Yellow;
                text[349] = "F";
            }
            else if (color == 5)
            {
                button350.BackColor = Color.MidnightBlue;
                text[349] = "O";
            }
            else if (color == 6)
            {
                button350.BackColor = Color.Magenta;
                text[349] = "C";
            }
        }

        private void button351_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button351.BackColor = Color.Green;
                text[350] = "W";
            }
            else if (color == 2)
            {
                button351.BackColor = Color.Red;
                text[350] = "E";
            }
            else if (color == 3)
            {
                button351.BackColor = Color.Blue;
                text[350] = "H";
            }
            else if (color == 4)
            {
                button351.BackColor = Color.Yellow;
                text[350] = "F";
            }
            else if (color == 5)
            {
                button351.BackColor = Color.MidnightBlue;
                text[350] = "O";
            }
            else if (color == 6)
            {
                button351.BackColor = Color.Magenta;
                text[350] = "C";
            }
        }

        private void button352_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button352.BackColor = Color.Green;
                text[351] = "W";
            }
            else if (color == 2)
            {
                button352.BackColor = Color.Red;
                text[351] = "E";
            }
            else if (color == 3)
            {
                button352.BackColor = Color.Blue;
                text[351] = "H";
            }
            else if (color == 4)
            {
                button352.BackColor = Color.Yellow;
                text[351] = "F";
            }
            else if (color == 5)
            {
                button352.BackColor = Color.MidnightBlue;
                text[351] = "O";
            }
            else if (color == 6)
            {
                button352.BackColor = Color.Magenta;
                text[351] = "C";
            }
        }

        private void button353_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button353.BackColor = Color.Green;
                text[352] = "W";
            }
            else if (color == 2)
            {
                button353.BackColor = Color.Red;
                text[352] = "E";
            }
            else if (color == 3)
            {
                button353.BackColor = Color.Blue;
                text[352] = "H";
            }
            else if (color == 4)
            {
                button353.BackColor = Color.Yellow;
                text[352] = "F";
            }
            else if (color == 5)
            {
                button353.BackColor = Color.MidnightBlue;
                text[352] = "O";
            }
            else if (color == 6)
            {
                button353.BackColor = Color.Magenta;
                text[352] = "C";
            }
        }

        private void button354_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button354.BackColor = Color.Green;
                text[353] = "W";
            }
            else if (color == 2)
            {
                button354.BackColor = Color.Red;
                text[353] = "E";
            }
            else if (color == 3)
            {
                button354.BackColor = Color.Blue;
                text[353] = "H";
            }
            else if (color == 4)
            {
                button354.BackColor = Color.Yellow;
                text[353] = "F";
            }
            else if (color == 5)
            {
                button354.BackColor = Color.MidnightBlue;
                text[353] = "O";
            }
            else if (color == 6)
            {
                button354.BackColor = Color.Magenta;
                text[353] = "C";
            }
        }

        private void button355_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button355.BackColor = Color.Green;
                text[354] = "W";
            }
            else if (color == 2)
            {
                button355.BackColor = Color.Red;
                text[354] = "E";
            }
            else if (color == 3)
            {
                button355.BackColor = Color.Blue;
                text[354] = "H";
            }
            else if (color == 4)
            {
                button355.BackColor = Color.Yellow;
                text[354] = "F";
            }
            else if (color == 5)
            {
                button355.BackColor = Color.MidnightBlue;
                text[354] = "O";
            }
            else if (color == 6)
            {
                button355.BackColor = Color.Magenta;
                text[354] = "C";
            }
        }

        private void button356_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button356.BackColor = Color.Green;
                text[355] = "W";
            }
            else if (color == 2)
            {
                button356.BackColor = Color.Red;
                text[355] = "E";
            }
            else if (color == 3)
            {
                button356.BackColor = Color.Blue;
                text[355] = "H";
            }
            else if (color == 4)
            {
                button356.BackColor = Color.Yellow;
                text[355] = "F";
            }
            else if (color == 5)
            {
                button356.BackColor = Color.MidnightBlue;
                text[355] = "O";
            }
            else if (color == 6)
            {
                button356.BackColor = Color.Magenta;
                text[355] = "C";
            }
        }

        private void button357_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button357.BackColor = Color.Green;
                text[356] = "W";
            }
            else if (color == 2)
            {
                button357.BackColor = Color.Red;
                text[356] = "E";
            }
            else if (color == 3)
            {
                button357.BackColor = Color.Blue;
                text[356] = "H";
            }
            else if (color == 4)
            {
                button357.BackColor = Color.Yellow;
                text[356] = "F";
            }
            else if (color == 5)
            {
                button357.BackColor = Color.MidnightBlue;
                text[356] = "O";
            }
            else if (color == 6)
            {
                button357.BackColor = Color.Magenta;
                text[356] = "C";
            }
        }

        private void button358_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button358.BackColor = Color.Green;
                text[357] = "W";
            }
            else if (color == 2)
            {
                button358.BackColor = Color.Red;
                text[357] = "E";
            }
            else if (color == 3)
            {
                button358.BackColor = Color.Blue;
                text[357] = "H";
            }
            else if (color == 4)
            {
                button358.BackColor = Color.Yellow;
                text[357] = "F";
            }
            else if (color == 5)
            {
                button358.BackColor = Color.MidnightBlue;
                text[357] = "O";
            }
            else if (color == 6)
            {
                button358.BackColor = Color.Magenta;
                text[357] = "C";
            }
        }

        private void button359_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button359.BackColor = Color.Green;
                text[358] = "W";
            }
            else if (color == 2)
            {
                button359.BackColor = Color.Red;
                text[358] = "E";
            }
            else if (color == 3)
            {
                button359.BackColor = Color.Blue;
                text[358] = "H";
            }
            else if (color == 4)
            {
                button359.BackColor = Color.Yellow;
                text[358] = "F";
            }
            else if (color == 5)
            {
                button359.BackColor = Color.MidnightBlue;
                text[358] = "O";
            }
            else if (color == 6)
            {
                button359.BackColor = Color.Magenta;
                text[358] = "C";
            }
        }

        private void button360_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button360.BackColor = Color.Green;
                text[359] = "W";
            }
            else if (color == 2)
            {
                button360.BackColor = Color.Red;
                text[359] = "E";
            }
            else if (color == 3)
            {
                button360.BackColor = Color.Blue;
                text[359] = "H";
            }
            else if (color == 4)
            {
                button360.BackColor = Color.Yellow;
                text[359] = "F";
            }
            else if (color == 5)
            {
                button360.BackColor = Color.MidnightBlue;
                text[359] = "O";
            }
            else if (color == 6)
            {
                button360.BackColor = Color.Magenta;
                text[359] = "C";
            }
        }

        private void button361_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button361.BackColor = Color.Green;
                text[360] = "W";
            }
            else if (color == 2)
            {
                button361.BackColor = Color.Red;
                text[360] = "E";
            }
            else if (color == 3)
            {
                button361.BackColor = Color.Blue;
                text[360] = "H";
            }
            else if (color == 4)
            {
                button361.BackColor = Color.Yellow;
                text[360] = "F";
            }
            else if (color == 5)
            {
                button361.BackColor = Color.MidnightBlue;
                text[360] = "O";
            }
            else if (color == 6)
            {
                button361.BackColor = Color.Magenta;
                text[360] = "C";
            }
        }

        private void button362_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button362.BackColor = Color.Green;
                text[361] = "W";
            }
            else if (color == 2)
            {
                button362.BackColor = Color.Red;
                text[361] = "E";
            }
            else if (color == 3)
            {
                button362.BackColor = Color.Blue;
                text[361] = "H";
            }
            else if (color == 4)
            {
                button362.BackColor = Color.Yellow;
                text[361] = "F";
            }
            else if (color == 5)
            {
                button362.BackColor = Color.MidnightBlue;
                text[361] = "O";
            }
            else if (color == 6)
            {
                button362.BackColor = Color.Magenta;
                text[361] = "C";
            }
        }

        private void button363_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button363.BackColor = Color.Green;
                text[362] = "W";
            }
            else if (color == 2)
            {
                button363.BackColor = Color.Red;
                text[362] = "E";
            }
            else if (color == 3)
            {
                button363.BackColor = Color.Blue;
                text[362] = "H";
            }
            else if (color == 4)
            {
                button363.BackColor = Color.Yellow;
                text[362] = "F";
            }
            else if (color == 5)
            {
                button363.BackColor = Color.MidnightBlue;
                text[362] = "O";
            }
            else if (color == 6)
            {
                button363.BackColor = Color.Magenta;
                text[362] = "C";
            }
        }

        private void button364_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button364.BackColor = Color.Green;
                text[363] = "W";
            }
            else if (color == 2)
            {
                button364.BackColor = Color.Red;
                text[363] = "E";
            }
            else if (color == 3)
            {
                button364.BackColor = Color.Blue;
                text[363] = "H";
            }
            else if (color == 4)
            {
                button364.BackColor = Color.Yellow;
                text[363] = "F";
            }
            else if (color == 5)
            {
                button364.BackColor = Color.MidnightBlue;
                text[363] = "O";
            }
            else if (color == 6)
            {
                button364.BackColor = Color.Magenta;
                text[363] = "C";
            }
        }

        private void button365_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button365.BackColor = Color.Green;
                text[364] = "W";
            }
            else if (color == 2)
            {
                button365.BackColor = Color.Red;
                text[364] = "E";
            }
            else if (color == 3)
            {
                button365.BackColor = Color.Blue;
                text[364] = "H";
            }
            else if (color == 4)
            {
                button365.BackColor = Color.Yellow;
                text[364] = "F";
            }
            else if (color == 5)
            {
                button365.BackColor = Color.MidnightBlue;
                text[364] = "O";
            }
            else if (color == 6)
            {
                button365.BackColor = Color.Magenta;
                text[364] = "C";
            }
        }

        private void button366_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button366.BackColor = Color.Green;
                text[365] = "W";
            }
            else if (color == 2)
            {
                button366.BackColor = Color.Red;
                text[365] = "E";
            }
            else if (color == 3)
            {
                button366.BackColor = Color.Blue;
                text[365] = "H";
            }
            else if (color == 4)
            {
                button366.BackColor = Color.Yellow;
                text[365] = "F";
            }
            else if (color == 5)
            {
                button366.BackColor = Color.MidnightBlue;
                text[365] = "O";
            }
            else if (color == 6)
            {
                button366.BackColor = Color.Magenta;
                text[365] = "C";
            }
        }

        private void button367_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button367.BackColor = Color.Green;
                text[366] = "W";
            }
            else if (color == 2)
            {
                button367.BackColor = Color.Red;
                text[366] = "E";
            }
            else if (color == 3)
            {
                button367.BackColor = Color.Blue;
                text[366] = "H";
            }
            else if (color == 4)
            {
                button367.BackColor = Color.Yellow;
                text[366] = "F";
            }
            else if (color == 5)
            {
                button367.BackColor = Color.MidnightBlue;
                text[366] = "O";
            }
            else if (color == 6)
            {
                button367.BackColor = Color.Magenta;
                text[366] = "C";
            }
        }

        private void button368_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button368.BackColor = Color.Green;
                text[367] = "W";
            }
            else if (color == 2)
            {
                button368.BackColor = Color.Red;
                text[367] = "E";
            }
            else if (color == 3)
            {
                button368.BackColor = Color.Blue;
                text[367] = "H";
            }
            else if (color == 4)
            {
                button368.BackColor = Color.Yellow;
                text[367] = "F";
            }
            else if (color == 5)
            {
                button368.BackColor = Color.MidnightBlue;
                text[367] = "O";
            }
            else if (color == 6)
            {
                button368.BackColor = Color.Magenta;
                text[367] = "C";
            }
        }

        private void button369_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button369.BackColor = Color.Green;
                text[368] = "W";
            }
            else if (color == 2)
            {
                button369.BackColor = Color.Red;
                text[368] = "E";
            }
            else if (color == 3)
            {
                button369.BackColor = Color.Blue;
                text[368] = "H";
            }
            else if (color == 4)
            {
                button369.BackColor = Color.Yellow;
                text[368] = "F";
            }
            else if (color == 5)
            {
                button369.BackColor = Color.MidnightBlue;
                text[368] = "O";
            }
            else if (color == 6)
            {
                button369.BackColor = Color.Magenta;
                text[368] = "C";
            }
        }

        private void button370_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button370.BackColor = Color.Green;
                text[369] = "W";
            }
            else if (color == 2)
            {
                button370.BackColor = Color.Red;
                text[369] = "E";
            }
            else if (color == 3)
            {
                button370.BackColor = Color.Blue;
                text[369] = "H";
            }
            else if (color == 4)
            {
                button370.BackColor = Color.Yellow;
                text[369] = "F";
            }
            else if (color == 5)
            {
                button370.BackColor = Color.MidnightBlue;
                text[369] = "O";
            }
            else if (color == 6)
            {
                button370.BackColor = Color.Magenta;
                text[369] = "C";
            }
        }

        private void button371_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button371.BackColor = Color.Green;
                text[370] = "W";
            }
            else if (color == 2)
            {
                button371.BackColor = Color.Red;
                text[370] = "E";
            }
            else if (color == 3)
            {
                button371.BackColor = Color.Blue;
                text[370] = "H";
            }
            else if (color == 4)
            {
                button371.BackColor = Color.Yellow;
                text[370] = "F";
            }
            else if (color == 5)
            {
                button371.BackColor = Color.MidnightBlue;
                text[370] = "O";
            }
            else if (color == 6)
            {
                button371.BackColor = Color.Magenta;
                text[370] = "C";
            }
        }

        private void button372_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button372.BackColor = Color.Green;
                text[371] = "W";
            }
            else if (color == 2)
            {
                button372.BackColor = Color.Red;
                text[371] = "E";
            }
            else if (color == 3)
            {
                button372.BackColor = Color.Blue;
                text[371] = "H";
            }
            else if (color == 4)
            {
                button372.BackColor = Color.Yellow;
                text[371] = "F";
            }
            else if (color == 5)
            {
                button372.BackColor = Color.MidnightBlue;
                text[371] = "O";
            }
            else if (color == 6)
            {
                button372.BackColor = Color.Magenta;
                text[371] = "C";
            }
        }

        private void button373_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button373.BackColor = Color.Green;
                text[372] = "W";
            }
            else if (color == 2)
            {
                button373.BackColor = Color.Red;
                text[372] = "E";
            }
            else if (color == 3)
            {
                button373.BackColor = Color.Blue;
                text[372] = "H";
            }
            else if (color == 4)
            {
                button373.BackColor = Color.Yellow;
                text[372] = "F";
            }
            else if (color == 5)
            {
                button373.BackColor = Color.MidnightBlue;
                text[372] = "O";
            }
            else if (color == 6)
            {
                button373.BackColor = Color.Magenta;
                text[372] = "C";
            }
        }

        private void button374_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button374.BackColor = Color.Green;
                text[373] = "W";
            }
            else if (color == 2)
            {
                button374.BackColor = Color.Red;
                text[373] = "E";
            }
            else if (color == 3)
            {
                button374.BackColor = Color.Blue;
                text[373] = "H";
            }
            else if (color == 4)
            {
                button374.BackColor = Color.Yellow;
                text[373] = "F";
            }
            else if (color == 5)
            {
                button374.BackColor = Color.MidnightBlue;
                text[373] = "O";
            }
            else if (color == 6)
            {
                button374.BackColor = Color.Magenta;
                text[373] = "C";
            }
        }

        private void button375_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button375.BackColor = Color.Green;
                text[374] = "W";
            }
            else if (color == 2)
            {
                button375.BackColor = Color.Red;
                text[374] = "E";
            }
            else if (color == 3)
            {
                button375.BackColor = Color.Blue;
                text[374] = "H";
            }
            else if (color == 4)
            {
                button375.BackColor = Color.Yellow;
                text[374] = "F";
            }
            else if (color == 5)
            {
                button375.BackColor = Color.MidnightBlue;
                text[374] = "O";
            }
            else if (color == 6)
            {
                button375.BackColor = Color.Magenta;
                text[374] = "C";
            }
        }

        private void button376_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button376.BackColor = Color.Green;
                text[375] = "W";
            }
            else if (color == 2)
            {
                button376.BackColor = Color.Red;
                text[375] = "E";
            }
            else if (color == 3)
            {
                button376.BackColor = Color.Blue;
                text[375] = "H";
            }
            else if (color == 4)
            {
                button376.BackColor = Color.Yellow;
                text[375] = "F";
            }
            else if (color == 5)
            {
                button376.BackColor = Color.MidnightBlue;
                text[375] = "O";
            }
            else if (color == 6)
            {
                button376.BackColor = Color.Magenta;
                text[375] = "C";
            }
        }

        private void button377_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button377.BackColor = Color.Green;
                text[376] = "W";
            }
            else if (color == 2)
            {
                button377.BackColor = Color.Red;
                text[376] = "E";
            }
            else if (color == 3)
            {
                button377.BackColor = Color.Blue;
                text[376] = "H";
            }
            else if (color == 4)
            {
                button377.BackColor = Color.Yellow;
                text[376] = "F";
            }
            else if (color == 5)
            {
                button377.BackColor = Color.MidnightBlue;
                text[376] = "O";
            }
            else if (color == 6)
            {
                button377.BackColor = Color.Magenta;
                text[376] = "C";
            }
        }

        private void button378_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button378.BackColor = Color.Green;
                text[377] = "W";
            }
            else if (color == 2)
            {
                button378.BackColor = Color.Red;
                text[377] = "E";
            }
            else if (color == 3)
            {
                button378.BackColor = Color.Blue;
                text[377] = "H";
            }
            else if (color == 4)
            {
                button378.BackColor = Color.Yellow;
                text[377] = "F";
            }
            else if (color == 5)
            {
                button378.BackColor = Color.MidnightBlue;
                text[377] = "O";
            }
            else if (color == 6)
            {
                button378.BackColor = Color.Magenta;
                text[377] = "C";
            }
        }

        private void button379_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button379.BackColor = Color.Green;
                text[378] = "W";
            }
            else if (color == 2)
            {
                button379.BackColor = Color.Red;
                text[378] = "E";
            }
            else if (color == 3)
            {
                button379.BackColor = Color.Blue;
                text[378] = "H";
            }
            else if (color == 4)
            {
                button379.BackColor = Color.Yellow;
                text[378] = "F";
            }
            else if (color == 5)
            {
                button379.BackColor = Color.MidnightBlue;
                text[378] = "O";
            }
            else if (color == 6)
            {
                button379.BackColor = Color.Magenta;
                text[378] = "C";
            }
        }

        private void button380_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button380.BackColor = Color.Green;
                text[379] = "W";
            }
            else if (color == 2)
            {
                button380.BackColor = Color.Red;
                text[379] = "E";
            }
            else if (color == 3)
            {
                button380.BackColor = Color.Blue;
                text[379] = "H";
            }
            else if (color == 4)
            {
                button380.BackColor = Color.Yellow;
                text[379] = "F";
            }
            else if (color == 5)
            {
                button380.BackColor = Color.MidnightBlue;
                text[379] = "O";
            }
            else if (color == 6)
            {
                button380.BackColor = Color.Magenta;
                text[379] = "C";
            }
        }

        private void button381_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button381.BackColor = Color.Green;
                text[380] = "W";
            }
            else if (color == 2)
            {
                button381.BackColor = Color.Red;
                text[380] = "E";
            }
            else if (color == 3)
            {
                button381.BackColor = Color.Blue;
                text[380] = "H";
            }
            else if (color == 4)
            {
                button381.BackColor = Color.Yellow;
                text[380] = "F";
            }
            else if (color == 5)
            {
                button381.BackColor = Color.MidnightBlue;
                text[380] = "O";
            }
            else if (color == 6)
            {
                button381.BackColor = Color.Magenta;
                text[380] = "C";
            }
        }

        private void button382_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button382.BackColor = Color.Green;
                text[381] = "W";
            }
            else if (color == 2)
            {
                button382.BackColor = Color.Red;
                text[381] = "E";
            }
            else if (color == 3)
            {
                button382.BackColor = Color.Blue;
                text[381] = "H";
            }
            else if (color == 4)
            {
                button382.BackColor = Color.Yellow;
                text[381] = "F";
            }
            else if (color == 5)
            {
                button382.BackColor = Color.MidnightBlue;
                text[381] = "O";
            }
            else if (color == 6)
            {
                button382.BackColor = Color.Magenta;
                text[381] = "C";
            }
        }

        private void button383_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button383.BackColor = Color.Green;
                text[382] = "W";
            }
            else if (color == 2)
            {
                button383.BackColor = Color.Red;
                text[382] = "E";
            }
            else if (color == 3)
            {
                button383.BackColor = Color.Blue;
                text[382] = "H";
            }
            else if (color == 4)
            {
                button383.BackColor = Color.Yellow;
                text[382] = "F";
            }
            else if (color == 5)
            {
                button383.BackColor = Color.MidnightBlue;
                text[382] = "O";
            }
            else if (color == 6)
            {
                button383.BackColor = Color.Magenta;
                text[382] = "C";
            }
        }

        private void button384_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button384.BackColor = Color.Green;
                text[383] = "W";
            }
            else if (color == 2)
            {
                button384.BackColor = Color.Red;
                text[383] = "E";
            }
            else if (color == 3)
            {
                button384.BackColor = Color.Blue;
                text[383] = "H";
            }
            else if (color == 4)
            {
                button384.BackColor = Color.Yellow;
                text[383] = "F";
            }
            else if (color == 5)
            {
                button384.BackColor = Color.MidnightBlue;
                text[383] = "O";
            }
            else if (color == 6)
            {
                button384.BackColor = Color.Magenta;
                text[383] = "C";
            }
        }
        #endregion

        #region Right 2 Code
        private void button385_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button385.BackColor = Color.Green;
                text[384] = "W";
            }
            else if (color == 2)
            {
                button385.BackColor = Color.Red;
                text[384] = "E";
            }
            else if (color == 3)
            {
                button385.BackColor = Color.Blue;
                text[384] = "H";
            }
            else if (color == 4)
            {
                button385.BackColor = Color.Yellow;
                text[384] = "F";
            }
            else if (color == 5)
            {
                button385.BackColor = Color.MidnightBlue;
                text[384] = "O";
            }
            else if (color == 6)
            {
                button385.BackColor = Color.Magenta;
                text[384] = "C";
            }
        }

        private void button386_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button386.BackColor = Color.Green;
                text[385] = "W";
            }
            else if (color == 2)
            {
                button386.BackColor = Color.Red;
                text[385] = "E";
            }
            else if (color == 3)
            {
                button386.BackColor = Color.Blue;
                text[385] = "H";
            }
            else if (color == 4)
            {
                button386.BackColor = Color.Yellow;
                text[385] = "F";
            }
            else if (color == 5)
            {
                button386.BackColor = Color.MidnightBlue;
                text[385] = "O";
            }
            else if (color == 6)
            {
                button386.BackColor = Color.Magenta;
                text[385] = "C";
            }
        }

        private void button387_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button387.BackColor = Color.Green;
                text[386] = "W";
            }
            else if (color == 2)
            {
                button387.BackColor = Color.Red;
                text[386] = "E";
            }
            else if (color == 3)
            {
                button387.BackColor = Color.Blue;
                text[386] = "H";
            }
            else if (color == 4)
            {
                button387.BackColor = Color.Yellow;
                text[386] = "F";
            }
            else if (color == 5)
            {
                button387.BackColor = Color.MidnightBlue;
                text[386] = "O";
            }
            else if (color == 6)
            {
                button387.BackColor = Color.Magenta;
                text[386] = "C";
            }
        }

        private void button388_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button388.BackColor = Color.Green;
                text[387] = "W";
            }
            else if (color == 2)
            {
                button388.BackColor = Color.Red;
                text[387] = "E";
            }
            else if (color == 3)
            {
                button388.BackColor = Color.Blue;
                text[387] = "H";
            }
            else if (color == 4)
            {
                button388.BackColor = Color.Yellow;
                text[387] = "F";
            }
            else if (color == 5)
            {
                button388.BackColor = Color.MidnightBlue;
                text[387] = "O";
            }
            else if (color == 6)
            {
                button388.BackColor = Color.Magenta;
                text[387] = "C";
            }
        }

        private void button389_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button389.BackColor = Color.Green;
                text[388] = "W";
            }
            else if (color == 2)
            {
                button389.BackColor = Color.Red;
                text[388] = "E";
            }
            else if (color == 3)
            {
                button389.BackColor = Color.Blue;
                text[388] = "H";
            }
            else if (color == 4)
            {
                button389.BackColor = Color.Yellow;
                text[388] = "F";
            }
            else if (color == 5)
            {
                button389.BackColor = Color.MidnightBlue;
                text[388] = "O";
            }
            else if (color == 6)
            {
                button389.BackColor = Color.Magenta;
                text[388] = "C";
            }
        }

        private void button390_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button390.BackColor = Color.Green;
                text[389] = "W";
            }
            else if (color == 2)
            {
                button390.BackColor = Color.Red;
                text[389] = "E";
            }
            else if (color == 3)
            {
                button390.BackColor = Color.Blue;
                text[380] = "H";
            }
            else if (color == 4)
            {
                button390.BackColor = Color.Yellow;
                text[389] = "F";
            }
            else if (color == 5)
            {
                button390.BackColor = Color.MidnightBlue;
                text[389] = "O";
            }
            else if (color == 6)
            {
                button390.BackColor = Color.Magenta;
                text[389] = "C";
            }
        }

        private void button391_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button391.BackColor = Color.Green;
                text[390] = "W";
            }
            else if (color == 2)
            {
                button391.BackColor = Color.Red;
                text[390] = "E";
            }
            else if (color == 3)
            {
                button391.BackColor = Color.Blue;
                text[390] = "H";
            }
            else if (color == 4)
            {
                button391.BackColor = Color.Yellow;
                text[390] = "F";
            }
            else if (color == 5)
            {
                button391.BackColor = Color.MidnightBlue;
                text[390] = "O";
            }
            else if (color == 6)
            {
                button391.BackColor = Color.Magenta;
                text[390] = "C";
            }
        }

        private void button392_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button392.BackColor = Color.Green;
                text[391] = "W";
            }
            else if (color == 2)
            {
                button392.BackColor = Color.Red;
                text[391] = "E";
            }
            else if (color == 3)
            {
                button392.BackColor = Color.Blue;
                text[391] = "H";
            }
            else if (color == 4)
            {
                button392.BackColor = Color.Yellow;
                text[391] = "F";
            }
            else if (color == 5)
            {
                button392.BackColor = Color.MidnightBlue;
                text[391] = "O";
            }
            else if (color == 6)
            {
                button392.BackColor = Color.Magenta;
                text[391] = "C";
            }
        }

        private void button393_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button393.BackColor = Color.Green;
                text[392] = "W";
            }
            else if (color == 2)
            {
                button393.BackColor = Color.Red;
                text[392] = "E";
            }
            else if (color == 3)
            {
                button393.BackColor = Color.Blue;
                text[392] = "H";
            }
            else if (color == 4)
            {
                button393.BackColor = Color.Yellow;
                text[392] = "F";
            }
            else if (color == 5)
            {
                button393.BackColor = Color.MidnightBlue;
                text[392] = "O";
            }
            else if (color == 6)
            {
                button393.BackColor = Color.Magenta;
                text[392] = "C";
            }
        }

        private void button394_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button394.BackColor = Color.Green;
                text[393] = "W";
            }
            else if (color == 2)
            {
                button394.BackColor = Color.Red;
                text[393] = "E";
            }
            else if (color == 3)
            {
                button394.BackColor = Color.Blue;
                text[393] = "H";
            }
            else if (color == 4)
            {
                button394.BackColor = Color.Yellow;
                text[393] = "F";
            }
            else if (color == 5)
            {
                button394.BackColor = Color.MidnightBlue;
                text[393] = "O";
            }
            else if (color == 6)
            {
                button394.BackColor = Color.Magenta;
                text[393] = "C";
            }
        }

        private void button395_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button395.BackColor = Color.Green;
                text[394] = "W";
            }
            else if (color == 2)
            {
                button395.BackColor = Color.Red;
                text[394] = "E";
            }
            else if (color == 3)
            {
                button395.BackColor = Color.Blue;
                text[394] = "H";
            }
            else if (color == 4)
            {
                button395.BackColor = Color.Yellow;
                text[394] = "F";
            }
            else if (color == 5)
            {
                button395.BackColor = Color.MidnightBlue;
                text[394] = "O";
            }
            else if (color == 6)
            {
                button395.BackColor = Color.Magenta;
                text[394] = "C";
            }
        }

        private void button396_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button396.BackColor = Color.Green;
                text[395] = "W";
            }
            else if (color == 2)
            {
                button396.BackColor = Color.Red;
                text[395] = "E";
            }
            else if (color == 3)
            {
                button396.BackColor = Color.Blue;
                text[395] = "H";
            }
            else if (color == 4)
            {
                button396.BackColor = Color.Yellow;
                text[395] = "F";
            }
            else if (color == 5)
            {
                button396.BackColor = Color.MidnightBlue;
                text[395] = "O";
            }
            else if (color == 6)
            {
                button396.BackColor = Color.Magenta;
                text[395] = "C";
            }
        }

        private void button397_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button397.BackColor = Color.Green;
                text[396] = "W";
            }
            else if (color == 2)
            {
                button397.BackColor = Color.Red;
                text[396] = "E";
            }
            else if (color == 3)
            {
                button397.BackColor = Color.Blue;
                text[396] = "H";
            }
            else if (color == 4)
            {
                button397.BackColor = Color.Yellow;
                text[396] = "F";
            }
            else if (color == 5)
            {
                button397.BackColor = Color.MidnightBlue;
                text[396] = "O";
            }
            else if (color == 6)
            {
                button397.BackColor = Color.Magenta;
                text[396] = "C";
            }
        }

        private void button398_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button398.BackColor = Color.Green;
                text[397] = "W";
            }
            else if (color == 2)
            {
                button398.BackColor = Color.Red;
                text[397] = "E";
            }
            else if (color == 3)
            {
                button398.BackColor = Color.Blue;
                text[397] = "H";
            }
            else if (color == 4)
            {
                button398.BackColor = Color.Yellow;
                text[397] = "F";
            }
            else if (color == 5)
            {
                button398.BackColor = Color.MidnightBlue;
                text[397] = "O";
            }
            else if (color == 6)
            {
                button398.BackColor = Color.Magenta;
                text[397] = "C";
            }
        }

        private void button399_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button399.BackColor = Color.Green;
                text[398] = "W";
            }
            else if (color == 2)
            {
                button399.BackColor = Color.Red;
                text[398] = "E";
            }
            else if (color == 3)
            {
                button399.BackColor = Color.Blue;
                text[398] = "H";
            }
            else if (color == 4)
            {
                button399.BackColor = Color.Yellow;
                text[398] = "F";
            }
            else if (color == 5)
            {
                button399.BackColor = Color.MidnightBlue;
                text[398] = "O";
            }
            else if (color == 6)
            {
                button399.BackColor = Color.Magenta;
                text[398] = "C";
            }
        }

        private void button400_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button400.BackColor = Color.Green;
                text[399] = "W";
            }
            else if (color == 2)
            {
                button400.BackColor = Color.Red;
                text[399] = "E";
            }
            else if (color == 3)
            {
                button400.BackColor = Color.Blue;
                text[399] = "H";
            }
            else if (color == 4)
            {
                button400.BackColor = Color.Yellow;
                text[399] = "F";
            }
            else if (color == 5)
            {
                button400.BackColor = Color.MidnightBlue;
                text[399] = "O";
            }
            else if (color == 6)
            {
                button400.BackColor = Color.Magenta;
                text[399] = "C";
            }
        }

        private void button401_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button401.BackColor = Color.Green;
                text[400] = "W";
            }
            else if (color == 2)
            {
                button401.BackColor = Color.Red;
                text[400] = "E";
            }
            else if (color == 3)
            {
                button401.BackColor = Color.Blue;
                text[400] = "H";
            }
            else if (color == 4)
            {
                button401.BackColor = Color.Yellow;
                text[400] = "F";
            }
            else if (color == 5)
            {
                button401.BackColor = Color.MidnightBlue;
                text[400] = "O";
            }
            else if (color == 6)
            {
                button401.BackColor = Color.Magenta;
                text[400] = "C";
            }
        }

        private void button402_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button402.BackColor = Color.Green;
                text[401] = "W";
            }
            else if (color == 2)
            {
                button402.BackColor = Color.Red;
                text[401] = "E";
            }
            else if (color == 3)
            {
                button402.BackColor = Color.Blue;
                text[401] = "H";
            }
            else if (color == 4)
            {
                button402.BackColor = Color.Yellow;
                text[401] = "F";
            }
            else if (color == 5)
            {
                button402.BackColor = Color.MidnightBlue;
                text[401] = "O";
            }
            else if (color == 6)
            {
                button402.BackColor = Color.Magenta;
                text[401] = "C";
            }
        }

        private void button403_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button403.BackColor = Color.Green;
                text[402] = "W";
            }
            else if (color == 2)
            {
                button403.BackColor = Color.Red;
                text[402] = "E";
            }
            else if (color == 3)
            {
                button403.BackColor = Color.Blue;
                text[402] = "H";
            }
            else if (color == 4)
            {
                button403.BackColor = Color.Yellow;
                text[402] = "F";
            }
            else if (color == 5)
            {
                button403.BackColor = Color.MidnightBlue;
                text[402] = "O";
            }
            else if (color == 6)
            {
                button403.BackColor = Color.Magenta;
                text[402] = "C";
            }
        }

        private void button404_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button404.BackColor = Color.Green;
                text[403] = "W";
            }
            else if (color == 2)
            {
                button404.BackColor = Color.Red;
                text[403] = "E";
            }
            else if (color == 3)
            {
                button404.BackColor = Color.Blue;
                text[403] = "H";
            }
            else if (color == 4)
            {
                button404.BackColor = Color.Yellow;
                text[403] = "F";
            }
            else if (color == 5)
            {
                button404.BackColor = Color.MidnightBlue;
                text[403] = "O";
            }
            else if (color == 6)
            {
                button404.BackColor = Color.Magenta;
                text[403] = "C";
            }
        }

        private void button405_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button405.BackColor = Color.Green;
                text[404] = "W";
            }
            else if (color == 2)
            {
                button405.BackColor = Color.Red;
                text[404] = "E";
            }
            else if (color == 3)
            {
                button405.BackColor = Color.Blue;
                text[404] = "H";
            }
            else if (color == 4)
            {
                button405.BackColor = Color.Yellow;
                text[404] = "F";
            }
            else if (color == 5)
            {
                button405.BackColor = Color.MidnightBlue;
                text[404] = "O";
            }
            else if (color == 6)
            {
                button405.BackColor = Color.Magenta;
                text[404] = "C";
            }
        }

        private void button406_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button406.BackColor = Color.Green;
                text[405] = "W";
            }
            else if (color == 2)
            {
                button406.BackColor = Color.Red;
                text[405] = "E";
            }
            else if (color == 3)
            {
                button406.BackColor = Color.Blue;
                text[405] = "H";
            }
            else if (color == 4)
            {
                button406.BackColor = Color.Yellow;
                text[405] = "F";
            }
            else if (color == 5)
            {
                button406.BackColor = Color.MidnightBlue;
                text[405] = "O";
            }
            else if (color == 6)
            {
                button406.BackColor = Color.Magenta;
                text[405] = "C";
            }
        }

        private void button407_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button407.BackColor = Color.Green;
                text[406] = "W";
            }
            else if (color == 2)
            {
                button407.BackColor = Color.Red;
                text[406] = "E";
            }
            else if (color == 3)
            {
                button407.BackColor = Color.Blue;
                text[406] = "H";
            }
            else if (color == 4)
            {
                button407.BackColor = Color.Yellow;
                text[406] = "F";
            }
            else if (color == 5)
            {
                button407.BackColor = Color.MidnightBlue;
                text[406] = "O";
            }
            else if (color == 6)
            {
                button407.BackColor = Color.Magenta;
                text[406] = "C";
            }
        }

        private void button408_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button408.BackColor = Color.Green;
                text[407] = "W";
            }
            else if (color == 2)
            {
                button408.BackColor = Color.Red;
                text[407] = "E";
            }
            else if (color == 3)
            {
                button408.BackColor = Color.Blue;
                text[407] = "H";
            }
            else if (color == 4)
            {
                button408.BackColor = Color.Yellow;
                text[407] = "F";
            }
            else if (color == 5)
            {
                button408.BackColor = Color.MidnightBlue;
                text[407] = "O";
            }
            else if (color == 6)
            {
                button408.BackColor = Color.Magenta;
                text[407] = "C";
            }
        }

        private void button409_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button409.BackColor = Color.Green;
                text[408] = "W";
            }
            else if (color == 2)
            {
                button409.BackColor = Color.Red;
                text[408] = "E";
            }
            else if (color == 3)
            {
                button409.BackColor = Color.Blue;
                text[408] = "H";
            }
            else if (color == 4)
            {
                button409.BackColor = Color.Yellow;
                text[408] = "F";
            }
            else if (color == 5)
            {
                button409.BackColor = Color.MidnightBlue;
                text[408] = "O";
            }
            else if (color == 6)
            {
                button409.BackColor = Color.Magenta;
                text[408] = "C";
            }
        }

        private void button410_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button410.BackColor = Color.Green;
                text[409] = "W";
            }
            else if (color == 2)
            {
                button410.BackColor = Color.Red;
                text[409] = "E";
            }
            else if (color == 3)
            {
                button410.BackColor = Color.Blue;
                text[409] = "H";
            }
            else if (color == 4)
            {
                button410.BackColor = Color.Yellow;
                text[409] = "F";
            }
            else if (color == 5)
            {
                button410.BackColor = Color.MidnightBlue;
                text[409] = "O";
            }
            else if (color == 6)
            {
                button410.BackColor = Color.Magenta;
                text[409] = "C";
            }
        }

        private void button411_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button411.BackColor = Color.Green;
                text[410] = "W";
            }
            else if (color == 2)
            {
                button411.BackColor = Color.Red;
                text[410] = "E";
            }
            else if (color == 3)
            {
                button411.BackColor = Color.Blue;
                text[410] = "H";
            }
            else if (color == 4)
            {
                button411.BackColor = Color.Yellow;
                text[410] = "F";
            }
            else if (color == 5)
            {
                button411.BackColor = Color.MidnightBlue;
                text[410] = "O";
            }
            else if (color == 6)
            {
                button411.BackColor = Color.Magenta;
                text[410] = "C";
            }
        }

        private void button412_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button412.BackColor = Color.Green;
                text[411] = "W";
            }
            else if (color == 2)
            {
                button412.BackColor = Color.Red;
                text[411] = "E";
            }
            else if (color == 3)
            {
                button412.BackColor = Color.Blue;
                text[411] = "H";
            }
            else if (color == 4)
            {
                button412.BackColor = Color.Yellow;
                text[411] = "F";
            }
            else if (color == 5)
            {
                button412.BackColor = Color.MidnightBlue;
                text[411] = "O";
            }
            else if (color == 6)
            {
                button412.BackColor = Color.Magenta;
                text[411] = "C";
            }
        }

        private void button413_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button413.BackColor = Color.Green;
                text[412] = "W";
            }
            else if (color == 2)
            {
                button413.BackColor = Color.Red;
                text[412] = "E";
            }
            else if (color == 3)
            {
                button413.BackColor = Color.Blue;
                text[412] = "H";
            }
            else if (color == 4)
            {
                button413.BackColor = Color.Yellow;
                text[412] = "F";
            }
            else if (color == 5)
            {
                button413.BackColor = Color.MidnightBlue;
                text[412] = "O";
            }
            else if (color == 6)
            {
                button413.BackColor = Color.Magenta;
                text[412] = "C";
            }
        }

        private void button414_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button414.BackColor = Color.Green;
                text[413] = "W";
            }
            else if (color == 2)
            {
                button414.BackColor = Color.Red;
                text[413] = "E";
            }
            else if (color == 3)
            {
                button414.BackColor = Color.Blue;
                text[413] = "H";
            }
            else if (color == 4)
            {
                button414.BackColor = Color.Yellow;
                text[413] = "F";
            }
            else if (color == 5)
            {
                button414.BackColor = Color.MidnightBlue;
                text[413] = "O";
            }
            else if (color == 6)
            {
                button414.BackColor = Color.Magenta;
                text[413] = "C";
            }
        }

        private void button415_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button415.BackColor = Color.Green;
                text[414] = "W";
            }
            else if (color == 2)
            {
                button415.BackColor = Color.Red;
                text[414] = "E";
            }
            else if (color == 3)
            {
                button415.BackColor = Color.Blue;
                text[414] = "H";
            }
            else if (color == 4)
            {
                button415.BackColor = Color.Yellow;
                text[414] = "F";
            }
            else if (color == 5)
            {
                button415.BackColor = Color.MidnightBlue;
                text[414] = "O";
            }
            else if (color == 6)
            {
                button415.BackColor = Color.Magenta;
                text[414] = "C";
            }
        }

        private void button416_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button416.BackColor = Color.Green;
                text[415] = "W";
            }
            else if (color == 2)
            {
                button416.BackColor = Color.Red;
                text[415] = "E";
            }
            else if (color == 3)
            {
                button416.BackColor = Color.Blue;
                text[415] = "H";
            }
            else if (color == 4)
            {
                button416.BackColor = Color.Yellow;
                text[415] = "F";
            }
            else if (color == 5)
            {
                button416.BackColor = Color.MidnightBlue;
                text[415] = "O";
            }
            else if (color == 6)
            {
                button416.BackColor = Color.Magenta;
                text[415] = "C";
            }
        }

        private void button417_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button417.BackColor = Color.Green;
                text[416] = "W";
            }
            else if (color == 2)
            {
                button417.BackColor = Color.Red;
                text[416] = "E";
            }
            else if (color == 3)
            {
                button417.BackColor = Color.Blue;
                text[416] = "H";
            }
            else if (color == 4)
            {
                button417.BackColor = Color.Yellow;
                text[416] = "F";
            }
            else if (color == 5)
            {
                button417.BackColor = Color.MidnightBlue;
                text[416] = "O";
            }
            else if (color == 6)
            {
                button417.BackColor = Color.Magenta;
                text[416] = "C";
            }
        }

        private void button418_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button418.BackColor = Color.Green;
                text[417] = "W";
            }
            else if (color == 2)
            {
                button418.BackColor = Color.Red;
                text[417] = "E";
            }
            else if (color == 3)
            {
                button418.BackColor = Color.Blue;
                text[417] = "H";
            }
            else if (color == 4)
            {
                button418.BackColor = Color.Yellow;
                text[417] = "F";
            }
            else if (color == 5)
            {
                button418.BackColor = Color.MidnightBlue;
                text[417] = "O";
            }
            else if (color == 6)
            {
                button418.BackColor = Color.Magenta;
                text[417] = "C";
            }
        }

        private void button419_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button419.BackColor = Color.Green;
                text[418] = "W";
            }
            else if (color == 2)
            {
                button419.BackColor = Color.Red;
                text[418] = "E";
            }
            else if (color == 3)
            {
                button419.BackColor = Color.Blue;
                text[418] = "H";
            }
            else if (color == 4)
            {
                button419.BackColor = Color.Yellow;
                text[418] = "F";
            }
            else if (color == 5)
            {
                button419.BackColor = Color.MidnightBlue;
                text[418] = "O";
            }
            else if (color == 6)
            {
                button419.BackColor = Color.Magenta;
                text[418] = "C";
            }
        }

        private void button420_Click(object sender, EventArgs e) //nice
        {
            if (color == 1)
            {
                button420.BackColor = Color.Green;
                text[419] = "W";
            }
            else if (color == 2)
            {
                button420.BackColor = Color.Red;
                text[419] = "E";
            }
            else if (color == 3)
            {
                button420.BackColor = Color.Blue;
                text[419] = "H";
            }
            else if (color == 4)
            {
                button420.BackColor = Color.Yellow;
                text[419] = "F";
            }
            else if (color == 5)
            {
                button420.BackColor = Color.MidnightBlue;
                text[419] = "O";
            }
            else if (color == 6)
            {
                button420.BackColor = Color.Magenta;
                text[419] = "C";
            }
        }

        private void button421_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button421.BackColor = Color.Green;
                text[420] = "W";
            }
            else if (color == 2)
            {
                button421.BackColor = Color.Red;
                text[420] = "E";
            }
            else if (color == 3)
            {
                button421.BackColor = Color.Blue;
                text[420] = "H";
            }
            else if (color == 4)
            {
                button421.BackColor = Color.Yellow;
                text[420] = "F";
            }
            else if (color == 5)
            {
                button421.BackColor = Color.MidnightBlue;
                text[420] = "O";
            }
            else if (color == 6)
            {
                button421.BackColor = Color.Magenta;
                text[420] = "C";
            }
        }

        private void button422_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button422.BackColor = Color.Green;
                text[421] = "W";
            }
            else if (color == 2)
            {
                button422.BackColor = Color.Red;
                text[421] = "E";
            }
            else if (color == 3)
            {
                button422.BackColor = Color.Blue;
                text[421] = "H";
            }
            else if (color == 4)
            {
                button422.BackColor = Color.Yellow;
                text[421] = "F";
            }
            else if (color == 5)
            {
                button422.BackColor = Color.MidnightBlue;
                text[421] = "O";
            }
            else if (color == 6)
            {
                button422.BackColor = Color.Magenta;
                text[421] = "C";
            }
        }

        private void button423_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button423.BackColor = Color.Green;
                text[422] = "W";
            }
            else if (color == 2)
            {
                button423.BackColor = Color.Red;
                text[422] = "E";
            }
            else if (color == 3)
            {
                button423.BackColor = Color.Blue;
                text[422] = "H";
            }
            else if (color == 4)
            {
                button423.BackColor = Color.Yellow;
                text[422] = "F";
            }
            else if (color == 5)
            {
                button423.BackColor = Color.MidnightBlue;
                text[422] = "O";
            }
            else if (color == 6)
            {
                button423.BackColor = Color.Magenta;
                text[422] = "C";
            }
        }

        private void button424_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button424.BackColor = Color.Green;
                text[423] = "W";
            }
            else if (color == 2)
            {
                button424.BackColor = Color.Red;
                text[423] = "E";
            }
            else if (color == 3)
            {
                button424.BackColor = Color.Blue;
                text[423] = "H";
            }
            else if (color == 4)
            {
                button424.BackColor = Color.Yellow;
                text[423] = "F";
            }
            else if (color == 5)
            {
                button424.BackColor = Color.MidnightBlue;
                text[423] = "O";
            }
            else if (color == 6)
            {
                button424.BackColor = Color.Magenta;
                text[423] = "C";
            }
        }

        private void button425_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button425.BackColor = Color.Green;
                text[424] = "W";
            }
            else if (color == 2)
            {
                button425.BackColor = Color.Red;
                text[424] = "E";
            }
            else if (color == 3)
            {
                button425.BackColor = Color.Blue;
                text[424] = "H";
            }
            else if (color == 4)
            {
                button425.BackColor = Color.Yellow;
                text[424] = "F";
            }
            else if (color == 5)
            {
                button425.BackColor = Color.MidnightBlue;
                text[424] = "O";
            }
            else if (color == 6)
            {
                button425.BackColor = Color.Magenta;
                text[424] = "C";
            }
        }

        private void button426_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button426.BackColor = Color.Green;
                text[425] = "W";
            }
            else if (color == 2)
            {
                button426.BackColor = Color.Red;
                text[425] = "E";
            }
            else if (color == 3)
            {
                button426.BackColor = Color.Blue;
                text[425] = "H";
            }
            else if (color == 4)
            {
                button426.BackColor = Color.Yellow;
                text[425] = "F";
            }
            else if (color == 5)
            {
                button426.BackColor = Color.MidnightBlue;
                text[425] = "O";
            }
            else if (color == 6)
            {
                button426.BackColor = Color.Magenta;
                text[425] = "C";
            }
        }

        private void button427_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button427.BackColor = Color.Green;
                text[426] = "W";
            }
            else if (color == 2)
            {
                button427.BackColor = Color.Red;
                text[426] = "E";
            }
            else if (color == 3)
            {
                button427.BackColor = Color.Blue;
                text[426] = "H";
            }
            else if (color == 4)
            {
                button427.BackColor = Color.Yellow;
                text[426] = "F";
            }
            else if (color == 5)
            {
                button427.BackColor = Color.MidnightBlue;
                text[426] = "O";
            }
            else if (color == 6)
            {
                button427.BackColor = Color.Magenta;
                text[426] = "C";
            }
        }

        private void button428_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button428.BackColor = Color.Green;
                text[427] = "W";
            }
            else if (color == 2)
            {
                button428.BackColor = Color.Red;
                text[427] = "E";
            }
            else if (color == 3)
            {
                button428.BackColor = Color.Blue;
                text[427] = "H";
            }
            else if (color == 4)
            {
                button428.BackColor = Color.Yellow;
                text[427] = "F";
            }
            else if (color == 5)
            {
                button428.BackColor = Color.MidnightBlue;
                text[427] = "O";
            }
            else if (color == 6)
            {
                button428.BackColor = Color.Magenta;
                text[427] = "C";
            }
        }

        private void button429_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button429.BackColor = Color.Green;
                text[428] = "W";
            }
            else if (color == 2)
            {
                button429.BackColor = Color.Red;
                text[428] = "E";
            }
            else if (color == 3)
            {
                button429.BackColor = Color.Blue;
                text[428] = "H";
            }
            else if (color == 4)
            {
                button429.BackColor = Color.Yellow;
                text[428] = "F";
            }
            else if (color == 5)
            {
                button429.BackColor = Color.MidnightBlue;
                text[428] = "O";
            }
            else if (color == 6)
            {
                button429.BackColor = Color.Magenta;
                text[428] = "C";
            }
        }

        private void button430_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button430.BackColor = Color.Green;
                text[429] = "W";
            }
            else if (color == 2)
            {
                button430.BackColor = Color.Red;
                text[429] = "E";
            }
            else if (color == 3)
            {
                button430.BackColor = Color.Blue;
                text[429] = "H";
            }
            else if (color == 4)
            {
                button430.BackColor = Color.Yellow;
                text[429] = "F";
            }
            else if (color == 5)
            {
                button430.BackColor = Color.MidnightBlue;
                text[429] = "O";
            }
            else if (color == 6)
            {
                button430.BackColor = Color.Magenta;
                text[429] = "C";
            }
        }

        private void button431_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button431.BackColor = Color.Green;
                text[430] = "W";
            }
            else if (color == 2)
            {
                button431.BackColor = Color.Red;
                text[430] = "E";
            }
            else if (color == 3)
            {
                button431.BackColor = Color.Blue;
                text[430] = "H";
            }
            else if (color == 4)
            {
                button431.BackColor = Color.Yellow;
                text[430] = "F";
            }
            else if (color == 5)
            {
                button431.BackColor = Color.MidnightBlue;
                text[430] = "O";
            }
            else if (color == 6)
            {
                button431.BackColor = Color.Magenta;
                text[430] = "C";
            }
        }

        private void button432_Click(object sender, EventArgs e)
        {
            if (color == 1)
            {
                button432.BackColor = Color.Green;
                text[431] = "W";
            }
            else if (color == 2)
            {
                button432.BackColor = Color.Red;
                text[431] = "E";
            }
            else if (color == 3)
            {
                button432.BackColor = Color.Blue;
                text[431] = "H";
            }
            else if (color == 4)
            {
                button432.BackColor = Color.Yellow;
                text[431] = "F";
            }
            else if (color == 5)
            {
                button432.BackColor = Color.MidnightBlue;
                text[431] = "O";
            }
            else if (color == 6)
            {
                button432.BackColor = Color.Magenta;
                text[431] = "C";
            }
        }
        #endregion

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            color = 1;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            color = 2;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            color = 3;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            color = 4;
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            color = 5;
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            color = 6;
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            File.WriteAllText("../../../../lvltxt.rtf", String.Empty);

            for (int i = 0; i < 432; i++)
            {
                if (i % 8 == 0)
                {
                    tEdit += "\n";
                }
                tEdit += text[i];
            }

            File.WriteAllText("../../../../lvltxt.rtf", tEdit);

            this.Hide();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            text = new string[432];
            for (int i = 0; i < 432; i++)
            {
                text[i] = "F";
            }
        }
    }
}
