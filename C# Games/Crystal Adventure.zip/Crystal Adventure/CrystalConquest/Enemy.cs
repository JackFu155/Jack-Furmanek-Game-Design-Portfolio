﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace CrystalConquest
{
    enum EnemyState { FacingLeft, FacingRight}
    class Enemy : Character
    {
        private bool isDead;
        private Random rng;
        private bool invincible;

        EnemyState eState;
        //animation fields
        private int frame; // current frame number
        private Point frameSize; // width and height of image
        private int numFrames; // number of frames on spritesheet
        private int rows, cols; // defines how spritesheet is laid out
        private int timeSinceLastFrame; // elapsed time since frame was drawn
        private int millisecondsPerFrame; // millisec to display a frame
        private Point currentFrame; // location of current frame on spritesheet
        private Vector2 position2;

        public int MillisecondsPerFrame
        {
            set { millisecondsPerFrame = value; }
        }

        const int windowWidth = 960;
        const int windowHeight = 720;
        public bool Invincible
        {
            get { return invincible; }
            set { invincible = value; }
        }
        public bool IsDead
        {
            get { return isDead; }
        }

        public Enemy(int Ehealth, int Edamage, Rectangle Epos) : base(Ehealth, Edamage, Epos)
        {
            isDead = false;
            rng = new Random();
            frameSize = new Point(100,100);
            numFrames = 10;
            rows = 1;
            cols = 10;
            millisecondsPerFrame = 70;
            currentFrame.X = 0;
            currentFrame.Y = 0;
        }

        public void Draw(SpriteBatch sb, SpriteFont sf,GameTime gameTime)
        {
            //sb.Draw(texture, position, Color.White);
            DrawSlimeAnimation(gameTime, sb);
            
            //sb.DrawString(sf,"Enemy Health: " +  health.ToString(), new Vector2(600, 0), Color.White);
            //sb.DrawString(sf,string.Format("( {0} , {1})", position.X , position.Y), new Vector2(600,50), Color.White);
        }
        private void DrawSlimeAnimation(GameTime gameTime, SpriteBatch spriteBatch)
        {
            if(eState == EnemyState.FacingRight)
            {
                spriteBatch.Draw(texture, // image to draw
                new Vector2(position.X, position.Y), // where to draw in window
                new Rectangle(currentFrame.X, currentFrame.Y, frameSize.X, frameSize.Y), // part of the image to draw
                Color.White, // don't change image color
                0, // no rotation of image
                Vector2.Zero, // center of rotation - not used
                1f, // don't change image size
                SpriteEffects.None, // no special effects
                0); // draw on same levvel as other images
            }
            else
            {
                spriteBatch.Draw(texture, // image to draw
                new Vector2(position.X, position.Y), // where to draw in window
                new Rectangle(currentFrame.X, currentFrame.Y, frameSize.X, frameSize.Y), // part of the image to draw
                Color.White, // don't change image color
                0, // no rotation of image
                Vector2.Zero, // center of rotation - not used
                1f, // don't change image size
                SpriteEffects.FlipHorizontally, // no special effects
                0); // draw on same levvel as other images
            }

        }
        /// <summary>
        /// Simple pathfinding code for the enemy to track the player
        /// </summary>
        /// <param name="p"></param>
        public void EnemyUpdate(Player p, GameTime gameTime)
        {
            CheckBounds();
            if (position.X > p.position.X)
            {
                eState = EnemyState.FacingLeft;
                position.X -= rng.Next(0, 2);
            }
            if (position.X < p.position.X)
            {
                eState = EnemyState.FacingRight;
                position.X += rng.Next(0, 2);
            }
            if (position.Y > p.position.Y)
            {
                position.Y -= rng.Next(0, 2);
            }
            if (position.Y < p.position.Y)
            {
                position.Y += rng.Next(0, 2);
            }
            if (health <= 0)
            {
                isDead = true;
            }

            //animation code
            timeSinceLastFrame += gameTime.ElapsedGameTime.Milliseconds;

            // time to change frame
            if (timeSinceLastFrame > millisecondsPerFrame)
            {
                timeSinceLastFrame = 0; // clear elapsed time
                frame++;

                // out of frames, return to start
                if (frame >= numFrames)
                {
                    frame = 0; // restart
                }

                // set location of frame to display
                switch (frame)
                {
                    case 0:
                        currentFrame.X = 1;
                        currentFrame.Y = 1;
                        break;
                    case 1:
                        currentFrame.X = 102;
                        currentFrame.Y = 1;
                        break;
                    case 2:
                        currentFrame.X = 203;
                        currentFrame.Y = 1;
                        break;
                    case 3:
                        currentFrame.X = 304;
                        currentFrame.Y = 1;
                        break;
                    case 4:
                        currentFrame.X = 405;
                        currentFrame.Y = 1;
                        break;
                    case 5:
                        currentFrame.X = 506;
                        currentFrame.Y = 1;
                        break;
                    case 6:
                        currentFrame.X = 607;
                        currentFrame.Y = 1;
                        break;
                    case 7:
                        currentFrame.X = 708;
                        currentFrame.Y = 1;
                        break;
                    case 8:
                        currentFrame.X = 809;
                        currentFrame.Y = 1;
                        break;
                    case 9:
                        currentFrame.X = 910;
                        currentFrame.Y = 1;
                        break;
                }
            }
        }

        public void CheckBounds()
        {
            //checks for xBounds
            if (position.X <= 0)
            {
                position.X = 0;
            }
            //checking if it exceeds the window size
            else if (position.X >= windowWidth - position.Width)
            {
                position.X = windowWidth - position.Width;
            }

            //checks for yBounds
            if (position.Y <= 0)
            {
                position.Y = 0;
            }
            else if (position.Y >= windowHeight - position.Height)
            {
                position.Y = windowHeight - position.Height;
            }

        }
    }
}
