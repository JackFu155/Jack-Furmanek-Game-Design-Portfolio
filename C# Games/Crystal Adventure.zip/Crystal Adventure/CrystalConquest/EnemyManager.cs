﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace CrystalConquest
{
    class EnemyManager
    {
        List<Enemy> enemyList = new List<Enemy>();
        private bool isEmpty;
        private int levelCount;
        private int enemyCount;
        private Random rng;
        private List<Texture2D> spriteList;
        public Texture2D slimeSprite;

        //width and height
        const int windowWidth = 960;
        const int windowHeight = 720;

        public bool IsEmpty
        {
            get { return isEmpty; }
        }

        public List<Enemy> EnemyList
        {
            get { return enemyList; }
        }

        public EnemyManager(List<Texture2D> spriteList)
        {
            isEmpty = false;

            this.spriteList = spriteList;
            slimeSprite = spriteList[0];

            levelCount = 0;
            rng = new Random();
        }

        public void Draw(SpriteBatch sb, SpriteFont sf, GameTime gameTime)
        {
            foreach (Enemy e in enemyList)
            {
                e.Draw(sb, sf, gameTime);
                //sb.DrawString(sf, "Health: " + e.Health.ToString(), new Vector2(500, 10), Color.White);
            }
        }

        public void Update(Player p, GameTime gameTime)
        {
            foreach (Enemy e in enemyList)
            {
                e.EnemyUpdate(p,gameTime);

            }
            for (int x = 0; x < enemyList.Count; x++)
            {
                if (enemyList[x].IsDead == true)
                {
                    enemyList.RemoveAt(x);
                }
            }
            if (enemyList.Count <= 0)
            {
                isEmpty = true;
            }
        }

        public void Initalize(int chosenX, int chosenY)
        {
            Enemy e = new Enemy(10, 10, new Rectangle(chosenX, chosenY, 50, 50));
            e.texture = slimeSprite;
            enemyList.Add(e);
        }


        /// <summary>
        /// Helper method created for incrementing enemys per level
        /// </summary>
        /// <returns></returns>
        private int EnemyCount()
        {
            if (levelCount == 0)
            {
                enemyCount = 1;
                return enemyCount;
            }
            else
            {
                enemyCount = 5 + (levelCount * 2);
                return enemyCount;
            }
        }

        private Enemy CreateEnemy()
        {
            Enemy e = new Enemy(10, 10, new Rectangle(rng.Next(0, 960), rng.Next(0, 720), 50, 50));
            e.texture = slimeSprite;
            return e;
        }


    }
}
