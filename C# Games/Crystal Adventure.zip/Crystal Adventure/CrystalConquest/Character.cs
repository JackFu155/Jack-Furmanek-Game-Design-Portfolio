﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
namespace CrystalConquest
{
    //Acts as a child class for player objects from gameobjects
    class Character : GameObjects
    {
        //creates a shared int health representing player health value
        protected int health;

        //Allows us to recieve and modify the value outside the class
        public int Health
        {
            get { return health; }
            set { health = value; }
        }

        //creates a shared int damage representing value of damage that the player recieves
        protected int damage;

        //Allows us to recieve and modify the value outside the class
        public int Damage { get { return damage; } set { damage = value; } }

        //protected int speed;
        //public int Speed { get { return speed; } set { speed = value; } }

        //This parent constructor allows us to add in the values of health and damage the player can do
        //It also allows us to set the position of the collision rectangle based on the parent class GameObjects
        public Character(int _health, int _damage, Rectangle pos) : base(pos)
        {
            health = _health;
            damage = _damage;
        }

    }
}
