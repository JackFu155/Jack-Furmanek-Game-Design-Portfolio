﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace CrystalConquest
{
    class Wall : GameObjects
    {
        Player player;
        public Wall(Rectangle OPos, Player player) : base(OPos)
        {
            this.player = player;
        }
        public bool CheckCollision()
        {
            if(position.Intersects(player.position))
            {
                return true;
            }
            return false;
        }

        public bool HoleCollision()
        {
            if(position.Intersects(player.Position))
            {
                return true;
            }
            return false;
        }
    }
}
