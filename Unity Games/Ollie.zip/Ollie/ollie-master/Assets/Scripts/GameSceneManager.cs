﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class GameSceneManager : MonoBehaviour
{
    // lists of gems
    public List<GameObject> airGems;
    public List<GameObject> earthGems;
    public List<GameObject> fireGems;
    public List<GameObject> waterGems;
    public List<GameObject> keys;
    // list of mupbups
    public List<GameObject> mupbups;

    // list of torches
    public List<GameObject> torches;
    public GameObject gate;
    // objective bools
    public bool collectGems;
    public bool lightTorches;
    public bool openChests;
    public bool findMupBup;
    public bool allTrue;

    // Ollie
    public GameObject ollie;

    // wait tingy
    WaitForSeconds waitForTut;

    // tutorial sprites
    public GameObject ollieIntro;
    public GameObject wTut;
    public GameObject aTut;
    public GameObject dTut;
    public GameObject outro;

    // float for timing
    public float counter = 0;

    // Start is called before the first frame update
    void Start()
    {
        collectGems = false;
        lightTorches = false;
        openChests = false;
        findMupBup = false;
        allTrue = false;

        ollieIntro.GetComponent<SpriteRenderer>().sortingLayerName = "Default";
        wTut.GetComponent<SpriteRenderer>().sortingLayerName = "Default";
        aTut.GetComponent<SpriteRenderer>().sortingLayerName = "Default";
        dTut.GetComponent<SpriteRenderer>().sortingLayerName = "Default";
        outro.GetComponent<SpriteRenderer>().sortingLayerName = "Default";
    }

    // Update is called once per frame
    void Update()
    {
        counter += 0.1f * Time.deltaTime;
        PlayTutorialMessages();

        // the chest wil take care of its boolean from its own class
        if (openChests == true && mupbups[0].GetComponent<MupBup>().transformed == false) // condition for mupbup 01
        {
            mupbups[0].GetComponent<MupBup>().Transform();
        }
        // if to see if all the gems were collected
        if (airGems.Count == 0 && earthGems.Count == 0 && fireGems.Count == 0 && waterGems.Count == 0 && mupbups[1].GetComponent<MupBup>().transformed == false) // condition for mupbup 2
        {
            collectGems = true;
            mupbups[1].GetComponent<MupBup>().Transform();
        }
        
        // if to check if all the torches were lit
        if(torches.Count == 4 && mupbups[2].GetComponent<MupBup>().transformed == false) // condition for mupbup 3
        {
            lightTorches = true;
            mupbups[2].GetComponent<MupBup>().Transform();
        }

        // if to see if the mupbups have been found
        if(mupbups[0].GetComponent<MupBup>().transformed == true
            && mupbups[1].GetComponent<MupBup>().transformed == true
            && mupbups[2].GetComponent<MupBup>().transformed == true
            && mupbups[3].GetComponent<MupBup>().transformed == false)
            // if all other mupbups are transformed
        {
            findMupBup = true;
            mupbups[3].GetComponent<MupBup>().Transform();
        }
        
        // changes scene when the game ends
        if (lightTorches == true && findMupBup==true && collectGems == true && openChests== true)
        {
            allTrue = true;
            // SceneManager.LoadScene("EndScene");           
        }
        
    }


    public void GoThroughTutorial(KeyCode key)
    {

    }

    public void PlayTutorialMessages()
    {
        if (counter <= 0.6f)
        {
            ollieIntro.GetComponent<SpriteRenderer>().sortingLayerName = "Middle";
        }
        else if (counter <= 1.2f && counter > 0.6f)
        {
            ollieIntro.GetComponent<SpriteRenderer>().sortingLayerName = "Default";
            dTut.GetComponent<SpriteRenderer>().sortingLayerName = "Middle";
        }
        else if (counter <= 1.8f && counter > 1.2f)
        {
            dTut.GetComponent<SpriteRenderer>().sortingLayerName = "Default";
            aTut.GetComponent<SpriteRenderer>().sortingLayerName = "Middle";
        }
        else if(counter <= 2.4f && counter > 1.8f)
        {
            aTut.GetComponent<SpriteRenderer>().sortingLayerName = "Default";
            wTut.GetComponent<SpriteRenderer>().sortingLayerName = "Middle";
        }
        else if(counter <= 3.0f && counter > 2.4f)
        {
            wTut.GetComponent<SpriteRenderer>().sortingLayerName = "Default";
            outro.GetComponent<SpriteRenderer>().sortingLayerName = "Middle";
        }
        else
        {
            outro.GetComponent<SpriteRenderer>().sortingLayerName = "Default";
        }
    }



   //  private void OnGUI()
   //  {
   // 
   //      GUI.TextArea(new Rect(0f, 0f, 300f, 250f), 
   //          "Hello! Welcome to the first demo for Ollie!\n " +
   //          "To move right, press D.\n " +
   //          "To move left, press A.\n " +
   //          "To jump, press W.\n " +
   //          "Cool beans! Now that you’re on your way, good luck and have fun!");
   //  }
}
