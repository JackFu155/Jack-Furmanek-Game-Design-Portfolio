﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Torches : MonoBehaviour
{
    public GameObject manager;
    public GameObject ollie;
    public AudioSource soundSource;
    public bool isLit;
    public Animator anim;

    // Start is called before the first frame update
    void Start()
    {
        ollie = GameObject.Find("Ollie");
        isLit = false;
        anim.SetBool("IsLit", false);
    }

    // Update is called once per frame
    void Update()
    {
        if(CalcDist() <= 2f && !isLit)
        {
            isLit = true;
            soundSource.Play();
            // do the animation and add self to the gameScenemanager list
            anim.SetBool("IsLit", true);
            manager.GetComponent<GameSceneManager>().torches.Add(gameObject);
        }
    }

    // gets the distance from Ollie to the object
    private float CalcDist()
    {
        return Mathf.Sqrt(Mathf.Pow((gameObject.transform.position.x - ollie.transform.position.x), 2) + Mathf.Pow((gameObject.transform.position.y - ollie.transform.position.y), 2));
        // the basic distance formula
        // sqaure root of the diff in x sqaured plus the diff in y squared
    }
}
