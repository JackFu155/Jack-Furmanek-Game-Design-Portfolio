﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Key : MonoBehaviour
{
    public GameObject manager;
    public GameObject ollie;
    public AudioSource soundSource;

    // Start is called before the first frame update
    void Start()
    {
        ollie = GameObject.Find("Ollie");
    }

    // Update is called once per frame
    void Update()
    {
        if(CalcDist() <= 2f && soundSource.isPlaying == false)
        {
            ollie.GetComponent<OllieMovement>().hasKey = true;
            soundSource.Play();
            gameObject.GetComponent<SpriteRenderer>().sortingLayerName = "Default";
            Destroy(gameObject, soundSource.clip.length);
        }
    }

    // gets the distance from Ollie to the object
    private float CalcDist()
    {
        return Mathf.Sqrt(Mathf.Pow((gameObject.transform.position.x - ollie.transform.position.x), 2) + Mathf.Pow((gameObject.transform.position.y - ollie.transform.position.y), 2));
        // the basic distance formula
        // sqaure root of the diff in x sqaured plus the diff in y squared
    }
}
